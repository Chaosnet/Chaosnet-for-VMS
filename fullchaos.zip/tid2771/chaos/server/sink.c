/* The software, data, and information contained herein are proprietary to, and comprise
 * valuable trade secrets of, Symbolics, Inc.  They are given in confidence by Symbolics
 * pursuant to a written license agreement, and may be used, copied, transmitted, and stored
 * only in accordance with the terms of such license.
 *
 * Copyright 1984, 1983, 1982, 1981, 1980 Symbolics Inc.  All Rights Reserved.
 *
 * Symbolics, Symbolics 3600, Symbolics 3670, Symbolics 3640, SYMBOLICS-LISP, ZETALISP,
 * MACSYMA, S-GEOMETRY, S-PAINT, and S-RENDER are trademarks of Symbolics, Inc.
 *
 * RESTRICTED RIGHTS LEGEND
 *	Use, duplication, or disclosure by the Government is subject to restrictions
 * as set forth in subdivision (b)(3)(ii) of the Rights in Technical Data and Computer
 * Clause at FAR 52.227-7013.
 *	Symbolics, Inc.
 *	11 Cambridge Center
 *	Cambridge, Massachusetts 02142
 *
 *
 *	Chaos SINK Server
 *	Written by Scott McKay at SCRC
 */

/*
 *  Utility routines for talking to Chaosnet
 */

int *seconds(n)
{
	static int secs[2] = {-1,-1};

	secs[0] = (-10*1000*1000)*n;
	return(secs);
}


struct VMS_Descriptor {int size; char *ptr;};

#define NDESCRS	20
struct VMS_Descriptor *descr(String)
register char *String;
{
	static struct VMS_Descriptor VMS_Descriptors[NDESCRS];
	static int index = 0;
	register int size = 0;

	if (index==NDESCRS) index = 0;
	VMS_Descriptors[index].ptr = String;
	while (*String++) size++;
	VMS_Descriptors[index].size = size;
	return(&VMS_Descriptors[index++]);
}


#include "chaos$library:chaos.h"

#define BANNER	"\r\nVAX/VMS Chaos SINK server V3.0"

#define LSN_TIMER	300		/* timeout for chaos_lsn */

#define	CHAOS_EFN_S	23		/* event flags */

int chaos_conn;				/* chaos connection */
static struct CHAOSNET_DATA_PACKET *packet = 0;

main()
{
	struct {int size; char *ptr;} pkt_descr;
	struct {int size; char *ptr;} rfc_descr;
	int rfc_len;
	char rfc_buf[256];

/*
 * Listen and open a Chaos connection
 */
	rfc_descr.size = 256;
	rfc_descr.ptr = rfc_buf;
	chaos_lsn(&chaos_conn,descr("SINK  "),seconds(LSN_TIMER));
	chaos_state(chaos_conn);
	if ((state_of_conn(chaos_conn)&0377)!=CONN_ST_RFCRCV) {
		exit(0);
	}
	chaos_accept(chaos_conn,15,&rfc_descr,&rfc_len);
	chaos_state(chaos_conn);
	if ((state_of_conn(chaos_conn)&0377)!=CONN_ST_OPEN) {
		exit(0);
	}
	chaos_sout(chaos_conn,descr(BANNER));
	chaos_force_out(chaos_conn);

	if (!(chaos_pkt(&packet)&1)) {	/* allocate a packet */
		chaos_close(chaos_conn,
			    descr("Error allocating Chaos packet\r\n"));
		exit(0);
	}

/*
 * Just read and toss out packets from Chaos
 */
	while (1) {
		chaos_get_pkt(chaos_conn,packet,0,0,0);
		if (!(packet->Pkt_IOSB_Status&1)) {
			chaos_close(chaos_conn,
				    descr("Network I/O error\r\n"));
			exit(0);
		}
		if ((packet->Pkt_Opcode==PKT_OP_LOS) ||
		    (packet->Pkt_Opcode==PKT_OP_CLS) ||
		    (packet->Pkt_Opcode==PKT_OP_EOF)) {
			chaos_close(chaos_conn,
				    descr("Connection lost or closed by NCP\r\n"));
			exit(0);
		}
	}
}

