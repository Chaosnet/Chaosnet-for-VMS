/*
 *
 *	VAX/VMS Chaosnet definitions:
 *		So we can call the Bliss routines from "C"
 *
 */

#define	PKT_MAX_NBYTES	488		/* Maximum packet size	*/

/***fff Connection States ***/
#define	CONN_ST_CLOSED	0		/* Connection Closed	*/
#define	CONN_ST_RFCRCV	1		/* RFC Received		*/
#define	CONN_ST_RFCSNT	2		/* RFC Sent		*/
#define	CONN_ST_OPEN	3		/* Open			*/
#define	CONN_ST_LOS	4		/* Lose			*/
#define	CONN_ST_INCOM	5		/* Incomplete xmit	*/
#define	CONN_ST_NEW	6		/* Newly allocated	*/
#define	CONN_ST_LSN	7		/* Listening		*/
#define	CONN_ST_FULL	0400		/* Window full		*/

/*** Internal Packet types ***/
#define	PKT_TYPE_NET	1		/* Network Packet	*/
#define	PKT_TYPE_USER	2		/* User Packet		*/
#define	PKT_TYPE_GONE	3		/* User Gone		*/
#define	PKT_TYPE_TIMER	4		/* Timer has ticked	*/
#define	PKT_TYPE_STATUS	5		/* User Status Request	*/
#define	PKT_TYPE_STATE	6		/* Int. State Change	*/
#define	PKT_TYPE_MAX	6		/* Highest legal type	*/

/*** Packet op-codes ***/
#define	PKT_OP_RFC	1		/* Request For Connection */
#define	PKT_OP_OPN	2		/* Open Connection	*/
#define	PKT_OP_CLS	3		/* Close Connection	*/
#define	PKT_OP_FWD	4		/* Forward an RFC	*/
#define	PKT_OP_ANS	5		/* Answer		*/
#define	PKT_OP_SNS	6		/* Sense Status		*/
#define	PKT_OP_STS	7		/* Status		*/
#define	PKT_OP_RUT	8		/* Routing Information	*/
#define	PKT_OP_LOS	9		/* Lossage		*/
#define	PKT_OP_LSN	10		/* Listen		*/
#define	PKT_OP_MNT	11		/* Maintenance		*/
#define	PKT_OP_EOF	12		/* End Of File		*/
#define	PKT_OP_UNC	13		/* Uncontrolled Data	*/
#define	PKT_OP_BRD	14		/* Broadcast		*/
#define	PKT_MAX_CTL_OP	14		/* Highest legal control code */
#define	PKT_OP_DAT	0200		/* 8-bit Data		*/
#define	PKT_OP_DAT16	0300		/* 16-bit Data		*/

/*** O/S dependent packet flags ***/
#define	PKT_OFLG_TXNOW	0200		/* Transmitting now	*/
#define	PKT_OFLG_TXFRE	0100		/* Free packet when done*/
#define	PKT_OFLG_ABORT	040		/* Transmit aborted	*/

/*
 *	This is what a packet looks like
 */
struct CHAOSNET_PACKET_HEADER {
	struct CHAOSNET_PACKET_HEADER *Pkt_Link;
	struct CHAOSNET_PACKET_HEADER *Pkt_Back_Link;
	unsigned char		Pkt_Type;
	unsigned char		Pkt_Flags;
	unsigned short		Pkt_Hard_Source;
	unsigned short		Pkt_Hard_Dest;
	unsigned short		Pkt_Hard_Crc;
	struct CHAOSNET_PACKET_HEADER *Pkt_Tx_Link;
	struct CHAOSNET_PACKET_HEADER *Pkt_Tx_End;
	unsigned short		Pkt_IOSB_Status;
	unsigned short		Pkt_IOSB_Bcnt;
	unsigned long		Pkt_IOSB_User;
	unsigned long		Pkt_Time;
	unsigned long		Pkt_Intfc;
	unsigned long		Pkt_Filler[4];
	};

struct CHAOSNET_STATUS_PACKET {
	struct CHAOSNET_PACKET_HEADER Header;
	unsigned short		Pkt_Status_Sta;
	unsigned short		Dummy;
	unsigned long		Pkt_Status_Txw;
	unsigned long		Pkt_Status_Rxw;
	unsigned long		Pkt_Status_Txwa;
	unsigned long		Pkt_Status_Rxav;
	};

struct CHAOSNET_DATA_PACKET {
	struct CHAOSNET_PACKET_HEADER Header;
	unsigned char		Pkt_Chaos_Type;
	unsigned char		Pkt_Opcode;
	unsigned short		Pkt_Nbytes;
#define	PKT_NBYTES(Packet_Ptr)	(Packet_Ptr->Pkt_Nbytes & 0x0fff)
#define	PKT_FC(Packet_Ptr)	((Packet_Ptr->Pkt_Nbytes & 0xf000) >> 12)
	unsigned short		Pkt_Dest_Host;
	unsigned short		Pkt_Dest_Idx;
	unsigned short		Pkt_Source_Host;
	unsigned short		Pkt_Source_Idx;
	unsigned short		Pkt_Number;
	unsigned short		Pkt_Ack_Number;
	char			Pkt_Data[1];
	};



