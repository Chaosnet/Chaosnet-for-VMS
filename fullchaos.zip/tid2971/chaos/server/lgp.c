/*
 *	Actually, "LGP" server is a misnomer - what this program
 *	really does is to receive an ASCII byte stream (frobbing
 *	carriage control characters) and queues it to LGP$PRINT,
 *	which is, in fact, a normal ASCII printer.  The real LGP
 *	server is included with the LGP software.
 *
 *	Copyright 1984 by Symbolics Inc.
 *
 *		written by Scott McKay (SWM@SCRC)
 *
 */

#include <stdio.h>
#include <jpidef.h>
#include "chaos$library:chaos.h"

struct VMS_Descr {long size; char *ptr;};

#define NDESCRS	20
struct VMS_Descr *Descr(string)
register char *string;
{
	static struct VMS_Descr VMS_Descriptors[NDESCRS];
	static int index = 0;
	register long size = 0;

	if( index == NDESCRS ) index = 0;
	VMS_Descriptors[index].ptr = string;
	while( *string++ ) size++;
	VMS_Descriptors[index].size = size;
	return(&VMS_Descriptors[index++]);
}

int *Seconds(n)
{
	static long secs[2] = {-1,-1};

	secs[0] = (-10*1000*1000)*n;
	return(secs);
}

#define LSN_TIMER	300		/* timeout for chaos_lsn */

#define	CHAOS_EFN_A	23		/* event flags */
#define	CHAOS_EFN_S	22		/* event flags */

unsigned long	Conn;			/* chaos connection */
struct		CHAOSNET_DATA_PACKET *Packet = 0;
FILE		*Out_File;
char		Out_Name[256],Printer_Name[256];

main()
{
	struct VMS_Descr rfc_descr;
	unsigned long rfc_len;
	char rfc_buf[256];
	extern Chaos_AST();
	unsigned long status;
	unsigned long pid;
	static struct {
		short	size;
		short	code;
		char	*buf;
		long	*buf_size;
		} item_list[2];
	unsigned short iosb[4];
	char *dlm,*dlm1;
	register char *cp;

	/*
	 * Listen and open a Chaos connection
	 */
	rfc_descr.size = 256;
	rfc_descr.ptr = rfc_buf;
	chaos_lsn(&Conn,Descr("LGP   "),Seconds(LSN_TIMER));
	chaos_state(Conn);
	if( (state_of_conn(Conn)&0377) != CONN_ST_RFCRCV ) exit();
	chaos_accept(Conn,60,&rfc_descr,&rfc_len);
	chaos_state(Conn);
	if( (state_of_conn(Conn)&0377) != CONN_ST_OPEN ) exit();

	/*
	 * Try to get a printer name out of the RFC
	 */
	strcpy(Printer_Name,"LGP$PRINT");
	if( (dlm = strchr(rfc_buf,0212)) )
	{	dlm1 = strchr(dlm,0174);
		if( dlm1 ) dlm = dlm1;
		dlm1 = strchr(dlm,0212);
		if( !dlm1 ) dlm1 = &rfc_buf[strlen(dlm)];
		*dlm1 = 0;
		strcpy(Printer_Name,++dlm);
	}
	for( cp = Printer_Name; *cp; cp++ )
		if( *cp == 45 ) *cp = 95;
 
	/*
	 * Connection is opened, so open up a "temporary" output file
	 * whose name is based on the current pid
	 */
	item_list[0].size = 4;
	item_list[0].code = JPI$_PID;
	item_list[0].buf = &pid;
	item_list[0].buf_size = 0;
	item_list[1].size = 0;
	item_list[1].code = 0;
	status = sys$getjpi(CHAOS_EFN_S,0,0,item_list,iosb,0,0);
	if( status & 1 )
		sys$waitfr(CHAOS_EFN_S);
	sprintf(Out_Name,"CHAOS$DISK:[CHAOS.TEMP]%X.LGP",pid);
	if( (Out_File = fopen(Out_Name,"w")) == NULL )
	{	chaos_close(Conn,
			    Descr("Couldn't create output file\n"));
		exit();
	}

	/*
	 * Allocate a packet and write the output file
	 */
	if( !(chaos_pkt(&Packet)&1) )	/* allocate a packet */
	{	chaos_close(Conn,
			    Descr("Error allocating Chaos packet\n"));
		exit();
	}
	chaos_asyn_in(Conn,Packet,CHAOS_EFN_A,Chaos_AST,0);
	while( TRUE ) sys$waitfr(CHAOS_EFN_A);
}

/*
 * We have a packet from the network - output it
 */
Chaos_AST()
{
	register int cnt,ch;			/* number of bytes to write */
	register char *cp;

	/*
	 * Ensure we received a packet ok
	 */
	if( !(Packet->Pkt_IOSB_Status&1) )
	{	chaos_close(Conn,
			    Descr("Network I/O error\n"));
		exit();
	}
	if( (Packet->Pkt_Opcode == PKT_OP_LOS) ||
	    (Packet->Pkt_Opcode == PKT_OP_CLS) ||
	    (Packet->Pkt_Opcode == PKT_OP_EOF) )
	{	chaos_close(Conn,
			    Descr("Queued to LGP\n"));
		Queue_To_LGP();		/* never returns */
		exit();
	}
	cnt = PKT_NBYTES(Packet);
	cp = Packet->Pkt_Data;

	/*
	 * Convert newlines and lf's to crlf's, and trash cr's
	 */
	while( cnt-- )
	{	ch = (*cp++ & 0377);
		if( (ch == 0215) || (ch == 012) )
		{	fputc(015,Out_File);
			fputc(012,Out_File);
		}
		else if( ch != 015 )
		{	fputc(ch,Out_File);
		}
	}
	chaos_asyn_in(Conn,Packet,CHAOS_EFN_A,Chaos_AST,0);
}

/*
 * Queue the output file to the LGP
 */
Queue_To_LGP()
{
	char dcl[256],*queue;

	fflush(Out_File);		/* final write */
	fclose(Out_File);
	chmod(Out_Name,0777);
	queue = (char *)getenv(Printer_Name);
	if( !queue ) queue = (char *)getenv("LGP$PRINT");
	if( !queue ) queue = (char *)getenv("SYS$PRINT");
	sprintf(dcl,"PRINT/DEVICE=%s/DELETE %s",queue,Out_Name);
	execute_cli(Descr(dcl));
	exit();
}

