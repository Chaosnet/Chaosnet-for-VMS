/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services error handling code
 */


#include <stdio.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"

/*
 * Define global and external variables
 */
int Signalled_Error = 0;			/* currently signalled error */
char *Error_Messages[] =
	{"Normal successful completion",
	 "Error converting input stream to tokens",
	 "Error reading class name",
	 "Error reading global name",
	 "Error reading name",
	 "Error reading string",
	 "Unrecognized keyword",
	 "Error during disk file I/O",
	 "Error during network I/O",
	 "Cannot allocate memory",
	 "No such object",
	 "No namespace supplied",
	 "Error while reading or setting timestamp",
	 "Bad incremental update type",
	 "Update-by requires a user name",
	 "Field is not YES or NO",
	 "Couldn't establish network connection",
	 "Error while reading or writing changes",
	 "Error while reading or writing log file",
	 "Record is missing a required field",
	 "Protocol version not supported",
	 "Timestamp is too old"};

extern long Lock_Count[];			/* for multiple-use locks */


/*
 * Signal an error
 */
Signal_Error(Code)
int Code;
{	register int i;

	for( i = LOCK_CACHE; i < NLOCKS; i++ )
	{	Lock_Count[i] = 0;
		Unlock_Namespace(i);
	}
	Signalled_Error = Code;
}

/*
 * Clear the signalled error condition
 */
Clear_Error()
{
	Signalled_Error = 0;
}

