/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services include module
 */


/*
 * Standard VAX descriptor format
 */
struct Descrp {
	long Size;
	char *Ptr;
};

/*
 * Define the structure which represents a free block of memory
 */
struct Free_Blk {
	struct Free_Blk *Next;			/* pointer to next free block */
	long Size;				/* size of this block */
};

/*
 * Define the structure which represents a block of active memory
 */
struct Active_Blk {
	long Size;				/* size of this block of memory */
};

#define ERROR(v)		(!(v & 1))
#define BIT(n)			(1 << (n))


/*
 * This header describes a single token.  Notice that Allocate_Token fills
 * allocates and fills in the Name field
 */
struct Token_Hdr {
	unsigned char Length;			/* length of name of token */
	char Class;				/* class of this token, if it's a name */
	short Type;				/* token type, i.e., PRETTY_NAME */
	short Subgroup;				/* length of this subgroup of tokens */
	unsigned short Flags;			/* token flags */
	struct Token_Hdr *Next;			/* pointer to next token header */
	char Name[0];				/* name of token */
};

#define TFLG_STRING		BIT(0)		/* token is a quoted string */
#define TFLG_GLOBAL_NAME	BIT(1)		/* token is a global name */
#define TFLG_NAME		BIT(2)		/* token is a name */
#define TFLG_ELEMENT		BIT(3)		/* token subgroup is an element */
#define TFLG_SET		BIT(4)		/* token is part of a set */
#define TFLG_SPACE		BIT(5)		/* token was terminated with a space */
#define TFLG_NEWLINE		BIT(6)		/* token was terminated with a newline */
#define TFLG_END		BIT(7)		/* this is the end of the record */
#define TFLG_BOL		BIT(8)		/* token is at beginning of line */
#define TFLG_WILD		BIT(9)		/* this token is a wildcard */

/*
 * This header describes a single object
 */
struct Object_Hdr {
	char *Name;				/* name of this object */
	unsigned char Length;			/* length of name of object */
	char Class;				/* class of object, i.e., CLASS_USER */
	unsigned short Flags;			/* object flags */
	struct Object_Hdr *Next;		/* pointer to the next object of this class */
	struct Token_Hdr *Tokens;		/* pointer to the object, as tokens */
	struct Token_Hdr *Other_Names;		/* list of other names, if any */
	long Timestamp;				/* timestamp on this object */
	unsigned long Sequence;			/* unique sequence number */
	unsigned long LRU_Count;		/* increment this upon each use */
	unsigned long Required;			/* required parts */
	unsigned long Given;			/* given parts */
};

#define OFLG_GLOBAL		BIT(0)		/* object is globally named */
#define OFLG_DELETED		BIT(1)		/* object has been deleted */
#define OFLG_CACHED		BIT(2)		/* object has been compressed and cached */
#define OFLG_PERMANENT		BIT(3)		/* object is permanently cached */
#define OFLG_COMPRESSED		BIT(4)		/* object is compressed */

/*
 * This structure describes a single update
 */
struct Change_Hdr {
	unsigned char Length;			/* length of text of change */
	char Class;				/* class of this change */
	struct Change_Hdr *Next;		/* pointer to next change */
	char Name[];				/* text of change */
};

/*
 * This structure describes a set of updates for a single timestamp
 */
struct Change_List {
	struct Change_Hdr *Deleted;		/* pointer to deleted objects */
	struct Change_Hdr *Changed;		/* pointer to changed objects */
	long Timestamp;				/* timestamp for this group of changes */
	struct Change_List *Next;		/* next group */
};


/*
 * Class types
 */
#define CLASS_ANY		-1
#define CLASS_NAMESPACE		0
#define CLASS_SITE		1
#define CLASS_NETWORK		2
#define CLASS_HOST		3
#define CLASS_PRINTER		4
#define CLASS_USER		5
#define NCLASSES		6

/*
 * Class NAMESPACE definitions
 */
#define NAME			0
#define USER_PROPERTY		1
#define PRIMARY_NAME_SERVER	2
#define SECONDARY_NAME_SERVER	3
#define SEARCH_RULES		4
#define DESCRIPTOR_FILE		5
#define INTERNET_DOMAIN_NAME	6
#define	NAMESPACE_KEYCNT	7

/*
 * Class SITE definitions
 */
#define NAME			0
#define USER_PROPERTY		1
#define PRETTY_NAME		2
#define LOCAL_NAMESPACE		3
#define SITE_DIRECTORY		4
#define SITE_SYSTEM		5
#define DEFAULT_PRINTER		6
#define DEFAULT_BITMAP_PRINTER	7
#define HOST_FOR_BUG_REPORTS	8
#define TIMEZONE		9
#define SECURE_SUBNETS		10
#define DONT_REPLY_TO_MAILING_LISTS 11
#define SITES_IGNORED_IN_ZMAIL_SUMMARY 12
#define STANDALONE		13
#define VALIDATE_LMFS_DUMP_TAPES 14
#define TERMINAL_F_ARGUMENT	15
#define HOST_PROTOCOL_DESIRABILITY 16
#define SITE_KEYCNT		17

/*
 * Class NETWORK definitions
 */
#define NAME			0
#define USER_PROPERTY		1
#define NICKNAME		3
#define SITE			4
#define TYPE			5
#define SUBNET			6
#define NETWORK_KEYCNT		7

/*
 * Class HOST definitions
 */
#define NAME			0
#define USER_PROPERTY		1
#define PRETTY_NAME		2
#define NICKNAME		3
#define SITE			4
#define SHORT_NAME		5
#define MACHINE_TYPE		6
#define SYSTEM_TYPE		7
#define ADDRESS			8
#define FINGER_LOCATION		9
#define LOCATION		10
#define PRINTER			11
#define BITMAP_PRINTER		12
#define PRINT_SPOOLER_OPTIONS	13
#define SPOOLED_PRINTER		14
#define SERVICE			15
#define SERVER_MACHINE		16
#define FILE_CONTROL_LIFETIME	17
#define DEFAULT_SECONDARY_SERVER 18
#define PERIPHERAL		19
#define HOST_KEYCNT		20

/*
 * Class PRINTER definitions
 */
#define NAME			0
#define USER_PROPERTY		1
#define PRETTY_NAME		2
#define FORMAT			3
#define SITE			4
#define TYPE			5
#define INTERFACE		6
#define INTERFACE_OPTIONS	7
#define HOST			8
#define PROTOCOL		9
#define DEFAULT_FONT		10
#define HEADER_FONT		11
#define DPLT_LOGO		12
#define CHARACTER_SIZE		13
#define PAGE_SIZE		14
#define FONTS_WIDTHS_FILE	15
#define PRINTER_KEYCNT		16

/*
 * Class USER definitions
 */
#define NAME			0
#define USER_PROPERTY		1
#define PERSONAL_NAME		2
#define NICKNAME		3
#define LOGIN_NAME		4
#define TYPE			5
#define LISPM_NAME		6
#define WORK_ADDRESS		7
#define WORK_PHONE		8
#define HOME_ADDRESS		9
#define HOME_PHONE		10
#define HOME_HOST		11
#define MAIL_ADDRESS		12
#define BIRTHDAY		13
#define PROJECT			14
#define SUPERVISOR		15
#define AFFILIATION		16
#define REMARKS			17
#define USER_KEYCNT		18


/*
 * Define some of the indexed files' attributes - these had better agree
 * with the stuff in NAMECREAT.COM
 */
#define	OBJECT_NAME		0		/* key numbers */
#define OBJECT_SEQ		1
#define OBJECT_TIME		2
#define OBJECT_NAME_SIZE	64		/* key sizes */
#define OBJECT_SEQ_SIZE		4
#define OBJECT_TIME_SIZE	4
#define OBJECT_NAME_POS		0		/* key positions */
#define OBJECT_SEQ_POS		OBJECT_NAME_POS+OBJECT_NAME_SIZE
#define OBJECT_TIME_POS		OBJECT_SEQ_POS+OBJECT_SEQ_SIZE
#define OBJECT_TEXT_POS		OBJECT_TIME_POS+OBJECT_TIME_SIZE

/*
 * Define constants pertaining to on-disk records
 */
#define LSN_TIMER		180		/* timeout for LSN's */
#define RFC_TIMER		60		/* timeout for RFC's */
#define REC_SIZE		2048		/* largest record, w/ overhead */
#define REC_OVHD		OBJECT_NAME_SIZE+OBJECT_SEQ_SIZE+OBJECT_TIME_SIZE
#define CHANGES_SIZE		256		/* largest changes line */
#define NAME_SIZE		128		/* maximum token name size */
#define KEY_MAX			64		/* maximum key size, from above */

/*
 * Lock definitions
 */
#define LOCK_CACHE		0		/* lock the shared cache */
#define LOCK_TIMESTAMP		1		/* lock the on-disk timestamp */
#define LOCK_SEQUENCE		2		/* lock the on-disk sequence number */
#define LOCK_CHANGES		3		/* lock access to the changes file */
#define NLOCKS			4

/*
 * Some useful characters
 */
#define	SPACE			0040
#define TAB			0011
#define CR			0015
#define LF			0012
#define NEWLINE			0215
#define QUOTE			0042
#define SEMICOLON		0073
#define SLASH			0057
#define BACKSLASH		0134
#define META_BIT		0200

/*
 * Update types
 */
#define NO_UPDATE		0
#define FULL_UPDATE		1
#define BRIEF_UPDATE		2

/*
 * Logging type
 */
#define LOG_DELETE		0
#define LOG_ADD			1
#define LOG_CHANGE		2

/*
 * Error codes
 */
#define SUCCESS			0		/* successful completion */
#define ERR_TOKENIZING		1		/* error tokenizing stream */
#define ERR_CLASSNAME		2		/* error getting class name */
#define ERR_GLOBALNAME		3		/* error getting global name */
#define ERR_NAME		4		/* error getting name */
#define ERR_STRING		5		/* error getting string */
#define ERR_KEYWORD		6		/* unrecognized keyword */
#define ERR_FILE		7		/* error during file i/o */
#define ERR_NET			8		/* error during network i/o */
#define ERR_MEM			9		/* error allocating memory */
#define ERR_NOOBJ		10		/* no such object */
#define ERR_NOSPACE		11		/* no namespace name supplied */
#define ERR_TIMESTAMP		12		/* some kind of timestamp error */
#define ERR_INCREMENTAL		13		/* error getting incremental type */
#define ERR_UPDATE_BY		14		/* he didn't say who it is... */
#define ERR_T_OR_NIL		15		/* error getting yes/no */
#define ERR_NO_CONNECTION	16		/* couldn't get a connection */
#define ERR_CHANGES		17		/* error reading/writing change file */
#define ERR_LOG			18		/* ditto for log file */
#define ERR_REQUIRED		19		/* missing required field */
#define ERR_PROTOCOL		20		/* bad or unsupported protcol */
#define ERR_TOO_OLD		21		/* timestamp is too old */
#define NERRORS			22

