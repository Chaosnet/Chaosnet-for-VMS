/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services file and network I/O procedures
 */


#include <stdio.h>
#include <fab.h>
#include <rab.h>
#include <rmsdef.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"
#include "chaos$library:chaos.h"

/*
 * Define global and external variables
 */
struct FAB Fabs[NCLASSES];
struct RAB Rabs[NCLASSES];
int Channels[NCLASSES] = {0,0,0,0,0,0};
struct FAB Changes_Fab,Log_Fab;
struct RAB Changes_Rab,Log_Rab;
char Changes_Buf[CHANGES_SIZE];
long NConn = -1;

extern char *Namespace;				/* namespace we are handling */
extern char *Primary;				/* primary namespace server host */
extern int Repository;				/* true if we are the primary server */
extern char *Classes[];				/* all class names */

/*
 * Rude kludgery to pick up a longword from a whatever
 */
unsigned long Convert_To_Long(Addr)
register long *Addr;
{
	return(*Addr);
}


/*
 * Given a string, return a pointer to a descriptor
 */
#define NDescrs			10

struct Descrp *Descr(String)
char *String;
{	static struct Descrp Descriptors[NDescrs];
	static unsigned int Index = 0;
	register unsigned int Size = 0;

	if( Index == NDescrs ) Index = 0;
	Descriptors[Index].Ptr = String;
	while( *String++ ) Size++;
	Descriptors[Index].Size = Size;
	return(&Descriptors[Index++]);
}

/*
 * Return a pointer to a VMS timer block
 */
int *Seconds(N)
int N;
{	static int Secs[2] = {-1,-1};

	Secs[0] = (-10*1000*1000)*N;
	return(Secs);
}


/*
 * Open up a namespace file
 */
Open_Namespace_File(Class)
register char Class;
{	long Status;
	char Filename[255];

	/*
	 * If we don't manage the database, get a network connection
	 */
	Clear_Error();
	if( !Repository && (NConn == -1) ) Connect_To_Namespace_Server();
	if( (Channels[Class] || (NConn != -1)) ) return(RMS$_NORMAL);

	/*
	 * Make a filename and open it up
	 */
	sprintf(Filename,"CHAOS$DISK:[CHAOS.NAMESPACE.%s]%s.IDX",
		Namespace,Classes[Class]);
	Fabs[Class] = cc$rms_fab;
	Fabs[Class].fab$l_fna = Filename;
	Fabs[Class].fab$b_fns = strlen(Filename);
	Fabs[Class].fab$b_fac = (FAB$M_GET | FAB$M_PUT | FAB$M_DEL | FAB$M_UPD);
	Fabs[Class].fab$b_shr = (FAB$M_GET | FAB$M_PUT | FAB$M_DEL | FAB$M_UPD);
	Rabs[Class] = cc$rms_rab;
	Rabs[Class].rab$l_fab = &Fabs[Class];
	Rabs[Class].rab$b_mbf = 10;
	Status = sys$open(&Fabs[Class]);
	if( !ERROR(Status) ) Status = sys$connect(&Rabs[Class]);
	if( !ERROR(Status) ) Channels[Class]++;
	if( ERROR(Status) ) Signal_Error(ERR_FILE);
	return(Status);
}

/*
 * Close a namespace file
 */
Close_Namespace_File(Class)
register char Class;
{
	if( Channels[Class] ) sys$close(&Fabs[Class]);
	Channels[Class] = 0;
}


/*
 * Seek to beginning of namespace file
 */
Rewind_File(Class,Key)
register char Class;
register short Key;
{	long Status = RMS$_NORMAL;

	if( !Channels[Class] ) Status = Open_Namespace_File(Class);
	if( !ERROR(Status) )
	{	Rabs[Class].rab$b_krf = Key;
		Status = sys$rewind(&Rabs[Class]);
	}
	if( ERROR(Status) ) Signal_Error(ERR_FILE);
}

#define RETRIES			10

/*
 * Read next record from disk into buffer described by Buf_Descr
 */
Get_Next_Record(Class,Key,Buf_Descr,Sequence,Timestamp)
register char Class;
struct Descrp *Buf_Descr;
unsigned long *Sequence;
long *Timestamp;
{	long Status = RMS$_NORMAL;
	int Retries = RETRIES;
	char Rec[REC_SIZE];

	/*
	 * Note well: this continues sequentially based on the last
	 * reference-key we explicitly used
	 */
	if( !Channels[Class] ) Status = Open_Namespace_File(Class);
	if( ERROR(Status) )
	{	Signal_Error(ERR_FILE);
		return(Status);
	}
	Clear_Error();
	Rabs[Class].rab$b_krf = Key;
	Rabs[Class].rab$b_rac = RAB$C_SEQ;
	Rabs[Class].rab$l_ubf = Rec;
	Rabs[Class].rab$w_usz = REC_SIZE;

	/*
	 * Read the record, try several times if it's locked
	 */
	while( ((Status = sys$get(&Rabs[Class])) == RMS$_RLK) &&
	       (Retries-- > 0) )
	{	if( !ERROR(sys$setimr(1,Seconds(1),0,0)) )
			sys$waitfr(1);
	}
	if( ERROR(Status) ) Signal_Error(ERR_FILE);
	else
	{	Buf_Descr->Size = Rabs[Class].rab$w_rsz-OBJECT_TEXT_POS;
		Copy_Block(Buf_Descr->Ptr,Buf_Descr->Size,&Rec[OBJECT_TEXT_POS],TRUE);
		*Sequence = Convert_To_Long(&Rec[OBJECT_SEQ_POS]);
		*Timestamp = Convert_To_Long(&Rec[OBJECT_TIME_POS]);
	}
	return(Status);
}


/*
 * Read keyed record from disk into buffer described by Buf_Descr
 */
int Key_Sizes[3] =				/* key number -> key size map */
	{OBJECT_NAME_SIZE,OBJECT_SEQ_SIZE,OBJECT_TIME_SIZE};

Get_Keyed_Record(Class,Key_Addr,Key,Buf_Descr,Sequence,Timestamp)
register char Class;
register short Key;
char *Key_Addr;
struct Descrp *Buf_Descr;
unsigned long *Sequence;
long *Timestamp;
{	long Status = RMS$_NORMAL;
	int Retries = RETRIES;
	char Rec[REC_SIZE];
	char Key_Buf[KEY_MAX];

	/*
	 * Set up to read by the requested key
	 */
	if( !Channels[Class] ) Status = Open_Namespace_File(Class);
	if( ERROR(Status) )
	{	Signal_Error(ERR_FILE);
		return(Status);
	}
	Clear_Error();
	Rabs[Class].rab$b_rac = RAB$C_KEY;
	Rabs[Class].rab$l_ubf = Rec;
	Rabs[Class].rab$w_usz = REC_SIZE;
	if( Key == OBJECT_NAME )
	{	Copy_Block_Filled(Key_Buf,OBJECT_NAME_SIZE,Key_Addr,strlen(Key_Addr));
		Rabs[Class].rab$l_kbf = Key_Buf;
	}
	else Rabs[Class].rab$l_kbf = Key_Addr;
	Rabs[Class].rab$b_krf = Key;
	Rabs[Class].rab$b_ksz = Key_Sizes[Key];

	/*
	 * Read the record, try several times if it's locked
	 */
	while( ((Status = sys$get(&Rabs[Class])) == RMS$_RLK) &&
	       (Retries-- > 0) )
	{	if( !ERROR(sys$setimr(1,Seconds(1),0,0)) )
			sys$waitfr(1);
	}
	if( ERROR(Status) ) Signal_Error(ERR_FILE);
	else
	{	/*
		 * Fill in all the return information
		 */
		Buf_Descr->Size = Rabs[Class].rab$w_rsz-OBJECT_TEXT_POS;
		Copy_Block(Buf_Descr->Ptr,Buf_Descr->Size,&Rec[OBJECT_TEXT_POS],TRUE);
		*Sequence = Convert_To_Long(&Rec[OBJECT_SEQ_POS]);
		*Timestamp = Convert_To_Long(&Rec[OBJECT_TIME_POS]);
	}
	return(Status);
}


/*
 * Write to disk from buffer described by Buf_Descr.  NB: It is the
 * responsibility of the calling routine to call this for all of the
 * possible names of the object
 */
Put_Named_Record(Class,Name,Buf_Descr,Sequence,Timestamp)
register char Class;
char *Name;
struct Descrp *Buf_Descr;
unsigned long Sequence;
long Timestamp;
{	long Status = RMS$_NORMAL;
	int Retries = RETRIES;
	char Rec[REC_SIZE];
	char Key_Buf[KEY_MAX];
	register int i;

	/*
	 * Set up to write by OBJECT_NAME, the primary key
	 */
	if( !Channels[Class] ) Status = Open_Namespace_File(Class);
	if( ERROR(Status) )
	{	Signal_Error(ERR_FILE);
		return(Status);
	}
	Clear_Error();
	i = strlen(Name);
	Copy_Block_Filled(Key_Buf,OBJECT_NAME_SIZE,Name,i);
	Copy_Block_Filled(&Rec[OBJECT_NAME_POS],OBJECT_NAME_SIZE,Name,i);
	Copy_Block(&Rec[OBJECT_SEQ_POS],OBJECT_SEQ_SIZE,&Sequence,FALSE);
	Copy_Block(&Rec[OBJECT_TIME_POS],OBJECT_TIME_SIZE,&Timestamp,FALSE);
	Copy_Block(&Rec[OBJECT_TEXT_POS],Buf_Descr->Size,Buf_Descr->Ptr,FALSE);
	Rabs[Class].rab$b_rac = RAB$C_KEY;
	Rabs[Class].rab$l_rbf = Rec;
	Rabs[Class].rab$w_rsz = Buf_Descr->Size+OBJECT_TEXT_POS;
	Rabs[Class].rab$l_kbf = Key_Buf;
	Rabs[Class].rab$b_krf = OBJECT_NAME;
	Rabs[Class].rab$b_ksz = OBJECT_NAME_SIZE;

	/*
	 * Write the record, try several times if it's locked
	 */
	while( ((Status = sys$put(&Rabs[Class])) == RMS$_RLK) &&
	       (Retries-- > 0) )
	{	if( !ERROR(sys$setimr(1,Seconds(1),0,0)) )
			sys$waitfr(1);
	}
	if( ERROR(Status) ) Signal_Error(ERR_FILE);
	return(Status);
}


/*
 * Delete keyed record from disk
 */
Delete_Keyed_Record(Class,Key_Addr,Key)
register char Class;
register short Key;
char *Key_Addr;
{	long Status = RMS$_NORMAL;
	int Retries = RETRIES;
	char Key_Buf[KEY_MAX];

	/*
	 * Delete record by the request key
	 */
	if( !Channels[Class] ) Status = Open_Namespace_File(Class);
	if( ERROR(Status) )
	{	Signal_Error(ERR_FILE);
		return(Status);
	}
	Clear_Error();
	Rabs[Class].rab$b_rac = RAB$C_KEY;
	if( Key == OBJECT_NAME )
	{	Copy_Block_Filled(Key_Buf,OBJECT_NAME_SIZE,Key_Addr,strlen(Key_Addr));
		Rabs[Class].rab$l_kbf = Key_Buf;
	}
	else Rabs[Class].rab$l_kbf = Key_Addr;
	Rabs[Class].rab$b_krf = Key;
	Rabs[Class].rab$b_ksz = Key_Sizes[Key];

	/*
	 * Delete the record, try several times if it's locked
	 */
	while( ((Status = sys$find(&Rabs[Class])) == RMS$_RLK) &&
	       (Retries-- > 0) )
	{	if( !ERROR(sys$setimr(1,Seconds(1),0,0)) )
			sys$waitfr(1);
	}
	if( !ERROR(Status) ) Status = sys$delete(&Rabs[Class]);
	if( ERROR(Status) ) Signal_Error(ERR_FILE);
	return(Status);
}


/*
 * Open or create the changes file.  The namespace should be locked
 */
Open_Changes_File(Newp)
int Newp;
{	long Status;
	char Filename[255];

	/*
	 * Open or create a version of CHANGES.TXT
	 */
	Clear_Error();
	sprintf(Filename,"CHAOS$DISK:[CHAOS.NAMESPACE.%s]CHANGES.TXT",Namespace);
	Changes_Fab = cc$rms_fab;
	Changes_Fab.fab$l_fna = Filename;
	Changes_Fab.fab$b_fns = strlen(Filename);
	Changes_Fab.fab$b_fac = (FAB$M_GET | FAB$M_PUT | FAB$M_DEL | FAB$M_UPD);
	Changes_Fab.fab$l_fop = (FAB$M_SQO);
	Changes_Rab = cc$rms_rab;
	Changes_Rab.rab$l_fab = &Changes_Fab;
	if( Newp )				/* creating new version */
	{	Changes_Fab.fab$b_org = FAB$C_SEQ;
		Changes_Fab.fab$b_rat = FAB$M_CR;
		Changes_Fab.fab$b_rfm = FAB$C_VAR;
		Changes_Fab.fab$w_mrs = CHANGES_SIZE;
	}
	else					/* default is to position at eof */
	{	Changes_Rab.rab$l_rop = RAB$M_EOF;
	}
	if( Newp ) Status = sys$create(&Changes_Fab);
	else Status = sys$open(&Changes_Fab);
	if( !ERROR(Status) ) Status = sys$connect(&Changes_Rab);
	if( ERROR(Status) ) Signal_Error(ERR_CHANGES);
	return(Status);
}

/*
 * Close the changes file
 */
Close_Changes_File()
{
	sys$close(&Changes_Fab);
}


/*
 * Read changes record from disk into buffer described by Buf_Descr
 */
Get_Changes_Record(Buf_Descr,Deleted)
int *Deleted;
struct Descrp *Buf_Descr;
{	long Status;
	register int i;
	register int Got_Line = FALSE;
	register int nlines = 0;

	/*
	 * Read from the changes file, line by line, until a blank line
	 * is encountered which signals the end of the record.  Save only
	 * the first line
	 */
	Buf_Descr->Size = 0;
	while( TRUE )
	{	Changes_Rab.rab$b_rac = RAB$C_SEQ;
		Changes_Rab.rab$l_ubf = Changes_Buf;
		Changes_Rab.rab$w_usz = CHANGES_SIZE;

		/*
		 * Read a line from the changes file
		 */
		Status = sys$get(&Changes_Rab);
		nlines++;
		if( ERROR(Status) ) break;

		/*
		 * Copy only first non-blank line into result
		 */
		i = Changes_Rab.rab$w_rsz;
		if( Got_Line && (i == 0) ) break;
		if( Got_Line || (i == 0) ) continue;
		Buf_Descr->Size = i;
		Copy_Block(Buf_Descr->Ptr,i,Changes_Buf,TRUE);
		Got_Line = TRUE;
	}

	if( nlines > 2 ) *Deleted = FALSE;
	else *Deleted = TRUE;
	return(Status);
}

/*
 * Write to changes file from buffer described by Buf_Descr.  The
 * namespace should be locked
 */
Put_Changes_Record(Buf_Descr)
struct Descrp *Buf_Descr;
{	long Status;
	register char *cp,*cp1;

	/*
	 * Break the buffer into lines, and put it into the changes file
	 * one line at a time
	 */
	Clear_Error();
	cp = Buf_Descr->Ptr;
	while( Buf_Descr->Size > 0 )
	{	cp1 = Changes_Buf;
		while( TRUE )
		{	Buf_Descr->Size--;
			if( Buf_Descr->Size < 0 ) break;
			if( (*cp & 0377) == NEWLINE ) break;
			*cp1++ = *cp++;
		}
		cp++;
		Changes_Rab.rab$b_rac = RAB$C_SEQ;
		Changes_Rab.rab$l_rbf = Changes_Buf;
		Changes_Rab.rab$w_rsz = (long)cp1 - (long)Changes_Buf;

		/*
		 * Write the record
		 */
		Status = sys$put(&Changes_Rab);
		if( ERROR(Status) )
		{	Signal_Error(ERR_CHANGES);
			return(Status);
		}
	}
	return(Status);
}


/*
 * Position record pointer in changes file
 */
Position_Changes_File(Initial_TS,Timestamp)
long Initial_TS,*Timestamp;
{	long Status = RMS$_NORMAL;
	long T;
	char Buf[CHANGES_SIZE];

	Clear_Error();
	sys$rewind(&Changes_Rab);
	Changes_Rab.rab$b_rac = RAB$C_SEQ;
	Changes_Rab.rab$l_ubf = Buf;
	Changes_Rab.rab$w_usz = CHANGES_SIZE;
	while( !ERROR(Status) )
	{	Status = sys$get(&Changes_Rab);
		if( ERROR(Status) ) break;
		Buf[Changes_Rab.rab$w_rsz] = NULL;
		T = 0;
		if( sscanf(Buf,"TIMESTAMP %ld",&T) != 1 ) continue;
		if( (T == Initial_TS) || (Initial_TS < 1) )
		{	*Timestamp = T;
			return(TRUE);
		}
		if( T > Initial_TS )
		{	Signal_Error(ERR_TOO_OLD);
			return(FALSE);
		}
	}
	return(FALSE);
}


/*
 * Open or create the log file
 */
Open_Log_File(Newp)
int Newp;
{	long Status;
	char Filename[255];
	char Log_Buf[CHANGES_SIZE];
	register char *cp;

	char *Date_Time();

	/*
	 * Open or create a version of CHANGES.TXT
	 */
	Clear_Error();
	sprintf(Filename,"CHAOS$DISK:[CHAOS.NAMESPACE.%s]NAMESPACE.LOG",Namespace);
	Log_Fab = cc$rms_fab;
	Log_Fab.fab$l_fna = Filename;
	Log_Fab.fab$b_fns = strlen(Filename);
	Log_Fab.fab$b_fac = (FAB$M_GET | FAB$M_PUT | FAB$M_DEL | FAB$M_UPD);
	Log_Fab.fab$l_fop = (FAB$M_SQO);
	Log_Rab = cc$rms_rab;
	Log_Rab.rab$l_fab = &Log_Fab;
	if( Newp )				/* creating new version */
	{	Log_Fab.fab$b_org = FAB$C_SEQ;
		Log_Fab.fab$b_rat = FAB$M_CR;
		Log_Fab.fab$b_rfm = FAB$C_VAR;
		Log_Fab.fab$w_mrs = CHANGES_SIZE;
	}
	else					/* default is to position at eof */
	{	Log_Rab.rab$l_rop = RAB$M_EOF;
	}
	if( Newp ) Status = sys$create(&Log_Fab);
	else Status = sys$open(&Log_Fab);
	if( !ERROR(Status) )
	{	Status = sys$connect(&Log_Rab);
		if( !ERROR(Status) && Newp )
		{	cp = Date_Time();
			sprintf(Log_Buf,"%s Namespace database initialized",cp);
			Log_Rab.rab$b_rac = RAB$C_SEQ;
			Log_Rab.rab$l_rbf = Log_Buf;
			Log_Rab.rab$w_rsz = strlen(Log_Buf);
			Status = sys$put(&Log_Rab);
		}
	}
	if( ERROR(Status) ) Signal_Error(ERR_LOG);
}

/*
 * Close the log file
 */
Close_Log_File()
{
	sys$close(&Log_Fab);
}


/*
 * Write to log file from buffer described by Buf_Descr
 */
Put_Log_Record(Class,Name,Update_By,Timestamp,Type)
char Class;
char *Name,*Update_By;
long Timestamp;
int Type;
{	long Status;
	char Log_Buf[CHANGES_SIZE];
	register char *cp;

	char *Date_Time();

	/*
	 * Copy all relevant data in buffer and write the record
	 */
	Clear_Error();
	cp = Date_Time();
	if( !Update_By ) Update_By = "Zippy";
	if( Type == LOG_DELETE )
	{	sprintf(Log_Buf,"%s %s %s deleted by %s.  Old timestamp was %d.",
			cp,Classes[Class],Name,Update_By,Timestamp);
	}
	else if( Type == LOG_ADD )
	{	sprintf(Log_Buf,"%s %s %s added by %s.  Old timestamp was %d.",
			cp,Classes[Class],Name,Update_By,Timestamp);
	}
	else
	{	sprintf(Log_Buf,"%s %s %s changed by %s.  Old timestamp was %d.",
			cp,Classes[Class],Name,Update_By,Timestamp);
	}
	Log_Rab.rab$b_rac = RAB$C_SEQ;
	Log_Rab.rab$l_rbf = Log_Buf;
	Log_Rab.rab$w_rsz = strlen(Log_Buf);
	Status = sys$put(&Log_Rab);
	if( ERROR(Status) ) Signal_Error(ERR_LOG);
	return(Status);
}

/*
 * Kludge to return ascii date and time
 */
char *Date_Time()
{	long Status;
	long l = 0;
	static char Time_Buf[64];
	struct Descrp D;

	D.Ptr = Time_Buf;
	D.Size = 64;
	Status = sys$asctim(&l,&D,0,0);
	if( ERROR(Status) ) sprintf(Time_Buf,"<bad date and time>");
	else Time_Buf[l] = NULL;
	return(Time_Buf);
}


/*
 * Query a remote namespace server
 */
char *Query_Namespace_Server(Request,Buf_Descr)
char *Request;
struct Descrp *Buf_Descr;
{
	/*
	 * Connect to the namespace server if not already connected,
	 * then send the request string
	 */
	Clear_Error();
	if( NConn == -1 )
	{	if( ERROR(Connect_To_Namespace_Server()) )
			return(NULL);
	}
	/***send off the request***/

	/*
	 * Wait for a response
	 */
	/***do it***/
}

/*
 * Connect to a remote namespace server
 */
Connect_To_Namespace_Server()
{	long Host_Addr = 0;
	struct Descrp RFC_Descr;
	int RFC_Len;
	char RFC_Buf[PKT_MAX_NBYTES];

	/*
	 * Establish a connection to the primary namespace server host,
	 *  or, failing that, the secondary ones
	 */
	Clear_Error();
	RFC_Descr.Ptr = RFC_Buf;
	RFC_Descr.Size = PKT_MAX_NBYTES;
	if( ERROR(hst_str_addr(Descr(Primary),&Host_Addr)) )
		return(ERR_NO_CONNECTION);
	chaos_rfc(&NConn,Host_Addr,Descr("NAMESPACE"),Seconds(RFC_TIMER));
	chaos_state(NConn);
	if( (state_of_conn(NConn) & 0377) != CONN_ST_OPEN )
	{	RFC_Descr.Ptr = RFC_Buf;
		RFC_Descr.Size = PKT_MAX_NBYTES;
		/***if( ERROR(hst_str_addr(Descr(Secondary),&Host_Addr)) )
			return(ERR_NO_CONNECTION);
		chaos_rfc(&NConn,Host_Addr,Descr("NAMESPACE"),Seconds(RFC_TIMER));***/
		chaos_state(NConn);
		if( (state_of_conn(NConn) & 0377) != CONN_ST_OPEN )
			Signal_Error(ERR_NO_CONNECTION);
	}
}

