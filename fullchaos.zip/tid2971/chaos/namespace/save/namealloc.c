/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services memory allocation procedures
 */


#include <stdio.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"

/*
 * Define global and external variables
 */
struct Free_Blk **Free_Memory = NULL;		/* head of free memory list */

extern struct Object_Hdr ***Object_Cache;	/* address of object cache head */
extern char *Classes[];

/*
 * Memory can be thought of as being partitioned into two pools:
 * allocated memory and free memory, each of these pools containing
 * from 0 to N buffers.
 *
 * An allocated buffer consists of a longword which contains a byte
 * count, followed by that many data bytes.
 *
 *		+------------+
 *	+0	|    Size    |
 *		+------------+
 *	+4	|            |
 *		| data bytes |
 *		|            |
 *		+------------+
 *
 * In a free block, the first two longword contain a pointer to the
 * next free block, and the size of the block.  The remaining bytes
 * are meaningless.
 *
 *		+------------+
 *	+0	|   *Next    |
 *		+------------+
 *	+4	|    Size    |
 *		+------------+
 *	+010	|            |
 *		| free bytes |
 *		|            |
 *		+------------+
 */


/*
 * Initialize the free memory header
 */
Initialize_Shared_Memory(Start,End)
register long Start,End;
{
	*Free_Memory = (struct Free_Blk *)Start;
	(*Free_Memory)->Next = NULL;
	(*Free_Memory)->Size = End - Start - 1;
	/* Show_Shared_Memory("Freshly initialized",0,0); */
}

/*
 * Debugging tool to trace memory lists
 */
Show_Shared_Memory(Text,Blk,Size)
char *Text;
long Blk,Size;
{	register struct Free_Blk *f;
	register struct Active_Blk *a;
	register struct Object_Hdr *o;
	register int i;

	if( Text ) fprintf(stderr,"\n%s",Text);
	if( Blk ) fprintf(stderr,", block = x%X",Blk);
	if( Size ) fprintf(stderr,", size = %d",Size);
	fprintf(stderr,"\n\nFree list\n Block\t Size\t Next\n");
	f = *Free_Memory;
	while( f )
	{	fprintf(stderr,"x%X\t %d\tx%X\n",f,f->Size,f->Next);
		f = f->Next;
	}
	fprintf(stderr,"\nActive list\n Block\t Size\t Next\t Name\n");
	for( i = CLASS_NAMESPACE; i < NCLASSES; i++ )
	{	fprintf(stderr,"%s\n",Classes[i]);
		for( o = Object_Cache[i]; o != NULL; o = o->Next )
		{	a = (struct Active_Blk *)((long)o -
						  sizeof(struct Active_Blk));
			fprintf(stderr,"x%X\t %d\tx%X\tx%X\t%s\n",
				a,a->Size,o->Next,o->Name,o->Name);
		}
		fprintf(stderr,"\n");
	}
	fprintf(stderr,"\n");
}


/*
 * Allocate a block of free memory from the object cache
 */
long Get_Shared_Block(Size)
register long Size;
{
	register struct Free_Blk *F,*P,*T;
	register struct Active_Blk *B;
	long FSize;

	/*
	 * Loop over all the free blocks, and try to get a block of
	 * sufficient size to satisfy the request
	 */
	Lock_Namespace(LOCK_CACHE);
	Size = ((Size + sizeof(struct Active_Blk)) + 3) & ~3;
	/* Show_Shared_Memory("Before allocation",0,Size); */
	F = *Free_Memory;
	P = NULL;
	while( F )
	{	if( Size <= F->Size )
		{	/*
			 * We have enough space, so trim off any extra
			 * and leave that in the free list
			 */
			T = F;
			F = (struct Free_Blk *)((long)F + Size);
			FSize = T->Size - Size;
			if( FSize < sizeof(struct Free_Blk) )
			{	Size = T->Size;
				FSize = 0;
			}
			if( FSize )		/* there is a small piece left */
			{	F->Size = FSize;
				F->Next = T->Next;
				if( P ) P->Next = F;
				else *Free_Memory = F;
			}
			else			/* we have used this piece completely */
			{	if( P ) P->Next = T->Next;
				else *Free_Memory = T->Next;
			}
			B = (struct Active_Blk *)T;
			B->Size = Size;
			/* Show_Shared_Memory("After successful allocation",B,0); */
			Unlock_Namespace(LOCK_CACHE);
			return((long)B + sizeof(struct Active_Blk));
		}
		else
		{	/*
			 * Get to the next free block
			 */
			P = F;
			F = F->Next;
		}
	}

	/* Show_Shared_Memory("After unsuccessful allocation",0,0); */
	Unlock_Namespace(LOCK_CACHE);
	return(NULL);
}


/*
 * Return a block of memory to the object cache
 */
Return_Shared_Block(Blk)
long Blk;
{	register struct Free_Blk *B,*Prev,*Next;
	register struct Active_Blk *T;

	/*
	 * First fudge the structures a bit
	 */
	Lock_Namespace(LOCK_CACHE);
	T = (struct Active_Blk *)(Blk - sizeof(struct Active_Blk));
	B = (struct Free_Blk *)T;
	B->Size = T->Size;
	/* Show_Shared_Memory("Before deallocation",T,T->Size); */

	/*
	 * Find the address-sequential place where B should go, first
	 * checking for the special case where there is no free space
	 * or B belongs right at the beginning
	 */
	Prev = *Free_Memory;
	if( ((long)B < (long)Prev) || !Prev )
	{	Next = *Free_Memory;
		Prev = NULL;
		B->Next = Next;
		*Free_Memory = B;		/* B is now head of free list */
	}
	else
	{	Next = Prev->Next;
		while( ((long)B < (long)Next) && Next )
		{	Prev = Next;
			Next = Next->Next;
		}
		B->Next = Next;			/* B goes between Prev and Next */
		Prev->Next = B;
	}

	/*
	 * Try to merge B and Next
	 */
	if( Next && (((long)B + B->Size) == (long)Next) )
	{	B->Size += Next->Size;
		B->Next = Next->Next;
	}

	/*
	 * Try to merge Prev and B
	 */
	if( Prev && (((long)Prev + Prev->Size) == (long)B) )
	{	Prev->Size += B->Size;
		Prev->Next = B->Next;
	}

	/* Show_Shared_Memory("After deallocation",0,0); */
	Unlock_Namespace(LOCK_CACHE);
}	


/*
 * These routines supersede the lousy C run-time library ones
 */
long Get_Block(Size)
long Size;
{	long Real_Size,Address;

	Real_Size = Size+4;
	if( ERROR(lib$get_vm(&Real_Size,&Address)) )
	{	Signal_Error(ERR_MEM);
		return(NULL);
	}

	*((long *)Address) = Real_Size;
	return(Address + 4);
}

Return_Block(Blk)
long Blk;
{	long Real_Size,Address;

	Address = Blk - 4;
	Real_Size = *((long *)Address);
	if( ERROR(lib$free_vm(&Real_Size,&Address)) )
		Signal_Error(ERR_MEM);
	return(NULL);
}
