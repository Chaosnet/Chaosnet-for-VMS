/* -*- Mode: CC -*- */

/*
 *	Namespace timestamp server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services timestamp network server
 */


#include <stdio.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"
#include "chaos$library:chaos.h"

/*
 * Define global and external variables
 */
extern char *Namespace;				/* namespace we are handling */
extern long *Shared_Timestamp;		/* globally shared timestamp */


/*
 * Return the current timestamp
 */
main()
{	long Conn;
	struct Descrp RFC_Descr;
	int RFC_Len;
	char RFC_Buf[PKT_MAX_NBYTES];
	char Reply[PKT_MAX_NBYTES];
	char *Contact_Name = "NAMESPACE-TIMESTAMP";
	register char *cp;

	/*
	 * Establish the connection and get the namespace name
	 */
	RFC_Descr.Ptr = RFC_Buf;
	RFC_Descr.Size = PKT_MAX_NBYTES;
	chaos_lsn(&Conn,Descr(Contact_Name),Seconds(RFC_TIMER));
	chaos_state(Conn);
	if( (state_of_conn(Conn) & 0377) != CONN_ST_RFCRCV ) exit();
	chaos_accept(Conn,7,&RFC_Descr,&RFC_Len);
	chaos_state(Conn);
	if( (state_of_conn(Conn) & 0377) != CONN_ST_OPEN ) exit();
	cp = (char *)((long)RFC_Buf + RFC_Len);
	*cp = NULL;
	Namespace = RFC_Buf;

	/*
	 * Ensure that this is our namespace, then get the timestamp
	 * and return it to the requester
	 */
	Initialize_Namespace_Server();
	sprintf(Reply,"%d%c",*Shared_Timestamp,NEWLINE);
	chaos_ans(Conn,Descr(Reply),0);
	Unmap_Global_Section(TRUE);
	exit();
}

