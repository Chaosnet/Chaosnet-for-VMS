/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services cache initialization program
 */


#include <stdio.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"
	
/*
 * Define global and external variables
 */
char Buf[REC_SIZE-REC_OVHD];			/* one large input buffer */
struct Descrp Buf_Descr;

extern char *Namespace;				/* namespace we are handling */
extern struct Object_Hdr ***Object_Cache;	/* address of object cache heads */
extern int Cache_Flags;				/* flags to set upon cacheing */
extern int Dont_Cache;				/* don't cache for the time being */
extern int Dont_Decache;			/* don't decache for the time being */
extern int Cache_Everything;			/* bit map of classes to be cached */


/*
 * Create the object cache as a global section, and fill in the
 * "permanent" part with commonly-used objects
 */
main(argc,argv)
int argc;
char **argv;
{	int Count;

	/*
	 * Get the name of the namespace from the arglist
	 */
	if( argc != 2 )
	{	fprintf(stderr,"You must specify a single namespace\n");
		exit();
	}
	Namespace = *++argv;
	fprintf(stderr,"Assuming namespace system is inactive\n\n");
	Unmap_Global_Section(TRUE);
	Delete_Global_Section();
	Count = Process_Cache_Request();
	fprintf(stderr,"Namespace cache initialized - cached %d objects\n",
		Count);
	Unmap_Global_Section(TRUE);
	exit();
}

/*
 * Do the work of initialization
 */
Process_Cache_Request()
{	long Status;
	char Filename[255];
	FILE *cs;
	char Classname[NAME_SIZE],Name[NAME_SIZE];
	char Line[CHANGES_SIZE];
	char Class;
	unsigned long Seq;
	long Time;
	register char *cp;
	register struct Object_Hdr *Obj;
	int Count = 0;
	int Saved_CE;

	int Get_Char_From_Buf();
	char Parse_Class();
	struct Object_Hdr *Find_Object_Named();
	struct Object_Hdr *Parse_Record();

	/*
	 * Create the cache's global section
	 */
	Cache_Flags = OFLG_PERMANENT;
	Status = Map_Global_Section(TRUE);
	if( ERROR(Status) )
	{	fprintf(stderr,"Couldn't create cache section, error 0x%X\n",Status);
		exit();
	}
	Initialize_Namespace_Server();

	/*
	 * Open the cache specification file, read it in line-by-line,
	 * and cache each of the named objects
	 */
	sprintf(Filename,"CHAOS$DISK:[CHAOS.NAMESPACE.%s]NAMECACHE.TXT",
		Namespace);
	if( !(cs = fopen(Filename,"r")) )
	{	fprintf(stderr,"Can't open the cache specification file\n");
		exit();
	}

	/*
	 * Cache classes given by Cache_Everything
	 */
	Dont_Decache = TRUE;
	for( Class = CLASS_NAMESPACE; Class < NCLASSES; Class++ )
	{	if( Cache_Everything & BIT(Class) )
		{	Rewind_File(Class,OBJECT_SEQ);
			while( TRUE )
			{	Buf_Descr.Ptr = Buf;
				Buf_Descr.Size = sizeof(Buf);
				if( ERROR(Get_Next_Record(Class,OBJECT_SEQ,&Buf_Descr,&Seq,&Time)) )
					break;
				if( Sequence_Cached(Class,Seq) ) continue;
				Obj = Parse_Record(Get_Char_From_Buf);
				if( Obj ) 
				{	if( Cache_Object(Obj,Seq,Time) ) Count++;
					else
					{	fprintf(stderr,"Cache full - quitting\n");
						Dont_Decache = FALSE;
						return(Count);
					}
					Deallocate_Object(Obj);
				}
			}
		}
	}

	/*
	 * Now cache what is explicitly specified
	 */
	Saved_CE = Cache_Everything;
	Cache_Everything = 0;
	while( TRUE )
	{	/*
		 * Get lines consisting of <class> <name> pairs
		 */
		if( fgets(Line,CHANGES_SIZE,cs) == NULL ) break;
		if( sscanf(Line,"%s %s",Classname,Name) != 2 ) break;
		Upper_Caseify(Classname);
		if( (Class = Parse_Class(Classname)) == -1 )
		{	fprintf(stderr,"Bad classname encountered - continuing\n");
			continue;
		}
		Upper_Caseify(Name);
		if( !(Obj = Find_Object_Named(Class,Name)) )
		{	fprintf(stderr,"Object %s %s not found - continuing\n",
				Classname,Name);
			continue;
		}
		Count++;
		Deallocate_Object(Obj);
	}
	Cache_Everything = Saved_CE;
	Dont_Decache = FALSE;
	return(Count);
}

/*
 * See if an object is already in the cache
 */
Sequence_Cached(Class,Sequence)
char Class;
register unsigned long Sequence;
{	register struct Object_Hdr *Obj;
	int Result = FALSE;

	Lock_Namespace(LOCK_CACHE);
	for( Obj = Object_Cache[Class]; Obj != NULL; Obj = Obj->Next )
	{	if( Obj->Sequence == Sequence )
		{	Result = TRUE;
			break;
		}
	}
	Unlock_Namespace(LOCK_CACHE);
	return(Result);
}

Get_Char_From_Buf()
{
	if( Buf_Descr.Size-- <= 0 ) return(-1);
	else return( (*(Buf_Descr.Ptr++)) & 0377 );
}

