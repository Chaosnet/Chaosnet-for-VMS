/* -*- Mode: CC -*- */

/*
 *	Namespace timestamp server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services test program
 */


#include <stdio.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"

#define NAME		0
#define PLIST		1
#define DELETE		2
#define CHANGE		3
#define BRIEF		4
#define FULL		5
#define MULTIPLE	6

/*
 * Define global and external variables
 */
struct Descrp Rec_Descr;
char Rec[REC_SIZE-REC_OVHD];
char Line[128];

extern char *Namespace;				/* namespace we are handling */
extern unsigned long *Shared_Sequence;		/* unique object sequence number */
extern long *Shared_Timestamp;			/* globally shared timestamp */
extern int Signalled_Error;			/* an error was signalled */
extern char *Classes[];				/* all class names */
extern int Dont_Cache;				/* don't cache for the time being */
extern int Dont_Decache;			/* don't decache for the time being */


/*
 * Grab a command and do its bidding
 */
main()
{	char Type[16];
	register char *cp;
	int T;

	Initialize_Namespace_Server();
	while( TRUE )
	{	printf("\nName, Delete, Plist, Multiple, Change, Brief, Full: ");
		if( gets(Line) == NULL ) break;
		if( sscanf(Line,"%s",Type) != 1 ) break;
		cp = Type;
		while( *cp )
		{	if( (*cp >= 'a') && (*cp <= 'z') )
				*cp = toupper(*cp);
			cp++;
		}
		T = NAME;
		if( Type[0] == 'N' ) T = NAME;
		else if( Type[0] == 'P' ) T = PLIST;
		else if( Type[0] == 'M' ) T = MULTIPLE;
		else if( Type[0] == 'D' ) T = DELETE;
		else if( Type[0] == 'C' ) T = CHANGE;
		else if( Type[0] == 'B' ) T = BRIEF;
		else if( Type[0] == 'F' ) T = FULL;
		else continue;
		Process_Test_Request(T);
	}
	Save_Sequence_Number(*Shared_Sequence);
	Save_Timestamp(*Shared_Timestamp);
	Unmap_Global_Section(TRUE);
	exit();
}


/*
 * Do the work of the test request
 */
Process_Test_Request(T)
int T;
{	register struct Object_Hdr *Object,*Properties;
	struct Object_Hdr *Obj;
	char Name[NAME_SIZE];
	char Class;
	register char *cp;
	register int i;
	int Hard_Way = FALSE;
	int Once = FALSE;
	register struct Change_Hdr *Change;
	struct Change_Hdr *Changes;
	register struct Change_List *List;
	struct Change_List *Lists;

	char Get_Class();
	char *Deparse_Object();
	char *Get_Incremental_Update();
	struct Object_Hdr *Find_Object_Named();
	struct Object_Hdr *Find_Object_From_Plist();
	struct Object_Hdr *Find_Objects_From_Plist();
	struct Object_Hdr *Change_Object_Named();
	struct Object_Hdr *Get_Properties();
	struct Change_List *Get_Updates();

	switch( T ) {
	case NAME:
Find_By_Name:
		if( !Get_Class_and_Name(&Class,Name) ) break;
		if( !(Object = Find_Object_Named(Class,Name)) )
		{	printf("Object not found\n");
			break;
		}
		printf("%d (%d)\n%s",
		       Object->Timestamp,Object->Sequence,Deparse_Object(Object,TRUE));
		Deallocate_Object(Object);
		break;
	case DELETE:
Delete_By_Name:
		if( !Get_Class_and_Name(&Class,Name) ) break;
		Delete_Object_Named(Class,Name,"Zippy");
		if( Signalled_Error )
			printf("Couldn't delete the object\n");
		break;
	case PLIST:
Find_By_Plist:
		if( (Class = Get_Class()) == -1 ) break;
		if( !(Properties = Get_Properties(Class)) ) break;
		if( !(Object = Find_Object_From_Plist(Class,Properties)) )
		{	printf("Object not found\n");
			break;
		}
		printf("%d (%d)\n%s",
		       Object->Timestamp,Object->Sequence,Deparse_Object(Object,TRUE));
		Deallocate_Object(Properties);
		Deallocate_Object(Object);
		break;
	case MULTIPLE:
Find_Multiple:
		printf("Do it the hard way? ");
		if( gets(Line) == NULL ) break;
		if( (Line[0] == 'y') || (Line[0] == 'Y') ) Hard_Way = TRUE;
		if( (Class = Get_Class()) == -1 ) break;
		if( !(Properties = Get_Properties(Class)) ) break;
		while( TRUE )
		{	if( !(Object = Find_Objects_From_Plist(Class,Properties,Once)) )
			{	if( !Once ) printf("No objects found\n");
				break;
			}
			Once = TRUE;
			if( Hard_Way )
			{	Obj = Find_Object_Named(Object->Class,Object->Name);
				printf("%d (%d)\n%s",
				       Object->Timestamp,Object->Sequence,
				       Deparse_Object(Object,TRUE));
				Deallocate_Object(Obj);
			}
			else
			{	printf("%d (%d)\n%s",
				       Object->Timestamp,Object->Sequence,
				       Deparse_Object(Object,TRUE));
			}
			Deallocate_Object(Object);
		}
		Deallocate_Object(Properties);
		break;
	case CHANGE:
Change_By_Name:
		if( !Get_Class_and_Name(&Class,Name) ) break;
		if( !(Properties = Get_Properties(Class)) ) break;
		if( !(Object = Change_Object_Named(Class,Name,Properties,"Zippy")) )
		{	printf("Object not changed\n");
			break;
		}
		printf("%d (%d)\n%s",
		       Object->Timestamp,Object->Sequence,Deparse_Object(Object,TRUE));
		Deallocate_Object(Properties);
		Deallocate_Object(Object);
		break;
	case BRIEF:
Brief_Updates:
		if( !(Lists = Get_Updates()) ) break;
		printf("TIMESTAMP %d\n",Lists->Timestamp);
		Changes = Merge_Deletions(Lists);
		for( Change = Changes; Change != NULL; Change = Change->Next )
		{	printf("%s %s\n",Classes[Change->Class],Change->Name);
		}
		printf("\n");
		Changes = Merge_Changes(Lists);
		for( Change = Changes; Change != NULL; Change = Change->Next )
		{	printf("%s %s\n",Classes[Change->Class],Change->Name);
		}
		printf("\n");
		Deallocate_Change_Lists(Lists);
		break;
	case FULL:
Full_Updates:
		if( !(Lists = Get_Updates()) ) break;
		Dont_Cache = TRUE;
		for( List = Lists; List != NULL; List = List->Next )
		{	printf("TIMESTAMP %d\n",List->Timestamp);
			for( Change = List->Deleted; Change != NULL; Change = Change->Next )
			{	printf("%s %s\n",Classes[Change->Class],Change->Name);
			}
			printf("\n");
			for( Change = List->Changed; Change != NULL; Change = Change->Next )
			{	if( !(Obj = Find_Object_Named(Change->Class,Change->Name)) )
					continue;
				printf("%s",Deparse_Object(Obj,TRUE));
				Deallocate_Object(Obj);
			}
			printf("\n");
		}
		printf("\n");
		Deallocate_Change_Lists(Lists);
		break;
	default:
		printf("What happened?\n");
		break;
	}
}


/*
 * Get a class and name from the user
 */
Get_Class_and_Name(Class,Name)
char *Class;
char *Name;
{	char Classname[NAME_SIZE];

	char Parse_Class();

	printf("\nClass and name: ");
	if( gets(Line) == NULL ) return(FALSE);
	if( sscanf(Line,"%s %s",Classname,Name) != 2 ) return(FALSE);
	Upper_Caseify(Classname);
	if( (*Class = Parse_Class(Classname)) == -1 )
	{	printf("Bad classname\n");
		return(FALSE);
	}
	Upper_Caseify(Name);
	return(TRUE);
}

/*
 * Get a class from the user
 */
char Get_Class()
{	char Classname[NAME_SIZE];
	char Class;

	char Parse_Class();

	printf("\nClass: ");
	if( gets(Line) == NULL ) return(-1);
	if( sscanf(Line,"%s",Classname) != 1 ) return(-1);
	Upper_Caseify(Classname);
	if( (Class = Parse_Class(Classname)) == -1 )
		printf("Bad classname\n");
	return(Class);
}

/*
 * Get a list of properties from the user
 */
struct Object_Hdr *Get_Properties(Class)
char Class;
{	register struct Token_Hdr *Tokens;
	register struct Object_Hdr *Properties;
	register char *cp;
	register int i;

	int Get_Char_From_Rec();
	struct Object_Hdr *Parse_Namespace_Record();
	struct Object_Hdr *Parse_Site_Record();
	struct Object_Hdr *Parse_Network_Record();
	struct Object_Hdr *Parse_Host_Record();
	struct Object_Hdr *Parse_Printer_Record();
	struct Object_Hdr *Parse_User_Record();
	struct Token_Hdr *Tokenize();

	cp = Rec;
	while( TRUE )
	{	printf("\nIndicator and values: ");
		if( gets(Line) == NULL ) break;
		if( Line[0] == 0 ) break;
		i = strlen(Line);
		Copy_Block(cp,i,Line,FALSE);
		cp += i;
		*cp++ = NEWLINE;
	}
	*cp++ = NEWLINE;
	*cp++ = NULL;
	Rec_Descr.Ptr = Rec;
	Rec_Descr.Size = strlen(Rec);
	if( !(Tokens = Tokenize(Get_Char_From_Rec)) )
	{	printf("Couldn't tokenize record\n");
		return(NULL);
	}
	switch( Class ) {
	case CLASS_NAMESPACE:
		Properties = Parse_Namespace_Record(Tokens,NULL);
	case CLASS_SITE:
		Properties = Parse_Site_Record(Tokens,NULL);
		break;
	case CLASS_NETWORK:
		Properties = Parse_Network_Record(Tokens,NULL);
		break;
	case CLASS_HOST:
		Properties = Parse_Host_Record(Tokens,NULL);
		break;
	case CLASS_PRINTER:
		Properties = Parse_Printer_Record(Tokens,NULL);
		break;
	case CLASS_USER:
		Properties = Parse_User_Record(Tokens,NULL);
		break;
	default:
		printf("What happened?\n");
		return(NULL);
		break;
	}
	if( Signalled_Error )
	{	Deallocate_Tokens(Tokens);
		printf("Couldn't parse properties\n");
		return(NULL);
	}
	return(Properties);
}

/*
 * Get a timestamp from the user, and return a list of updates
 */
struct Change_List *Get_Updates()
{	long Timestamp;

	struct Change_List *Get_Incremental_Updates();

	printf("\nTimestamp: ");
	if( gets(Line) == NULL ) return(NULL);
	if( sscanf(Line,"%ld",&Timestamp) != 1 ) return(NULL);
	return(Get_Incremental_Updates(Timestamp));
}

Get_Char_From_Rec()
{
	if( Rec_Descr.Size-- <= 0 ) return(-1);
	else return( (*(Rec_Descr.Ptr++)) & 0377 );
}

