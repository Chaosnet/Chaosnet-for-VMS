/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services network server
 */


#include <stdio.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"
#include "chaos$library:chaos.h"

/*
 * Define global and external variables
 */
long Conn = 0;					/* chaos connection */
int Protocol = -1;				/* requested protocol version */
int Namespace_Protocol = 2;			/* default protocol version */

extern char *Namespace;				/* namespace we are handling */
extern unsigned long *Shared_Sequence;		/* unique object sequence number */
extern long *Shared_Timestamp;			/* globally shared timestamp */
extern int Repository;				/* true if we are the primary server */
extern char *Classes[];				/* all class names */
extern int Signalled_Error;			/* an error was signalled */
extern char *Error_Messages[];			/* table of error messages */
extern int Dont_Cache;				/* don't cache for the time being */
extern int Dont_Decache;			/* don't decache for the time being */


/*
 * Establish network connection and call work routines
 */
main()
{	struct Descrp RFC_Descr;
	int RFC_Len;
	char RFC_Buf[PKT_MAX_NBYTES];
	char *Contact_Name = "NAMESPACE";

	/*
	 * Establish the connection
	 */
	RFC_Descr.Ptr = RFC_Buf;
	RFC_Descr.Size = PKT_MAX_NBYTES;
	chaos_lsn(&Conn,Descr(Contact_Name),Seconds(LSN_TIMER));
	chaos_state(Conn);
	if( (state_of_conn(Conn) & 0377) != CONN_ST_RFCRCV ) exit();
	chaos_accept(Conn,7,&RFC_Descr,&RFC_Len);
	chaos_state(Conn);
	if( (state_of_conn(Conn) & 0377) != CONN_ST_OPEN ) exit();

	/*
	 * Process namespace requests, then close shop
	 */
	Initialize_Namespace_Server();
	while( TRUE )
	{	chaos_state(Conn);
		if( (state_of_conn(Conn) & 0377) != CONN_ST_OPEN ) break;
		Process_Namespace_Request();
	}
	Save_Sequence_Number(*Shared_Sequence);
	Save_Timestamp(*Shared_Timestamp);
	chaos_close(Conn,Descr(""));
	Unmap_Global_Section(TRUE);
	exit();
}


/*
 * The namespace server proper.  This is the only procedure called
 * directly by a network user
 */
#define LOWEST_PROTOCOL		0
#define HIGHEST_PROTOCOL	2

Process_Namespace_Request()
{	struct Token_Hdr *Token,*Tokens;
	register struct Object_Hdr *Obj = NULL;
	register struct Object_Hdr *Object = NULL;
	char Response[2048];
	char Name[NAME_SIZE];
	register char *cp;
	register struct Change_Hdr *Change;
	struct Change_Hdr *Changes;
	register struct Change_List *List;
	struct Change_List *Lists;
	long Timestamp = 0;			/* timestamp, if supplied */
	char Class = CLASS_ANY;			/* class we want to operate over */
	char Obj_Name[NAME_SIZE];
	int Saw_Name = FALSE;			/* saw an object name */
	int Delete = FALSE;			/* delete record if true */
	char Update_Name[NAME_SIZE];		/* name of update-er */
	int Update_By = FALSE;
	int Names_Only = FALSE;
	int Saw_Protocol = FALSE;		/* saw PROTOCOL-VERSION */
	short Incremental = NO_UPDATE;		/* incremental update type */
	int Once = FALSE;

	int Get_Char_From_Net();
	char Parse_Class();
	char *Deparse_Object();
	struct Object_Hdr *Find_Object_Named();
	struct Object_Hdr *Find_Object_From_Plist();
	struct Object_Hdr *Find_Objects_From_Plist();
	struct Object_Hdr *Change_Object_Named();
	struct Object_Hdr *Parse_Namespace_Record();
	struct Object_Hdr *Parse_Site_Record();
	struct Object_Hdr *Parse_Network_Record();
	struct Object_Hdr *Parse_Host_Record();
	struct Object_Hdr *Parse_Printer_Record();
	struct Object_Hdr *Parse_User_Record();
	struct Token_Hdr *Get_Global_Name();
	struct Token_Hdr *Get_Name();
	struct Token_Hdr *Get_String();
	struct Token_Hdr *Tokenize();
	struct Change_List *Get_Incremental_Updates();

	/*
	 * Tokenize a stream from the network
	 */
	if( !(Tokens = Tokenize(Get_Char_From_Net)) )
	{	if( Signalled_Error ) goto Send_Error_Response;
			else return;
	}

	/*
	 * Get the "commands" from the token stream
	 */
	for( Token = Tokens; Token != NULL; Token = Tokens )
	{	if( Signalled_Error ) goto Send_Error_Response;
		Copy_Block(Name,Token->Length,Token->Name,TRUE);
		Upper_Caseify(Name);
		Tokens = Tokens->Next;
		Deallocate_Token(Token);
		if( !strcmp(Name,"PROTOCOL-VERSION") )
		{	Saw_Protocol = TRUE;
			if( (Token = Get_Name(&Tokens,CLASS_ANY)) )
			{	if( sscanf(Token->Name,"%ld",&Protocol) != 1 )
					Signal_Error(ERR_PROTOCOL);
			}
			else Signal_Error(ERR_PROTOCOL);
		}
		else if( !strcmp(Name,"NAMESPACE") )
		{	if( (Token = Get_Global_Name(&Tokens,CLASS_NAMESPACE)) )
				Namespace = Token->Name;
			else Signal_Error(ERR_NOSPACE);
		}
		else if( !strcmp(Name,"CLASS") )
		{	if( (Token = Get_Name(&Tokens,CLASS_A      





















































































































































ESTAMP); 		}t( 		else if( !strcmp(Name,"INCREMENTAL") )/ 		{	if( (Token = Get_Name(&Tokens,CLASS_ANY)) )d' 			{	if( !strcmp(Token->Name,"BRIEF") )   					Incremental = BRIEF_UPDATE;* 				else if( !strcmp(Token->Name,"FULL") ) 					Incremental = FULL_UPDATE;H 			}& 			else Signal_Error(ERR_INCREMENTAL); 		}j& 		else if( !strcmp(Name,"UPDATE-BY") )1 		{	if( (Token = Get_String(&Tokens,CLASS_ANY)) )N< 			{	Copy_Block(Update_Name,Token->Length,Token->Name,TRUE); 				Update_By = TRUE;e 			}$ 			else Signal_Error(ERR_UPDATE_BY); 		}t# 		else if( !strcmp(Name,"DELETE") )n/ 		{	if( (Token = Get_Name(&Tokens,CLASS_ANY)) ) 9 			{	Copy_Block(Obj_Name,Token->Length,Token->Name,TRUE);  				Saw_Name = TRUE; 				Delete = TRUE; 			} 			else Signal_Error(ERR_NAME);  		}t' 		else if( !strcmp(Name,"NAMES-ONLY") )u/ 		{	if( (Token = Get_Name(&Tokens,CLASS_ANY)) )p8 			{	if( !strcmp(Token->Name,"YES") ) Names_Only = TRUE;< 				else if( !strcmp(Token->Name,"NO") ) Names_Only = FALSE; 			}# 			else Signal_Error(ERR_T_OR_NIL);n 		}p! 		else if( !strcmp(Name,"NAME") ) / 		{	if( (Token = Get_Name(&Tokens,CLASS_ANY)) ) 9 			{	Copy_Block(Obj_Name,Token->Length,Token->Name,TRUE);a 				Saw_Name = TRUE; 			} 			else Signal_Error(ERR_NAME);c 		}e 		else& 		{	if( !(Token = Allocate_Token(Name,2 						     (TFLG_NAME | TFLG_SPACE | TFLG_BOL))) ) 				continue;_ 			Token->Next = Tokens; 			Tokens = Token;	 			break;r 		}b 	}$ 	/***what about untrusted hosts?***/   	/*t8 	 * Convert the rest of the tokens into a partial object 	 */ 	if( Saw_Name ) cp = Obj_Name; 	else cp = NULL; 	if( Class != CLASS_ANY )o 	{	switch( Class ) { 		case CLASS_NAMESPACE:s+ 			Obj = Parse_Namespace_Record(Tokens,cp);_ 		case CLASS_SITE:& 			Obj = Parse_Site_Record(Tokens,cp);	 			break;/ 		case CLASS_NETWORK:a) 			Obj = Parse_Network_Record(Tokens,cp);o	 			break;C 		case CLASS_HOST:& 			Obj = Parse_Host_Record(Tokens,cp);	 			break;	 		case CLASS_PRINTER:/) 			Obj = Parse_Printer_Record(Tokens,cp);t	 			break;  		case CLASS_USER:& 			Obj = Parse_User_Record(Tokens,cp);	 			break;d
 		default: 			Signal_Error(ERR_CLASSNAME);o 			goto Send_Error_Response;	 			break;  		}e 	}0 	if( Signalled_Error ) goto Send_Error_Response;   	/*nB 	 * The record has been parsed, so do the real work.  Make sure we! 	 * have a namespace to work with& 	 */ 	if( !Namespace ){ 	{	Signal_Error(ERR_NOSPACE);P 		goto Send_Error_Response;_ 	}   	/*R, 	 * Handle PROTOCOL-VERSION, if there is one 	 */ 	if( !Saw_Protocol )6 	{	if( Protocol == -1 ) Protocol = Namespace_Protocol; 	} 	elseCF 	{	if( (Protocol < LOWEST_PROTOCOL) || (Protocol > HIGHEST_PROTOCOL) ) 		{	Signal_Error(ERR_PROTOCOL);t 			goto Send_Error_Response; 		}n 		else/ 		{	sprintf(Response,"PROTOCOL-VERSION %d%c%c",s 				Protocol,NEWLINE,NEWLINE); 			goto Send_Response;		 		}	 	}   	/*t' 	 * Get incremental update of some sort= 	 */ 	if( Incremental )' 	{	if( Timestamp == *Shared_Timestamp ),4 		{	sprintf(Response,"CURRENT%c%c",NEWLINE,NEWLINE); 			goto Send_Response; 		}E- 		Lists = Get_Incremental_Updates(Timestamp);I& 		if( Signalled_Error == ERR_CHANGES )A 		{	sprintf(Response,"TOO-OLD %d%c%c",Timestamp,NEWLINE,NEWLINE);  			goto Send_Response; 		}T1 		if( Signalled_Error ) goto Send_Error_Response;	 		switch( Incremental ) {H 		case BRIEF_UPDATE:? 			sprintf(Response,"TIMESTAMP %d%c",Lists->Timestamp,NEWLINE);Y$ 			chaos_sout(Conn,Descr(Response));$ 			Changes = Merge_Deletions(Lists);A 			for( Change = Changes; Change != NULL; Change = Change->Next )   			{	sprintf(Response,"%s %s%c",2 					Classes[Change->Class],Change->Name,NEWLINE);% 				chaos_sout(Conn,Descr(Response));S 			}  			chaos_out_char(Conn,NEWLINE);" 			Changes = Merge_Changes(Lists);A 			for( Change = Changes; Change != NULL; Change = Change->Next )R  			{	sprintf(Response,"%s %s%c",2 					Classes[Change->Class],Change->Name,NEWLINE);% 				chaos_sout(Conn,Descr(Response));T 			}  			chaos_out_char(Conn,NEWLINE);" 			Deallocate_Change_Lists(Lists); 			goto Force_Response; 	 			break;s 		case FULL_UPDATE:O 			Dont_Cache = TRUE;i7 			for( List = Lists; List != NULL; List = List->Next )k@ 			{	sprintf(Response,"TIMESTAMP %d%c",List->Timestamp,NEWLINE);% 				chaos_sout(Conn,Descr(Response));}H 				for( Change = List->Deleted; Change != NULL; Change = Change->Next )! 				{	sprintf(Response,"%s %s%c",M3 						Classes[Change->Class],Change->Name,NEWLINE);k& 					chaos_sout(Conn,Descr(Response)); 				}k! 				chaos_out_char(Conn,NEWLINE);sH 				for( Change = List->Changed; Change != NULL; Change = Change->Next )B 				{	if( !(Obj = Find_Object_Named(Change->Class,Change->Name)) ) 						continue;N6 					sprintf(Response,"%s",Deparse_Object(Obj,FALSE));& 					chaos_sout(Conn,Descr(Response)); 					Deallocate_Object(Obj); 				}e! 				chaos_out_char(Conn,NEWLINE);/ 			}" 			Deallocate_Change_Lists(Lists); 			Dont_Cache = FALSE; 			goto Force_Response;A	 			break;	 		otherwise:! 			Signal_Error(ERR_INCREMENTAL);  			goto Send_Error_Response;	 			break;i 		}R 	}   	/*s- 	 * Either delete, or add or change an object= 	 */ 	else if( Delete || Update_By )k1 	{	if( !Obj->Name )		/* check for missing info */	 		{	Signal_Error(ERR_NOOBJ); 			goto Send_Error_Response; 		}E 		if( Class < 0 )r  		{	Signal_Error(ERR_CLASSNAME); 			goto Send_Error_Response; 		}w@ 		if( Delete ) Delete_Object_Named(Class,Obj->Name,Update_Name);< 		else Change_Object_Named(Class,Obj->Name,Obj,Update_Name);& 		sprintf(Response,"TIMESTAMP %d%c%c",& 			*Shared_Timestamp,NEWLINE,NEWLINE); 		goto Send_Response;{ 	}   	/*o6 	 * Find an object, either by name or by property list 	 */ 	elsel 	{	if( Class < 0 )  		{	Signal_Error(ERR_CLASSNAME); 			goto Send_Error_Response; 		} & 		if( (Protocol == 2) && !Repository )+ 		{	sprintf(Response,"VALID NO%c",NEWLINE);%$ 			chaos_sout(Conn,Descr(Response));2 			if( !Names_Only ) chaos_out_char(Conn,NEWLINE); 		}r 		while( TRUE ) 5 		{	Object = Find_Objects_From_Plist(Class,Obj,Once);= 			if( !Object ) 			{	if( Once ) break;" 				else goto Send_Error_Response; 			} 			Once = TRUE; ' 			if( Object->Timestamp >= Timestamp )i 			{	if( Names_Only )l4 				{	sprintf(Response,"%s%c",Object->Name,NEWLINE); 					cp = Response;, 				},+ 				else cp = Deparse_Object(Object,FALSE);f 				chaos_sout(Conn,Descr(cp));o 			} 			Deallocate_Object(Object); 0 			Object = NULL;		/* don't get nailed below! */ 		}P 		goto Force_Response; 	}   	/* . 	 * Send some kind of reply across the network 	 */ Send_Error_Response:% 	sprintf(Response,"ERROR %c%s%c%c%c",L? 		QUOTE,Error_Messages[Signalled_Error],QUOTE,NEWLINE,NEWLINE);	   Send_Response:" 	chaos_sout(Conn,Descr(Response));   Force_Response:( 	chaos_out_char(Conn,NEWLINE); 	chaos_force_out(Conn);C" 	if( Obj ) Deallocate_Object(Obj);( 	if( Object ) Deallocate_Object(Object); 	return; }N   /**  * Get a single character from the network  */C Get_Char_From_Net()>	 {	int ch;E  3 	if( ERROR(chaos_in_char(Conn,&ch,0)) ) return(-1);a 	else return(ch & 0377); }	  