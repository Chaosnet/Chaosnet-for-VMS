/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services file initialization program
 */


#include <stdio.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"

/*
 * Define global and external variables
 */
long Initial_Timestamp = 1;
int Seq = 0;
char Record[REC_SIZE-REC_OVHD];
struct Descrp Record_Descr;
int P_Counts[] = {0,0,0,0,0,0};
int S_Counts[] = {0,0,0,0,0,0};

extern char *Namespace;				/* namespace we are handling */
extern unsigned long *Shared_Sequence;		/* unique object sequence number */
extern long *Shared_Timestamp;			/* globally shared timestamp */
extern unsigned long Secondary_Names[];		/* other naming properties for objects */
extern char *Classes[];				/* all class names */
extern int Cache_Mapped;			/* true if cache is mapped in */
extern long Lock_Count[];			/* for multiple-use locks */
extern int Signalled_Error;			/* an error was signalled */
extern char *Error_Messages[];			/* table of error messages */


/*
 * Convert NAMESPACE.TXT into the permanent namespace files.  Note
 * that NAMESPACE.TXT is a text file created by HTMAKE.EXE (which also
 * creates the older HOSTS2 style tables).
 */
main(argc,argv)
int argc;
char **argv;
{
	/*
	 * Get the name of the namespace from the arglist
	 */
	if( argc != 2 )
	{	fprintf(stderr,"You must specify a single namespace\n");
		exit();
	}
	Namespace = *++argv;
	fprintf(stderr,"Assuming namespace system is inactive\n\n");
	Process_Build_Request();
	fprintf(stderr,"\nNamespace files initialized\n");
	exit();
}

/*
 * Do the work of building
 */
Process_Build_Request()
{	long Status;
	char Filename[255];
	FILE *cs;
	char Line[CHANGES_SIZE];
	register int i,j,cp;
	char Last_Class = CLASS_ANY;
	char Class;
	int eof = FALSE;
	char C[CHANGES_SIZE];
	struct Descrp D;

	/*
	 * Initialize the timestamp and the sequence number if necessary,
	 * then ensure all the other files are around
	 */
	Cache_Mapped = TRUE;			/* we don't need the cache */
	Shared_Sequence = &Seq;			/* now some horrible kludges... */
	Shared_Timestamp = &Initial_Timestamp;
	Get_Sequence_Number();
	Save_Sequence_Number(Seq);
	Get_Timestamp();
	Save_Timestamp(Initial_Timestamp);
	Initialize_Namespace_Server();		/* finally initialize the world */
	if( (*Shared_Timestamp != 1) || (*Shared_Sequence != 1) )
	{	fprintf(stderr,"Timestamp or sequence number does not have initial value\n");
		fprintf(stderr,"Please execute the NAMECREAT.COM command file\n");
		exit();
	}
	if( ERROR(Open_Namespace_File(CLASS_NAMESPACE)) ||
	    ERROR(Open_Namespace_File(CLASS_SITE)) ||
	    ERROR(Open_Namespace_File(CLASS_NETWORK)) ||
	    ERROR(Open_Namespace_File(CLASS_HOST)) ||
	    ERROR(Open_Namespace_File(CLASS_PRINTER)) ||
	    ERROR(Open_Namespace_File(CLASS_USER)) )
	{	fprintf(stderr,"Can't open one of the namespace index files\n");
		fprintf(stderr,"Please execute the NAMECREAT.COM command file\n");
		exit();
	}

	/*
	 * Open NAMESPACE.TXT and shove all its records into the correct
	 * namespace files
	 */
	sprintf(Filename,"CHAOS$DISK:[CHAOS.NAMESPACE.%s]NAMESPACE.TXT",
		Namespace);
	if( !(cs = fopen(Filename,"r")) )
	{	fprintf(stderr,"Can't open initial namespace spec file\n");
		exit();
	}
	Open_Log_File(TRUE);
	Close_Log_File();
	Open_Changes_File(TRUE);
	sprintf(C,"TIMESTAMP %d%c%c",Initial_Timestamp,NEWLINE,NEWLINE);
	D.Ptr = C;
	D.Size = strlen(C);
	Put_Changes_Record(&D);
	while( !eof )
	{	cp = 0;
		Record[0] = NULL;
		do
		{	
			if( fgets(Line,CHANGES_SIZE,cs) == NULL )
			{	eof = TRUE;
				b     






















































































































































rd_Descr.Ptr = Record; 		Record_Descr.Size = i;   		/*) 		 * We have a record, add it to the file  		 */* 		Class = Add_New_Object();h 		if( Signalled_Error )e
 		{	i = 0; 			while( i < cp ) 			{	j = i;e= 				while( (i < cp) && ((Record[i] & 0377) != NEWLINE) ) i++;  				Record[i++] = NULL;n& 				fprintf(stderr,"%s\n",&Record[j]); 			} 		} 5 		if( (Class != Last_Class) && (Class != CLASS_ANY) ) 2 		{	fprintf(stderr,"Adding objects of class %s\n", 				Classes[Class]); 		} . 		if( Class != CLASS_ANY ) Last_Class = Class; 	} 	Close_Changes_File(); 	fprintf(stderr,"\n");. 	for( i = CLASS_NAMESPACE; i < NCLASSES; i++ ) 	{	Close_Namespace_File(i);d@ 		fprintf(stderr,"Added %d objects of type %s (%d nicknames)\n",' 			P_Counts[i],Classes[i],S_Counts[i]);a 	} 	Save_Sequence_Number(Seq);a# 	Save_Timestamp(Initial_Timestamp); ' 	for( i = LOCK_CACHE; i < NLOCKS; i++ )  	{	Lock_Count[i] = 0;= 		Unlock_Namespace(i); 	} };   /*5  * Add a new object to the appropriate namespace filed  */s Add_New_Object()% {	register struct Object_Hdr *Object;e 	register struct Token_Hdr *T; 	register long Status; 	char *New_Object; 	struct Descrp D;n   	int Get_Char_From_Record(); 	char *Deparse_Object();& 	unsigned long Next_Sequence_Number();# 	struct Object_Hdr *Parse_Record();m   	/*)" 	 * First parse the record at hand 	 */- 	Object = Parse_Record(Get_Char_From_Record);r 	if( Signalled_Error )9 	{	fprintf(stderr,"Record did not parse - continuing\n");_9 		fprintf(stderr,"%s\n",Error_Messages[Signalled_Error]);n 		return(CLASS_ANY); 	}   	/*\C 	 * If not object, just exit, otherwise make sure it looks ok, and,\6 	 * if it does, add it and its aliases to the database 	 */! 	if( !Object ) return(CLASS_ANY);p= 	if( (Object->Required & Object->Given) != Object->Required )NF 	{	fprintf(stderr,"Record is missing required fields - continuing\n"); 		Signal_Error(ERR_REQUIRED);T 		return(CLASS_ANY); 	}+ 	Object->Sequence = Next_Sequence_Number();d' 	Object->Timestamp = *Shared_Timestamp;x+ 	New_Object = Deparse_Object(Object,FALSE);e 	D.Ptr = New_Object; 	D.Size = strlen(New_Object); 9 	Status = Put_Named_Record(Object->Class,Object->Name,&D,t* 				  Object->Sequence,Object->Timestamp); 	if( ERROR(Status) )D 	{	fprintf(stderr,"I/O error x%X during write of primary name %s\n", 			Status,Object->Name); 		return(CLASS_ANY); 	}  	else P_Counts[Object->Class]++;% 	if( Secondary_Names[Object->Class] )U4 	{	for( T = Object->Tokens; T != NULL; T = T->Next ); 		{	if( (Secondary_Names[Object->Class] & (1 << T->Type)) )N8 			{	Status = Put_Named_Record(Object->Class,T->Name,&D, 							  Object->Sequence, 							  Object->Timestamp); 				if( ERROR(Status) )s 					fprintf(stderr,4 						"I/O error x%X during write of nickname %s\n", 						Status,T->Name);# 				else S_Counts[Object->Class]++;/ 			} 		}r 	}  $ 	if( ERROR(Put_Changes_Record(&D)) )1 	{	fprintf(stderr,"I/O error to changes file\n");  		return(FALSE); 	} 	return(Object->Class);c })   /*%  * Get a single character from Recordc  */= Get_Char_From_Record() {=+ 	if( Record_Descr.Size-- <= 0 ) return(-1);	/ 	else return( (*(Record_Descr.Ptr++)) & 0377 );  }l