/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 * Namespace services indexed file dumper
 */


#include <stdio.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"
	
/*
 * Define global and external variables
 */
char Buf[REC_SIZE-REC_OVHD];			/* one large input buffer */
struct Descrp Buf_Descr;

extern char *Namespace;				/* namespace we are handling */
extern int Dont_Cache;				/* don't cache for the time being */
extern int Dont_Decache;			/* don't decache for the time being */


/*
 * Dump the indexed files out into a machine (and human) readable text file
 */
main(argc,argv)
int argc;
char **argv;
{	int Count;

	/*
	 * Get the name of the namespace from the arglist
	 */
	if( argc != 2 )
	{	fprintf(stderr,"You must specify a single namespace\n");
		exit();
	}
	Namespace = *++argv;
	fprintf(stderr,"Assuming namespace system is inactive\n\n");
	Process_Dump_Request();
	fprintf(stderr,"All namespace objects dumped to NAMEDUMP.TXT\n");
	exit();
}

/*
 * Do the work of dumping the indexed files
 */
Process_Dump_Request()
{	long Status;
	char Filename[255];
	FILE *cs;
	char Class;
	register struct Object_Hdr *Obj;
	unsigned long Seq,Last_Seq;
	long Time;

	int Get_Char_From_Buf();
	char Parse_Class();
	char *Deparse_Object();
	struct Object_Hdr *Parse_Record();

	/*
	 * Open up the output file
	 */
	Initialize_Namespace_Server();
	sprintf(Filename,"CHAOS$DISK:[CHAOS.NAMESPACE.%s]NAMEDUMP.TXT",
		Namespace);
	if( !(cs = fopen(Filename,"w")) )
	{	fprintf(stderr,"Can't open the new namespace text file\n");
		exit();
	}

	/*
	 * Dump the world
	 */
	Dont_Cache = TRUE;
	Last_Seq = 0;
	for( Class = CLASS_NAMESPACE; Class < NCLASSES; Class++ )
	{	Rewind_File(Class,OBJECT_SEQ);
		while( TRUE )
		{	Buf_Descr.Ptr = Buf;
			Buf_Descr.Size = sizeof(Buf);
			if( ERROR(Get_Next_Record(Class,OBJECT_SEQ,&Buf_Descr,&Seq,&Time)) )
				break;
			if( Seq == Last_Seq ) continue;
			Last_Seq = Seq;
			Obj = Parse_Record(Get_Char_From_Buf);
			if( Obj ) 
			{	fprintf(cs,"%s",Deparse_Object(Obj,TRUE));
				Deallocate_Object(Obj);
			}
		}
	}
	fclose(cs);
	Dont_Cache = FALSE;
}

Get_Char_From_Buf()
{
	if( Buf_Descr.Size-- <= 0 ) return(-1);
	else return( (*(Buf_Descr.Ptr++)) & 0377 );
}

