/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 *	Namespace services record parsing procedures
 */


#include <stdio.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"

/*
 * Define global and external variables
 */
unsigned long Secondary_Names[] =		/* other keys which name an object */
	{0,0,(1 << NICKNAME),((1 << NICKNAME) | (1 << SHORT_NAME)),0,0};

extern char *Namespace;				/* namespace we are handling */


/*
 * Parse a record and turn it into an object
 */
struct Object_Hdr *Parse_Record(Get_Char)
int (*Get_Char)();
{	register struct Object_Hdr *Object;
	register struct Token_Hdr *Token,*Tokens,*Name;
	register char Class = -1;

	char Parse_Class();
	struct Object_Hdr *Parse_Namespace_Record();
	struct Object_Hdr *Parse_Site_Record();
	struct Object_Hdr *Parse_Network_Record();
	struct Object_Hdr *Parse_Host_Record();
	struct Object_Hdr *Parse_Printer_Record();
	struct Object_Hdr *Parse_User_Record();
	struct Token_Hdr *Get_Global_Name();
	struct Token_Hdr *Get_Name();
	struct Token_Hdr *Get_String();
	struct Token_Hdr *Tokenize();

	/*
	 * Break the input stream into a series of tokens
	 */
	Clear_Error();
	if( !(Tokens = Tokenize(Get_Char)) ) return(NULL);

	/*
	 * First two tokens should be <class> <object-name>
	 */
	if( (Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
	{	if( (Token->Flags & TFLG_BOL) )
			Class = Parse_Class(Token->Name);
	}
	if( !(Name = Get_Name(&Tokens,CLASS_ANY)) )
	{	Signal_Error(ERR_NAME);
		return(NULL);
	}

	/*
	 * Dispatch on class type
	 */ 
	switch( Class ) {
	case CLASS_NAMESPACE:
		Object = Parse_Namespace_Record(Tokens,Name->Name);
		break;
	case CLASS_SITE:
		Object = Parse_Site_Record(Tokens,Name->Name);
		break;
	case CLASS_NETWORK:
		Object = Parse_Network_Record(Tokens,Name->Name);
		break;
	case CLASS_HOST:
		Object = Parse_Host_Record(Tokens,Name->Name);
		break;
	case CLASS_PRINTER:
		Object = Parse_Printer_Record(Tokens,Name->Name);
		break;
	case CLASS_USER:
		Object = Parse_User_Record(Tokens,Name->Name);
		break;
	default:
		Signal_Error(ERR_CLASSNAME);
		return(NULL);
		break;
	}

	return(Object);
}


/*
 * Parse a NAMESPACE record
 */
char *Namespace_Keywords[] =
	{"NAME",				/* global-name, internal */
	 "USER-PROPERTY",			/* element pair g-n token */
	 "PRIMARY-NAME-SERVER",			/* element host */
	 "SECONDARY-NAME-SERVER",		/* element host */
	 "SEARCH-RULES",			/* set namespace, required */
	 "DESCRIPTOR-FILE",			/* token, required */
	 "INTERNET-DOMAIN-NAME"};		/* token */
unsigned long Required_Namespace_Keys =
	(1 << SEARCH_RULES) | (1 << DESCRIPTOR_FILE);

struct Object_Hdr *Parse_Namespace_Record(Tokens,Name)
struct Token_Hdr *Tokens;			/* deallocates these */
char *Name;
{	register struct Object_Hdr *Object;
	register struct Token_Hdr *Token;
	struct Token_Hdr *T;
	register short Key;

	struct Object_Hdr *Allocate_Object_Header();
	struct Token_Hdr *Get_Global_Name();
	struct Token_Hdr *Get_Name();
	struct Token_Hdr *Get_String();
	long Get_Block();

	/*
	 * Loop over the record and build a namespace object
	 */
	if( !(Object = Allocate_Object_Header(CLASS_NAMESPACE,OFLG_GLOBAL,
					      Required_Namespace_Keys)) )
		return(NULL);
	if( Name )
	{	if( !(Object->Name = Get_Block(strlen(Name)+1)) )
			goto Flush_Tokens;
		Reduce_Qualifier(Name);
		Object->Length = strlen(Name);
		Copy_Block(Object->Name,Object->Length,Name,TRUE);
	}
	for( Token = Tokens; Token != NULL; Token = Tokens )
	{	Upper_Caseify(Token->Name);
		for( Key = NAME; Key < NAMESPACE_KEYCNT; Key++ )
			if( String_Eql(Token->Name,Token->Length,Namespace_Keywords[Key],
				       strlen(Namespace_Keywords[Key])) )
				break;
		if( !(Token->Flags & TFLG_BOL) )
		{	Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
		}
		T = Tokens;
		Tokens = Tokens->Next;
		Deallocate_Token(T);
		Object->Given |= (1 << Key);
		switch( Key ) {
		case NAME:	
			if( Object->Name )
			{	Signal_Error(ERR_NAME);
				goto Flush_Tokens;
			}
			if( !(Token = Get_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			if( !(Object->Name = Get_Block(Token->Length+1)) )
				goto Flush_Tokens;
			Reduce_Qualifier(Token->Name);
			Object->Length = strlen(Token->Name);
			Copy_Block(Object->Name,Object->Length,Token->Name,TRUE);
			break;
		case USER_PROPERTY:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case PRIMARY_NAME_SERVER:
		case SECONDARY_NAME_SERVER:
			if( !(Token = Get_Name(&Tokens,CLASS_HOST)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,(TFLG_ELEMENT | TFLG_BOL));
			break;
		case SEARCH_RULES:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_NAMESPACE)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,1,Object,(TFLG_SET | TFLG_BOL));
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_Global_Name(&Tokens,CLASS_NAMESPACE)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup++;
			}
			break;
		case DESCRIPTOR_FILE:
		case INTERNET_DOMAIN_NAME:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		default:
			Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
			break;
		}
	}
	return(Object);

	/*
	 * Exit here on error
	 */
Flush_Tokens:
	Deallocate_Tokens(Tokens);
	return(NULL);
}


/*
 * Parse a SITE record
 */
char *Site_Keywords[] =
	{"NAME",				/* global-name, internal */
	 "USER-PROPERTY",			/* element pair g-n token */
	 "PRETTY-NAME",				/* token */
	 "LOCAL-NAMESPACE",			/* namespace, required */
	 "SITE-DIRECTORY",			/* token, required */
	 "SITE-SYSTEM",				/* token */
	 "DEFAULT-PRINTER",			/* printer */
	 "DEFAULT-BITMAP-PRINTER",		/* printer */
	 "HOST-FOR-BUG-REPORTS",		/* host, required */
	 "TIMEZONE",				/* global-name, required */
	 "SECURE-SUBNETS",			/* element pair network set token */
	 "DONT-REPLY-TO-MAILING-LISTS",		/* set token */
	 "OTHER-SITES-IGNORED-IN-ZMAIL-SUMMARY",/* set site */
	 "STANDALONE",				/* token */
	 "VALIDATE-LMFS-DUMP-TAPES",		/* token */
	 "TERMINAL-F-ARGUMENT",			/* element triple token g-n set host */
	 "HOST-PROTOCOL-DESIRABILITY"};		/* element triple host g-n token */
unsigned long Required_Site_Keys =
	(1 << LOCAL_NAMESPACE) | (1 << SITE_DIRECTORY) |
	(1 << HOST_FOR_BUG_REPORTS) | (1 << TIMEZONE);

struct Object_Hdr *Parse_Site_Record(Tokens,Name)
struct Token_Hdr *Tokens;			/* deallocates these */
char *Name;
{	register struct Object_Hdr *Object;
	register struct Token_Hdr *Token;
	struct Token_Hdr *T;
	register short Key;

	struct Object_Hdr *Allocate_Object_Header();
	struct Token_Hdr *Get_Global_Name();
	struct Token_Hdr *Get_Name();
	struct Token_Hdr *Get_String();
	long Get_Block();

	/*
	 * Loop over the record and build a site object
	 */
	if( !(Object = Allocate_Object_Header(CLASS_SITE,OFLG_GLOBAL,Required_Site_Keys)) )
		return(NULL);
	if( Name )
	{	if( !(Object->Name = Get_Block(strlen(Name)+1)) )
			goto Flush_Tokens;
		Reduce_Qualifier(Name);
		Object->Length = strlen(Name);
		Copy_Block(Object->Name,Object->Length,Name,TRUE);
	}
	for( Token = Tokens; Token != NULL; Token = Tokens )
	{	Upper_Caseify(Token->Name);
		for( Key = NAME; Key < SITE_KEYCNT; Key++ )
			if( String_Eql(Token->Name,Token->Length,Site_Keywords[Key],
				       strlen(Site_Keywords[Key])) )
				break;
		if( !(Token->Flags & TFLG_BOL) )
		{	Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
		}
		T = Tokens;
		Tokens = Tokens->Next;
		Deallocate_Token(T);
		Object->Given |= (1 << Key);
		switch( Key ) {
		case NAME:
			if( Object->Name )
			{	Signal_Error(ERR_NAME);
				goto Flush_Tokens;
			}
			if( !(Token = Get_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			if( !(Object->Name = Get_Block(Token->Length+1)) )
				goto Flush_Tokens;
			Reduce_Qualifier(Token->Name);
			Object->Length = strlen(Token->Name);
			Copy_Block(Object->Name,Object->Length,Token->Name,TRUE);
			break;
		case TIMEZONE:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case USER_PROPERTY:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case PRETTY_NAME:
		case SITE_DIRECTORY:
		case SITE_SYSTEM:
		case STANDALONE:
		case VALIDATE_LMFS_DUMP_TAPES:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case LOCAL_NAMESPACE:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_NAMESPACE)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case DEFAULT_PRINTER:
		case DEFAULT_BITMAP_PRINTER:
			if( !(Token = Get_Name(&Tokens,CLASS_PRINTER)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case HOST_FOR_BUG_REPORTS:
			if( !(Token = Get_Name(&Tokens,CLASS_HOST)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case SECURE_SUBNETS:
			if( !(Token = Get_Name(&Tokens,CLASS_NETWORK)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_SET);
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_String(&Tokens)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup++;
			}
			break;
		case DONT_REPLY_TO_MAILING_LISTS:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,1,Object,(TFLG_SET | TFLG_BOL));
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_String(&Tokens)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup++;
			}
			break;
		case SITES_IGNORED_IN_ZMAIL_SUMMARY:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_SITE)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,1,Object,(TFLG_SET | TFLG_BOL));
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_Global_Name(&Tokens,CLASS_SITE)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup++;
			}
			break;
		case TERMINAL_F_ARGUMENT:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,3,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
			if( !(Token = Get_Name(&Tokens,CLASS_HOST)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_SET);
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_Name(&Tokens,CLASS_HOST)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup++;
			}
			break;
		case HOST_PROTOCOL_DESIRABILITY:
			if( !(Token = Get_Name(&Tokens,CLASS_HOST)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,3,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		default:
			Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
			break;
		}
	}
	return(Object);

	/*
	 * Exit here on error
	 */
Flush_Tokens:
	Deallocate_Tokens(Tokens);
	return(NULL);
}


/*
 * Parse a NETWORK record
 */
char *Network_Keywords[] =
	{"NAME",				/* name, internal */
	 "USER-PROPERTY",			/* element pair g-n token */
	 "",					/* unused */
	 "NICKNAME",				/* element name */
	 "SITE",				/* site */
	 "TYPE",				/* global-name, required */
	 "SUBNET"};				/* element pair token set pair g-n token */
unsigned long Required_Network_Keys =
	(1 << TYPE);

struct Object_Hdr *Parse_Network_Record(Tokens,Name)
struct Token_Hdr *Tokens;			/* deallocates these */
char *Name;
{	register struct Object_Hdr *Object;
	register struct Token_Hdr *Token;
	struct Token_Hdr *T;
	register short Key;

	struct Object_Hdr *Allocate_Object_Header();
	struct Token_Hdr *Get_Global_Name();
	struct Token_Hdr *Get_Name();
	struct Token_Hdr *Get_String();
	struct Token_Hdr *Allocate_Token();
	long Get_Block();

	/*
	 * Loop over the record and build a network object
	 */
	if( !(Object = Allocate_Object_Header(CLASS_NETWORK,0,Required_Network_Keys)) )
		return(NULL);
	if( Name )
	{	if( !(Object->Name = Get_Block(strlen(Name)+1)) )
			goto Flush_Tokens;
		Reduce_Qualifier(Name);
		Object->Length = strlen(Name);
		Copy_Block(Object->Name,Object->Length,Name,TRUE);
	}
	for( Token = Tokens; Token != NULL; Token = Tokens )
	{	Upper_Caseify(Token->Name);
		for( Key = NAME; Key < NETWORK_KEYCNT; Key++ )
			if( String_Eql(Token->Name,Token->Length,Network_Keywords[Key],
				       strlen(Network_Keywords[Key])) )
				break;
		if( !(Token->Flags & TFLG_BOL) )
		{	Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
		}
		T = Tokens;
		Tokens = Tokens->Next;
		Deallocate_Token(T);
		Object->Given |= (1 << Key);
		switch( Key ) {
		case NAME:
			if( Object->Name )
			{	Signal_Error(ERR_NAME);
				goto Flush_Tokens;
			}
			if( !(Token = Get_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			if( !(Object->Name = Get_Block(Token->Length+1)) )
				goto Flush_Tokens;
			Reduce_Qualifier(Token->Name);
			Object->Length = strlen(Token->Name);
			Copy_Block(Object->Name,Object->Length,Token->Name,TRUE);
			break;
		case USER_PROPERTY:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case NICKNAME:
			if( !(Token = Get_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,(TFLG_ELEMENT | TFLG_BOL));
			T = Allocate_Token(Token->Name,0);
			Reduce_Qualifier(T->Name);
			T->Length = strlen(T->Name);
			if( Object->Other_Names ) T->Next = Object->Other_Names;
			Object->Other_Names = T;
			break;
		case SITE:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_SITE)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case TYPE:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case SUBNET:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,2,Object,TFLG_SET);
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				if( !(Token = Get_String(&Tokens)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup += 2;
			}
			break;
		default:
			Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
			break;
		}
	}
	return(Object);

	/*
	 * Exit here on error
	 */
Flush_Tokens:
	Deallocate_Tokens(Tokens);
	return(NULL);
}


/*
 * Parse a HOST record
 */
char *Host_Keywords[] =
	{"NAME",				/* name, internal */
	 "USER-PROPERTY",			/* element pair g-n token */
	 "PRETTY-NAME",				/* token */
	 "NICKNAME",				/* element name */
	 "SITE",				/* site */
	 "SHORT-NAME",				/* element name */
	 "MACHINE-TYPE",			/* global-name */
	 "SYSTEM-TYPE",				/* required */
	 "ADDRESS",				/* element pair network token */
	 "FINGER-LOCATION",			/* token */
	 "LOCATION",				/* pair token token */
	 "PRINTER",				/* printer */
	 "BITMAP-PRINTER",			/* printer */
	 "PRINT-SPOOLER-OPTIONS",		/* set pair global-name token */
	 "SPOOLED-PRINTER",			/* element pair printer set pair g-n token */
	 "SERVICE",				/* element triple g-n g-n g-n */
	 "SERVER-MACHINE",			/* token */
	 "FILE-CONTROL-LIFETIME",		/* token */
	 "DEFAULT-SECONDARY-NAME-SERVER",	/* token */
	 "PERIPHERAL"};				/* element pair g-n set pair g-n token */
unsigned long Required_Host_Keys =
	(1 << SYSTEM_TYPE);

struct Object_Hdr *Parse_Host_Record(Tokens,Name)
struct Token_Hdr *Tokens;			/* deallocates these */
char *Name;
{	register struct Object_Hdr *Object;
	register struct Token_Hdr *Token;
	struct Token_Hdr *T;
	register short Key;

	struct Object_Hdr *Allocate_Object_Header();
	struct Token_Hdr *Get_Global_Name();
	struct Token_Hdr *Get_Name();
	struct Token_Hdr *Get_String();
	struct Token_Hdr *Allocate_Token();
	long Get_Block();

	/*
	 * Loop over the record and build a host object
	 */
	if( !(Object = Allocate_Object_Header(CLASS_HOST,0,Required_Host_Keys)) )
		return(NULL);
	if( Name )
	{	if( !(Object->Name = Get_Block(strlen(Name)+1)) )
			goto Flush_Tokens;
		Reduce_Qualifier(Name);
		Object->Length = strlen(Name);
		Copy_Block(Object->Name,Object->Length,Name,TRUE);
	}
	for( Token = Tokens; Token != NULL; Token = Tokens )
	{	Upper_Caseify(Token->Name);
		for( Key = NAME; Key < HOST_KEYCNT; Key++ )
			if( String_Eql(Token->Name,Token->Length,Host_Keywords[Key],
				       strlen(Host_Keywords[Key])) )
				break;
		if( !(Token->Flags & TFLG_BOL) )
		{	Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
		}
		T = Tokens;
		Tokens = Tokens->Next;
		Deallocate_Token(T);
		Object->Given |= (1 << Key);
		switch( Key ) {
		case NAME:
			if( Object->Name )
			{	Signal_Error(ERR_NAME);
				goto Flush_Tokens;
			}
			if( !(Token = Get_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			if( !(Object->Name = Get_Block(Token->Length+1)) )
				goto Flush_Tokens;
			Reduce_Qualifier(Token->Name);
			Object->Length = strlen(Token->Name);
			Copy_Block(Object->Name,Object->Length,Token->Name,TRUE);
			break;
		case USER_PROPERTY:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case NICKNAME:
		case SHORT_NAME:
			if( !(Token = Get_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,(TFLG_ELEMENT | TFLG_BOL));
			T = Allocate_Token(Token->Name,0);
			Reduce_Qualifier(T->Name);
			T->Length = strlen(T->Name);
			if( Object->Other_Names ) T->Next = Object->Other_Names;
			Object->Other_Names = T;
			break;
		case MACHINE_TYPE:
		case SYSTEM_TYPE:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case PRETTY_NAME:
		case FINGER_LOCATION:
		case SERVER_MACHINE:
		case FILE_CONTROL_LIFETIME:
		case DEFAULT_SECONDARY_SERVER:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case SITE:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_SITE)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case ADDRESS:
			if( !(Token = Get_Name(&Tokens,CLASS_NETWORK)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,TFLG_BOL);
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case LOCATION:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,TFLG_BOL);
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case PRINTER:
		case BITMAP_PRINTER:
			if( !(Token = Get_Name(&Tokens,CLASS_PRINTER)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case PRINT_SPOOLER_OPTIONS:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,2,Object,TFLG_SET);
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				if( !(Token = Get_String(&Tokens)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup += 2;
			}
			break;
		case SPOOLED_PRINTER:
			if( !(Token = Get_Name(&Tokens,CLASS_PRINTER)) )
				goto Flush_Tokens;
			if( (Token->Flags & TFLG_SPACE) )
				Add_Token_To_Object(Token,Key,2,Object,
						    (TFLG_ELEMENT | TFLG_BOL));
			else
			{	Add_Token_To_Object(Token,Key,1,Object,
						    (TFLG_ELEMENT | TFLG_BOL));
				break;
			}
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,2,Object,TFLG_SET);
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				if( !(Token = Get_String(&Tokens)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup += 2;
			}
			break;
		case SERVICE:
			if                                 ns,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,3,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case PERIPHERAL:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,2,Object,TFLG_SET);
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				if( !(Token = Get_String(&Tokens)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup += 2;
			}
			break;
		default:
			Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
			break;
		}
	}
	return(Object);

	/*
	 * Exit here on error
	 */
Flush_Tokens:
	Deallocate_Tokens(Tokens);
	return(NULL);
}


/*
 * Parse a PRINTER record
 */
char *Printer_Keywords[] =
	{"NAME",				/* name, internal */
	 "USER-PROPERTY",			/* element pair g-n token */
	 "PRETTY-NAME",				/* token */
	 "FORMAT",				/* element global-name */
	 "SITE",				/* site */
	 "TYPE",				/* required */
	 "INTERFACE",				/* global-name */
	 "INTERFACE-OPTIONS",			/* global-name */
	 "HOST",				/* host */
	 "PROTOCOL",				/* element global-name */
	 "DEFAULT-FONT",			/* token */
	 "HEADER-FONT",				/* token */
	 "DPLT-LOGO",				/* global-name */
	 "CHARACTER-SIZE",			/* pair token token */
	 "PAGE-SIZE",				/* pair token token */
	 "FONTS-WIDTHS-FILE"};			/* token */
unsigned long Required_Printer_Keys =
	(1 << TYPE);

struct Object_Hdr *Parse_Printer_Record(Tokens,Name)
struct Token_Hdr *Tokens;			/* deallocates these */
char *Name;
{	register struct Object_Hdr *Object;
	register struct Token_Hdr *Token;
	struct Token_Hdr *T;
	register short Key;

	struct Object_Hdr *Allocate_Object_Header();
	struct Token_Hdr *Get_Global_Name();
	struct Token_Hdr *Get_Name();
	struct Token_Hdr *Get_String();
	long Get_Block();

	/*
	 * Loop over the record and build a printer object
	 */
	if( !(Object = Allocate_Object_Header(CLASS_PRINTER,0,Required_Printer_Keys)) )
		return(NULL);
	if( Name )
	{	if( !(Object->Name = Get_Block(strlen(Name)+1)) )
			goto Flush_Tokens;
		Reduce_Qualifier(Name);
		Object->Length = strlen(Name);
		Copy_Block(Object->Name,Object->Length,Name,TRUE);
	}
	for( Token = Tokens; Token != NULL; Token = Tokens )
	{	Upper_Caseify(Token->Name);
		for( Key = NAME; Key < PRINTER_KEYCNT; Key++ )
			if( String_Eql(Token->Name,Token->Length,Printer_Keywords[Key],
				       strlen(Printer_Keywords[Key])) )
				break;
		if( !(Token->Flags & TFLG_BOL) )
		{	Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
		}
		T = Tokens;
		Tokens = Tokens->Next;
		Deallocate_Token(T);
		Object->Given |= (1 << Key);
		switch( Key ) {
		case NAME:
			if( Object->Name )
			{	Signal_Error(ERR_NAME);
				goto Flush_Tokens;
			}
			if( !(Token = Get_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			if( !(Object->Name = Get_Block(Token->Length+1)) )
				goto Flush_Tokens;
			Reduce_Qualifier(Token->Name);
			Object->Length = strlen(Token->Name);
			Copy_Block(Object->Name,Object->Length,Token->Name,TRUE);
			break;
		case USER_PROPERTY:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case PRETTY_NAME:
		case DEFAULT_FONT:
		case HEADER_FONT:
		case FONTS_WIDTHS_FILE:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case TYPE:
		case INTERFACE:
		case DPLT_LOGO:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case FORMAT:
		case PROTOCOL:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,(TFLG_ELEMENT | TFLG_BOL));
			break;
		case SITE:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_SITE)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case INTERFACE_OPTIONS:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			T = Token;
			Add_Token_To_Object(Token,Key,2,Object,TFLG_SET);
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
			while( (Token->Flags & TFLG_SPACE) )
			{	if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				if( !(Token = Get_String(&Tokens)) )
					goto Flush_Tokens;
				Add_Token_To_Object(Token,Key,0,Object,TFLG_SET);
				T->Subgroup += 2;
			}
			break;
		case HOST:
			if( !(Token = Get_Name(&Tokens,CLASS_HOST)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case CHARACTER_SIZE:
		case PAGE_SIZE:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,TFLG_BOL);
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		default:
			Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
			break;
		}
	}
	return(Object);

	/*
	 * Exit here on error
	 */
Flush_Tokens:
	Deallocate_Tokens(Tokens);
	return(NULL);
}


/*
 * Parse a USER record
 */
char *User_Keywords[] =
	{"NAME",				/* name, internal */
	 "USER-PROPERTY",			/* element pair g-n token */
	 "PERSONAL-NAME",			/* token, required */
	 "NICKNAME",				/* token */
	 "LOGIN-NAME",				/* element pair token host */
	 "TYPE",				/* global name */
	 "LISPM-NAME",				/* token, required */
	 "WORK-ADDRESS",			/* token */
	 "WORK-PHONE",				/* token */
	 "HOME-ADDRESS",			/* token */
	 "HOME-PHONE",				/* token */
	 "HOME-HOST",				/* host, required */
	 "MAIL-ADDRESS",			/* pair token host, required */
	 "BIRTHDAY",				/* token */
	 "PROJECT",				/* token */
	 "SUPERVISOR",				/* token */
	 "AFFILIATION",				/* token */
	 "REMARKS"};				/* token */
unsigned long Required_User_Keys =
	(1 << PERSONAL_NAME) | (1 << LISPM_NAME) |
	(1 << HOME_HOST) | (1 << MAIL_ADDRESS);

struct Object_Hdr *Parse_User_Record(Tokens,Name)
struct Token_Hdr *Tokens;			/* deallocates these */
char *Name;
{	register struct Object_Hdr *Object;
	register struct Token_Hdr *Token;
	struct Token_Hdr *T;
	register short Key;

	struct Object_Hdr *Allocate_Object_Header();
	struct Token_Hdr *Get_Global_Name();
	struct Token_Hdr *Get_Name();
	struct Token_Hdr *Get_String();
	long Get_Block();

	/*
	 * Loop over the record and build a user object
	 */
	if( !(Object = Allocate_Object_Header(CLASS_USER,0,Required_User_Keys)) )
		return(NULL);
	if( Name )
	{	if( !(Object->Name = Get_Block(strlen(Name)+1)) )
			goto Flush_Tokens;
		Reduce_Qualifier(Name);
		Object->Length = strlen(Name);
		Copy_Block(Object->Name,Object->Length,Name,TRUE);
	}
	for( Token = Tokens; Token != NULL; Token = Tokens )
	{	Upper_Caseify(Token->Name);
		for( Key = NAME; Key < USER_KEYCNT; Key++ )
			if( String_Eql(Token->Name,Token->Length,User_Keywords[Key],
				       strlen(User_Keywords[Key])) )
				break;
		if( !(Token->Flags & TFLG_BOL) )
		{	Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
		}
		T = Tokens;
		Tokens = Tokens->Next;
		Deallocate_Token(T);
		Object->Given |= (1 << Key);
		switch( Key ) {
		case NAME:
			if( Object->Name )
			{	Signal_Error(ERR_NAME);
				goto Flush_Tokens;
			}
			if( !(Token = Get_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			if( !(Object->Name = Get_Block(Token->Length+1)) )
				goto Flush_Tokens;
			Reduce_Qualifier(Token->Name);
			Object->Length = strlen(Token->Name);
			Copy_Block(Object->Name,Object->Length,Token->Name,TRUE);
			break;
		case USER_PROPERTY:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case TYPE:
			if( !(Token = Get_Global_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case LOGIN_NAME:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,(TFLG_ELEMENT | TFLG_BOL));
			if( !(Token = Get_Name(&Tokens,CLASS_HOST)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case HOME_HOST:
			if( !(Token = Get_Name(&Tokens,CLASS_ANY)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		case MAIL_ADDRESS:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,2,Object,TFLG_BOL);
			if( !(Token = Get_Name(&Tokens,CLASS_HOST)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,0,Object,0);
			break;
		case PERSONAL_NAME:
		case NICKNAME:
		case LISPM_NAME:
		case WORK_ADDRESS:
		case WORK_PHONE:
		case HOME_ADDRESS:
		case HOME_PHONE:
		case BIRTHDAY:
		case PROJECT:
		case SUPERVISOR:
		case AFFILIATION:
		case REMARKS:
			if( !(Token = Get_String(&Tokens)) )
				goto Flush_Tokens;
			Add_Token_To_Object(Token,Key,1,Object,TFLG_BOL);
			break;
		default:
			Signal_Error(ERR_KEYWORD);
			goto Flush_Tokens;
			break;
		}
	}
	return(Object);

	/*
	 * Exit here on error
	 */
Flush_Tokens:
	Deallocate_Tokens(Tokens);
	return(NULL);
}


/*
 * Parse a class name, returning a class number
 */
char *Classes[NCLASSES] =
	{"NAMESPACE","SITE","NETWORK","HOST","PRINTER","USER"};
int Class_Lengths[NCLASSES] = {9,4,7,4,7,4};

char Parse_Class(Classname)
char *Classname;
{	register char Class;
	register int i;

	/*
	 * Search the classname table and return an index
	 */
	i = strlen(Classname);
	for( Class = CLASS_NAMESPACE; Class < NCLASSES; Class++ )
		if( String_Eql(Classname,strlen(Classname),
			       Classes[Class],Class_Lengths[Class]) )
			return(Class);
	Signal_Error(ERR_CLASSNAME);
	return(-1);				/* no match, return error */
}

/*
 * Take a qualified name and reduce it to canonical form
 */
Reduce_Qualifier(Name)
char *Name;
{	register int i;
	register char *cp;

	/*
	 * Try to find the name of our own namespace at the beginning of
	 * the name.  If it is there, strip it out.
	 */
	i = strlen(Namespace);
	cp = Locate_Char(Name,strlen(Name),'|');
	if( cp && String_Eql(Namespace,i,Name,(long)cp-(long)Name) )
		cp = (char *)((long)Name + i+1);
	else cp = Name;
	Copy_Block(Name,strlen(cp),cp,TRUE);
}


/*
 * Take an object and turn it back into an asciified record
 */
char **Keyword_Arrays[] =			/* awful, horrible C decls */
	{Namespace_Keywords,Site_Keywords,Network_Keywords,
	 Host_Keywords,Printer_Keywords,User_Keywords};

char *Deparse_Object(Object,For_Printing)
struct Object_Hdr *Object;
int For_Printing;
{	static char Deparsed_Object[REC_SIZE-REC_OVHD];
	char T[NAME_SIZE];
	register char *cp = Deparsed_Object;
	register char *cp1;
	register int i;
	register struct Token_Hdr *Token;
	int Output_Keyword = TRUE;

	/*
	 * Copy in the object name
	 */
	Clear_Error();
	i = Class_Lengths[Object->Class];
	Copy_Block(cp,i,Classes[Object->Class],FALSE);
	cp += i;
	*cp++ = SPACE;
	Copy_Block(cp,Object->Length,Object->Name,FALSE);
	cp += Object->Length;
	if( For_Printing )
	{	*cp++ = LF;
		*cp++ = CR;
	}
	else *cp++ = NEWLINE;

	/*
	 * Loop over all tokens in the object
	 */
	for( Token = Object->Tokens; Token != NULL; Token = Token->Next )
	{	if( Output_Keyword )		/* output keyword if we haven't */
		{	Output_Keyword = FALSE;
			i = strlen(Keyword_Arrays[Object->Class][Token->Type]);
			Copy_Block(cp,i,Keyword_Arrays[Object->Class][Token->Type],FALSE);
			cp += i;
			*cp++ = SPACE;
		}

		/*
		 * Output text of token, including any formatting characters,
		 * followed by a space or newline
		 */
		cp1 = Token->Name;
		while( *cp1 )
		{	if( (*cp1 & META_BIT) ) *cp++ = SLASH;
			*cp++ = (*cp1++ & ~META_BIT);
		}
		if( (Token->Flags & TFLG_SPACE) )
		{	*cp++ = SPACE;
		}
		else if( (Token->Flags & TFLG_NEWLINE) )
		{	if( For_Printing )
			{	*cp++ = LF;
				*cp++ = CR;
			}
			else *cp++ = NEWLINE;
			Output_Keyword = TRUE;
		}
		else if( (Token->Flags & TFLG_END) )
		{	*cp++ = NEWLINE;
			break;
		}
	}

	/*
	 * Add the final touches...
	 */
	if( For_Printing )
	{	*cp++ = LF;
		*cp++ = CR;
	}
	else *cp++ = NEWLINE;
	*cp++ = NULL;
	return(Deparsed_Object);
}


/*
 * Get a globally qualified name, updating token listhead
 */
struct Token_Hdr *Get_Global_Name(Tokens,Class)
struct Token_Hdr **Tokens;
char Class;
{	register struct Token_Hdr *T;

	/*
	 * Get the next token and ensure it's a global name
	 */
	if( (T = *Tokens) )
	{	*Tokens = (*Tokens)->Next;
		Upper_Caseify(T->Name);
		if( String_Eql(T->Name,T->Length,"*",1) )
			T->Flags |= (TFLG_WILD | TFLG_GLOBAL_NAME);
		if( !(T->Flags & (TFLG_NAME | TFLG_GLOBAL_NAME)) ||
		    Locate_Char(T->Name,T->Length,'|') )
		{	Deallocate_Token(T);
			Signal_Error(ERR_GLOBALNAME);
			return(NULL);
		}
		else
		{	T->Flags &= ~TFLG_NAME;
			T->Flags |= TFLG_GLOBAL_NAME;
			T->Class = Class;
		}
	}

	return(T);
}

/*
 * Get a name, updating token listhead
 */
struct Token_Hdr *Get_Name(Tokens,Class)
struct Token_Hdr **Tokens;
char Class;
{	register struct Token_Hdr *T;

	/*
	 * Get the next token and ensure it's a name
	 */
	if( (T = *Tokens) )
	{	*Tokens = (*Tokens)->Next;
		Upper_Caseify(T->Name);
		if( String_Eql(T->Name,T->Length,"*",1) )
			T->Flags |= (TFLG_WILD | TFLG_NAME);
		if( !(T->Flags & TFLG_NAME) )
		{	Deallocate_Token(T);
			Signal_Error(ERR_NAME);
			return(NULL);
		}
		else
		{	T->Flags &= ~TFLG_GLOBAL_NAME;
			T->Flags |= TFLG_NAME;
			T->Class = Class;
		}
	}

	return(T);
}

/*
 * Get a string, updating token listhead
 */
struct Token_Hdr *Get_String(Tokens)
struct Token_Hdr **Tokens;
{	register struct Token_Hdr *T;

	/*
	 * Get the next token and ensure it's a string
	 */
	if( (T = *Tokens) )
	{	*Tokens = (*Tokens)->Next;
		if( String_Eql(T->Name,T->Length,"*",1) )
			T->Flags |= (TFLG_WILD | TFLG_STRING);
		if( !(T->Flags & TFLG_STRING) )
		{	T->Flags &= ~(TFLG_NAME | TFLG_GLOBAL_NAME);
			T->Flags |= TFLG_STRING;
		}
		T->Class = CLASS_ANY;
	}

	return(T);
}


/*
 * Add a token into the object being built
 */
Add_Token_To_Object(Token,Type,Subgroup,Object,Flags)
struct Object_Hdr *Object;
struct Token_Hdr *Token;
unsigned short Flags,Type,Subgroup;
{	register struct Token_Hdr *T,*TL,*Temp;

	/*
	 * We want to add the tokens to the object in ascending order
	 * by the type of the token, and at the end of all previous
	 * occurrences of that type of token
	 */
	Token->Type = Type;			/* set in type and flags */
	Token->Flags &= ~TFLG_BOL;
	Token->Flags |= Flags;
	Token->Subgroup = Subgroup;
	TL = NULL;
	T = Object->Tokens;
	while( T )				/* get to right place in object */
	{	if( Type < T->Type ) break;	/*  i.e., ascending by type code */
		TL = T;
		T = T->Next;
	}
	if( !TL )				/* first item in list? */
	{	Temp = Object->Tokens;		/* yes - link in at head of list */
		Object->Tokens = Token;
	}
	else
	{	Temp = TL->Next;		/* no - link into middle of list */
		TL->Next = Token;
	}
	Token->Next = Temp;			/* preserve Next pointer */
}


/*
 * Convert a record in a character stream into a stream of tokens.  All
 * tokens have either TFLG_SPACE or TFLG_NEWLINE to indicate how they were
 * terminated.  In addition, TFLG_STRING is set if the token is inside
 * double-quotes.  Note that if the record consists only of comments and
 * blank lines, the returned token list is null.
 */
#define STATE_WHITE	0			/* reading whitespace */
#define STATE_NAME	1			/* reading a name */
#define STATE_STRING	2			/* reading a string */
#define STATE_SLASH	3			/* quote next character */
#define STATE_COMMENT	4			/* reading a comment */
#define STATE_END	5			/* end of record */

struct Token_Hdr *Tokenize(Get_Char)
int (*Get_Char)();
{	char Token[NAME_SIZE];
	struct Token_Hdr *T;
	struct Token_Hdr *TL = NULL;		/* link a new token here */
	struct Token_Hdr *Tokens = NULL;	/* head of token list */
	register short State = STATE_WHITE;
	register int ch,nch;			/* current and next char */
	register char *cp;
	short Flags,LFlags = 0;			/* current and last flags */
	short bol = TFLG_BOL;

	struct Token_Hdr *Allocate_Token();

	/*
	 * Loop 'til EOF or end of record
	 */
	Clear_Error();
	if( (nch = (*Get_Char)()) == -1) return(NULL);
	while( (State != STATE_END) )
	{	if( nch ) ch = nch;
		else ch = (*Get_Char)();
		nch = NULL;
		if( ch == -1 )			/* last char ==> signal eof */
		{	if( TL ) TL->Flags |= TFLG_END;
			break;
		}
		if( (ch == CR) || (ch == LF) ) ch = NEWLINE;
		switch( State ) {

		/*
		 * Skip whitespace until start of next token
		 */
		case STATE_WHITE:
			switch( ch ) {
			case SPACE:		/* ignore */
			case TAB:
				Flags = 0;
				break;
			case NEWLINE:		/* end of line or record */
				if( (LFlags & TFLG_NEWLINE) )
				{	State = STATE_END;
					if( TL ) TL->Flags |= TFLG_END;
				}
				if( TL )
				{	TL->Flags |= TFLG_NEWLINE;
					TL->Flags &= ~TFLG_SPACE;
					LFlags = TL->Flags;
				}
				Flags = 0;
				bol = TFLG_BOL;
				break;
			case QUOTE:		/* start of string */
				Flags = TFLG_STRING;
				cp = Token;
				*cp++ = ch;
				State = STATE_STRING;
				break;
			case SEMICOLON:		/* start of comment */
				State = STATE_COMMENT;
				break;
			default:		/* any other character ==> start of name */
				Flags = TFLG_NAME;
				cp = Token;
				*cp++ = ch;
				State = STATE_NAME;
				break;
			}
			break;

		/*
		 * Continue reading in a name
		 */
		case STATE_NAME:
			switch( ch ) {
			case SPACE:		/* end of name */
			case TAB:
				Flags |= TFLG_SPACE;
				State = STATE_WHITE;
				*cp++ = NULL;
				if( !(T = Allocate_Token(Token,(Flags | bol))) )
					goto Flush_Tokens;
				bol = 0;
				LFlags = Flags;
				if( TL ) TL->Next = T;
				else Tokens = T;
				TL = T;
				break;
			case NEWLINE:		/* end of name and line */
				Flags |= TFLG_NEWLINE;
				State = STATE_WHITE;
				*cp++ = NULL;
				if( !(T = Allocate_Token(Token,(Flags | bol))) )
					goto Flush_Tokens;
				bol = TFLG_BOL;
				LFlags = Flags;
				if( TL ) TL->Next = T;
				else Tokens = T;
				TL = T;
				break;
			case QUOTE:		/* end of name, start of string */
				Flags |= TFLG_SPACE;
				*cp++ = NULL;
				if( !(T = Allocate_Token(Token,(Flags | bol))) )
					goto Flush_Tokens;
				bol = 0;
				LFlags = Flags;
				if( TL ) TL->Next = T;
				else Tokens = T;
				TL = T;
				cp = Token;	/* start filling next token */
				*cp++ = ch;
				Flags = TFLG_STRING;
				State = STATE_STRING;
				break;
			default:		/* otherwise stash a character */
				*cp++ = ch;
				break;
			}
			break;

		/*
		 * Continue reading in a string
		 */		
		case STATE_STRING:
			switch( ch ) {
			case QUOTE:		/* end of string */
				*cp++ = ch;
				nch = (*Get_Char)();
				if( nch == -1 )
				{	Flags |= TFLG_END;
					State = STATE_END;
				}
				if( (nch == CR) || (nch == LF) ) nch = NEWLINE;
				if( nch == NEWLINE ) Flags |= TFLG_NEWLINE;
				else Flags |= TFLG_SPACE;
				State = STATE_WHITE;
				*cp++ = NULL;
				if( !(T = Allocate_Token(Token,(Flags | bol))) )
					goto Flush_Tokens;
				if( nch == NEWLINE )
				{	bol = TFLG_BOL;
					nch = NULL;
				}
				else bol = 0;
				LFlags = Flags;
				Flags = 0;
				if( TL ) TL->Next = T;
				else Tokens = T;
				TL = T;
				break;
			case SLASH:		/* quote next char */
			case BACKSLASH:
				State = STATE_SLASH;
				break;
			default:		/* otherwise stash a character */
				*cp++ = ch;
				break;
			}
			break;

		/*
		 * Stash a quoted character into a string
		 */
		case STATE_SLASH:
			*cp++ = (ch | META_BIT);
			State = STATE_STRING;
			break;

		/*
		 * Read comment until end of line
		 */
		case STATE_COMMENT:
			if( ch == NEWLINE )
			{	State = STATE_WHITE;
				bol = TFLG_BOL;
			}
			break;
		}
	}
	return(Tokens);

	/*
	 * Exit here if error
	 */
Flush_Tokens:
	Deallocate_Tokens(Tokens);
	return(NULL);
}


/*
 * Allocate a new token from user memory
 */
struct Token_Hdr *Allocate_Token(Name,Flags)
register char *Name;
unsigned short Flags;
{	register struct Token_Hdr *T;
	register char *m;
	register int i;

	long Get_Block();

	/*
	 * Allocate both header and token name in one fell swoop
	 */
	Clear_Error();
	i = strlen(Name);
	if( !(m = Get_Block(sizeof(struct Token_Hdr) + ((i+2) & ~1))) )
		return(NULL);
	T = (struct Token_Hdr *)m;		/* point to header */
	T->Type = 0;
	T->Flags = Flags;
	T->Class = CLASS_ANY;
	T->Subgroup = 0;
	T->Next = NULL;
	T->Length = i;
	sprintf(T->Name,"%s",Name);
	return(T);
}

/*
 * Deallocate a single token
 */
Deallocate_Token(Token)
register struct Token_Hdr *Token;
{
	Return_Block(Token);
}

/*
 * Deallocate a list of tokens, if it is not empty
 */
Deallocate_Tokens(Tokens)
register struct Token_Hdr *Tokens;
{	register struct Token_Hdr *T,*TN;


	T = Tokens;
	if( !T ) return;
	TN = T->Next;
	while( T )
	{	Deallocate_Token(T);
		T = TN;
		if( T ) TN = T->Next;
	}
}


/*
 * Allocate an object header
 */
struct Object_Hdr *Allocate_Object_Header(Class,Flags,Required)
char Class;
unsigned short Flags,Required;
{	register struct Object_Hdr *Object;

	long Get_Block();

	/*
	 * Allocate an object header, and initialize it
	 */
	Clear_Error();
	Object = (struct Object_Hdr *)Get_Block(sizeof(struct Object_Hdr));
	if( !Object )
		return(NULL);
	Object->Class = Class;
	Object->Flags = Flags;
	Object->Timestamp = 0;
	Object->LRU_Count = 0;
	Object->Sequence = 0;
	Object->Required = Required;
	Object->Given = 0;
	Object->Tokens = NULL;
	Object->Next = NULL;
	Object->Name = NULL;
	Object->Length = 0;
	Object->Other_Names = NULL;
	return(Object);
}

/*
 * Deallocate an object and all its tokens
 */
Deallocate_Object(Object)
struct Object_Hdr *Object;
{
	if( (Object->Flags & OFLG_CACHED) )
	{	Return_Shared_Block(Object);	/* free compressed object from cache */
	}
	else if( (Object->Flags & OFLG_COMPRESSED) )
	{	Return_Block(Object);		/* free compressed object */
	}
	else
	{	if( Object->Name ) Return_Block(Object->Name);
		Deallocate_Tokens(Object->Tokens);
		Deallocate_Tokens(Object->Other_Names);
		Return_Block(Object);		/* free uncompressed object */
	}
}

