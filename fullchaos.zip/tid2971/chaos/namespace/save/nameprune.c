/* -*- Mode: CC -*- */

/*
 *	Namespace server for VAX/VMS
 *
 *	Written by Scott McKay at SCRC
 *
 *	Copyright 1983,1984 by Symbolics, Inc.
 *
 */

/*
 * Namespace services change file "pruner"
 */


#include <stdio.h>
#include <fab.h>
#include <rab.h>
#include <rmsdef.h>
#include "chaos$srcdisk:[chaos.namespace]namespace.h"
	
/*
 * Define global and external variables
 */
extern char *Namespace;				/* namespace we are handling */
extern struct FAB Changes_Fab;
extern struct RAB Changes_Rab;
extern char Changes_Buf[];


/*
 * Prune junk from the changes file
 */
main(argc,argv)
int argc;
char **argv;
{	long Status;
	long Timestamp;

	/*
	 * Get the name of the namespace from the arglist
	 */
	if( argc != 3 )
	{	fprintf(stderr,"You must specify a namespace and a timestamp\n");
		exit();
	}
	Namespace = *++argv;
	if( (sscanf(*++argv,"%ld",&Timestamp) != 1) || Timestamp < 1 )
	{	fprintf(stderr,"Bad timestamp given\n");
		exit();
	} 
	fprintf(stderr,"Assuming namespace system is inactive\n\n");
	Status = Prune_Changes_File(Timestamp);
	if( ERROR(Status) )
		fprintf(stderr,"Error x%X pruning change file\n",Status);
	else fprintf(stderr,"Namespace changes file pruned from timestamp %d\n",
		     Timestamp);
	exit();
}

/*
 * Prune old changes from changes file
 */
Prune_Changes_File(Timestamp)
long Timestamp;
{	long Status,TS;
	struct FAB Fab;
	struct RAB Rab;
	char Filename[255];
	char Buf[CHANGES_SIZE];

	/*
	 * Position in the old file, and create a new one
	 */
	Status = Open_Changes_File(FALSE);
	if( ERROR(Status) ) return(Status);
	Position_Changes_File(Timestamp,&TS);
	sprintf(Filename,"CHAOS$DISK:[CHAOS.NAMESPACE.%s]CHANGES.TXT",Namespace);
	Fab = cc$rms_fab;
	Fab.fab$l_fna = Filename;
	Fab.fab$b_fns = strlen(Filename);
	Fab.fab$b_fac = (FAB$M_GET | FAB$M_PUT | FAB$M_DEL | FAB$M_UPD);
	Fab.fab$l_fop = (FAB$M_SQO);
	Rab = cc$rms_rab;
	Rab.rab$l_fab = &Fab;
	Fab.fab$b_org = FAB$C_SEQ;
	Fab.fab$b_rat = FAB$M_CR;
	Fab.fab$b_rfm = FAB$C_VAR;
	Fab.fab$w_mrs = CHANGES_SIZE;
	Status = sys$create(&Fab);
	if( !ERROR(Status) ) Status = sys$connect(&Rab);
	if( ERROR(Status) ) return(Status);

	/*
	 * Copy the remaining records after setting in the timestamp
	 * (note that the extra newline after the first timestamp will
	 * get copied in the loop)
	 */
	Rab.rab$b_rac = RAB$C_SEQ;
	sprintf(Buf,"TIMESTAMP %d",Timestamp);
	Rab.rab$l_rbf = Buf;
	Rab.rab$w_rsz = strlen(Buf);
	sys$put(&Rab);
	Rab.rab$l_rbf = Changes_Buf;
	Changes_Rab.rab$b_rac = RAB$C_SEQ;
	Changes_Rab.rab$l_ubf = Changes_Buf;
	Changes_Rab.rab$w_usz = CHANGES_SIZE;
	while( TRUE )
	{	Status = sys$get(&Changes_Rab);
		if( ERROR(Status) ) break;
		Rab.rab$w_rsz = Changes_Rab.rab$w_rsz;
		sys$put(&Rab);
	}
	if( ERROR(Status) && (Status != RMS$_EOF) )
		Fab.fab$l_fop |= FAB$M_DLT;
	else Status = RMS$_NORMAL;
	sys$close(&Fab);
	Close_Changes_File();
	return(Status);
}

