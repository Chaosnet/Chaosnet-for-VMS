/* -*- Mode: CC -*- */

/*
 *;;;>
 *;;;>******************************************************************************************
 *;;;>    This data and information is proprietary to, and a valuable trade
 *;;;>    secret of, Symbolics, INC.  It is given in confidence by Symbolics,
 *;;;>    and may only be used as permitted under the license agreement under
 *;;;>    which it has been distributed, and in no other way.
 *;;;>******************************************************************************************
 *;;;>
 *;;;> Copyright (c) 1982, 1983 by Symbolics, Inc.
 *;;;> ** (c) Copyright 1984 by Symbolics, Incorporated.  **
 *;;;>
 */

/*
 * Attach to another named process (only meaningful if this process
 * was started via a "spawn" command)
 * (stolen from TELUSR.C)
 */

#include <stdio.h>
#include <jpidef.h>

struct VMS_Descriptor {int size; char *ptr;};

#define NDESCRS	20
struct VMS_Descriptor *descr(String)
register char *String;
{
	static struct VMS_Descriptor VMS_Descriptors[NDESCRS];
	static int index = 0;
	register int size = 0;

	if( index==NDESCRS ) index = 0;
	VMS_Descriptors[index].ptr = String;
	while( *String++ ) size++;	/* no nulls inside strings! */
	VMS_Descriptors[index].size = size;
	return(&VMS_Descriptors[index++]);
}

supdup_suspend(father)
{
	int i;
	int status = 1;
	int att_pid = 0;
	char att_name[32];
	long jpi_items = 0;
	static struct {
		short	size;
		short	code;
		char	*buf;
		long	*buf_size;
		} item_list[2];

	if( father )
	{	item_list[0].size = 4;
		item_list[0].code = JPI$_OWNER;
		item_list[0].buf = &att_pid;
		item_list[0].buf_size = 0;
		item_list[1].size = 0;
		item_list[1].code = 0;
		status = sys$getjpi(0,0,0,item_list,0,0,0);
		if( !(status&1) ) goto att_ex;
	}
	else
	{	fprintf(stderr,"Process name: ");
		gets(att_name);
		if( att_name == NULL ) goto att_ex;
		status = sys$getjpi(1,&att_pid,descr(att_name),
				    &jpi_items,0,0,0);
		if( !(status&1) )
		{	for( i = 0; i < strlen(att_name); i++ )
				att_name[i] = toupper(att_name[i]);
			att_pid = 0;
			status = sys$getjpi(0,&att_pid,descr(att_name),
					    &jpi_items,0,0,0);
			if( !(status&1) ) goto att_ex;
		}
	}
	status = lib$attach(&att_pid);
att_ex:	if( !(status&1) )
	{	if( !father ) fprintf(stderr,"Cannot attach to process\n");
		else fprintf(stderr,"There is no superior process to attach to\n");
	}
}

