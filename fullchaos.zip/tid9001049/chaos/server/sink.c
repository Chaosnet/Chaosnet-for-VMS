/*
 *;;;>
 *;;;>******************************************************************************************
 *;;;>    This data and information is proprietary to, and a valuable trade
 *;;;>    secret of, Symbolics, INC.  It is given in confidence by Symbolics,
 *;;;>    and may only be used as permitted under the license agreement under
 *;;;>    which it has been distributed, and in no other way.
 *;;;>******************************************************************************************
 *;;;>
 *;;;> Copyright (c) 1983 by Symbolics, Inc.
 *;;;> ** (c) Copyright 1984 by Symbolics, Incorporated.  **
 *;;;>
 */

/*
 *	Chaos SINK Server
 *	Written by Scott McKay at SCRC
 */

/*
 *  Utility routines for talking to Chaosnet
 */

int *seconds(n)
{
	static int secs[2] = {-1,-1};

	secs[0] = (-10*1000*1000)*n;
	return(secs);
}


struct VMS_Descriptor {int size; char *ptr;};

#define NDESCRS	20
struct VMS_Descriptor *descr(String)
register char *String;
{
	static struct VMS_Descriptor VMS_Descriptors[NDESCRS];
	static int index = 0;
	register int size = 0;

	if (index==NDESCRS) index = 0;
	VMS_Descriptors[index].ptr = String;
	while (*String++) size++;
	VMS_Descriptors[index].size = size;
	return(&VMS_Descriptors[index++]);
}


#include "chaos$library:chaos.h"

#define BANNER	"\r\nVAX/VMS Chaos SINK server V3.0"

#define LSN_TIMER	300		/* timeout for chaos_lsn */

#define	CHAOS_EFN_S	23		/* event flags */

int chaos_conn;				/* chaos connection */
static struct CHAOSNET_DATA_PACKET *packet = 0;

main()
{
	struct {int size; char *ptr;} pkt_descr;
	struct {int size; char *ptr;} rfc_descr;
	int rfc_len;
	char rfc_buf[256];

/*
 * Listen and open a Chaos connection
 */
	rfc_descr.size = 256;
	rfc_descr.ptr = rfc_buf;
	chaos_lsn(&chaos_conn,descr("SINK  "),seconds(LSN_TIMER));
	chaos_state(chaos_conn);
	if ((state_of_conn(chaos_conn)&0377)!=CONN_ST_RFCRCV) {
		exit(0);
	}
	chaos_accept(chaos_conn,15,&rfc_descr,&rfc_len);
	chaos_state(chaos_conn);
	if ((state_of_conn(chaos_conn)&0377)!=CONN_ST_OPEN) {
		exit(0);
	}
	chaos_sout(chaos_conn,descr(BANNER));
	chaos_force_out(chaos_conn);

	if (!(chaos_pkt(&packet)&1)) {	/* allocate a packet */
		chaos_close(chaos_conn,
			    descr("Error allocating Chaos packet\r\n"));
		exit(0);
	}

/*
 * Just read and toss out packets from Chaos
 */
	while (1) {
		chaos_get_pkt(chaos_conn,packet,0,0,0);
		if (!(packet->Pkt_IOSB_Status&1)) {
			chaos_close(chaos_conn,
				    descr("Network I/O error\r\n"));
			exit(0);
		}
		if ((packet->Pkt_Opcode==PKT_OP_LOS) ||
		    (packet->Pkt_Opcode==PKT_OP_CLS) ||
		    (packet->Pkt_Opcode==PKT_OP_EOF)) {
			chaos_close(chaos_conn,
				    descr("Connection lost or closed by NCP\r\n"));
			exit(0);
		}
	}
}

