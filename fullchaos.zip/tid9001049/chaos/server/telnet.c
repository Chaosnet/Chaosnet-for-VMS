/* -*- Mode: CC -*- */

/*
 *;;;>
 *;;;>******************************************************************************************
 *;;;>    This data and information is proprietary to, and a valuable trade
 *;;;>    secret of, Symbolics, INC.  It is given in confidence by Symbolics,
 *;;;>    and may only be used as permitted under the license agreement under
 *;;;>    which it has been distributed, and in no other way.
 *;;;>******************************************************************************************
 *;;;>
 *;;;> Copyright (c) 1983 by Symbolics, Inc.
 *;;;> ** (c) Copyright 1984 by Symbolics, Incorporated.  **
 *;;;>
 */

/*
 *	Chaos TELNET Server
 *	Written by Scott McKay at SCRC
 */

/*
 *  Utility routines for talking to Chaosnet
 */

int *seconds(n)
{
	static int secs[2] = {-1,-1};

	secs[0] = (-10*1000*1000)*n;
	return(secs);
}


struct VMS_Descriptor {int size; char *ptr;};

#define NDESCRS	20
struct VMS_Descriptor *descr(String)
register char *String;
{
	static struct VMS_Descriptor VMS_Descriptors[NDESCRS];
	static int index = 0;
	register int size = 0;

	if( index==NDESCRS ) index = 0;
	VMS_Descriptors[index].ptr = String;
	while( *String++ ) size++;	/* no nulls inside strings! */
	VMS_Descriptors[index].size = size;
	return(&VMS_Descriptors[index++]);
}


#include <stdio.h>
#include <dvidef.h>
#include <iodef.h>
#include <jpidef.h>
#include <syscalls.h>
#include <ttdef.h>
#include "chaos$library:chaos.h"

#define BANNER	"\r\nVAX/VMS Chaos TELNET server V3.0\r\n"

#define	PTY1		0		/* lowest PTY */
#define	PTYN		15		/* highest PTY */

#define LSN_TIMER	300		/* timeout for chaos_lsn */

#define	CHAOS_EFN_A	23		/* event flags */
#define	CHAOS_EFN_S	22
#define	PTY_EFN_A	21
#define	PTY_EFN_S	20
#define	MBX_EFN_A	19
#define GEN_EFN		18

/*
 * TELNET protocol command characters
 */
#define	SE		240		/* end of subnegotiation params */
#define	NOP		241
#define	DMARK		242		/* data stream part of a synch */
#define	BRK		243		/* break key hit */
#define	IP		244		/* interrupt process */
#define	AO		245		/* abort output */
#define	AYT		246		/* are you there? */
#define	EC		247		/* erase character */
#define	EL		248		/* erase line */
#define	GA		249		/* goahead */
#define	SB		250		/* subnegotiation follows */
#define	WILL		251
#define	WONT		252
#define	DO		253
#define	DONT		254
#define	IAC		255		/* interpret as command */

/*
 * TELNET option codes
 */
#define	TN_TRNBIN	0		/* transmit binary (&3 -> 0) */
#define	TN_ECHO		1		/* echo (&3 -> 1) */
#define	TN_SUPGO	3		/* suppress goahead (&3 -> 3) */
#define	TN_TIMMRK	6		/* timing mark (&3 -> 2) */

#define pty_out(c) pty_obuf[pty_ocnt++] = c

int pty_chan,mbx_chan;			/* random vms channels */
int conn;				/* chaos connection */
int hisopts[4],myopts[4];		/* TELNET options */
int goahead = 1;
int verbose = 0;
char pty_obuf[512];			/* PTY output buffer */
int pty_ocnt;				/*  for efficiency */
static struct CHAOSNET_DATA_PACKET *packet = 0;
static int bytes_left = 0;
static char *data_ptr = 0;

main()
{
        int status,i;
	unsigned short pty_iosb[4];
	char pty_buf[512],mbx_buf[256];
	struct {int size; char *ptr;} pkt_descr;
	struct {int size; char *ptr;} rfc_descr;
	int rfc_len;
	char rfc_buf[256];
	char goahead_signal[8];
	long exit_blk[4],exit_reason;
	int pid = 0;
	static struct {
		short	size;
		short	code;
		char	*buf;
		long	*buf_size;
		} item_list[2];
	extern chaos_ast(),mbx_ast(),kill_process();

	/*
	 * Listen and open a Chaos connection
	 */
	for( i = 0; i < 4; i++ )
	{	hisopts[i] = 0;
		myopts[i] = 0;
	}
	if( verbose ) fprintf(stderr,"Chaos TELNET started\n");
	rfc_descr.size = 256;
	rfc_descr.ptr = rfc_buf;
	chaos_lsn(&conn,descr("TELNET"),seconds(LSN_TIMER));
	chaos_state(conn);
	if( (state_of_conn(conn)&0377) != CONN_ST_RFCRCV )
	{	if( verbose ) fprintf(stderr,"Not in RFC state\n");
		exit(0);
	}
	chaos_accept(conn,15,&rfc_descr,&rfc_len);
	chaos_state(conn);
	if( (state_of_conn(conn)&0377) != CONN_ST_OPEN )
	{	if( verbose ) fprintf(stderr,"Chaosnet didn't open\n");
		exit(0);
	}
	if( verbose ) fprintf(stderr,"Chaos connection opened OK\n");
	chaos_sout(conn,descr(BANNER));
	chaos_force_out(conn);

	/*
	 *	Try to allocate a PTY and an associated termination MBX
	 */
	item_list[0].size = 4;
	item_list[0].code = JPI$_PID;
	item_list[0].buf = &pid;
	item_list[0].buf_size = 0;
	item_list[1].size = 0;
	item_list[1].code = 0;
	status = sys$getjpi(0,0,0,item_list,0,0,0);
	for( i = PTY1; i <= PTYN; i++ )
	{	char pty_name[64];
		char mbx_name[64];
		sprintf(mbx_name,"SPT%X_%d",pid,i);
		sprintf(pty_name,"_PYA%d",i);
		status = sys$crembx(0,&mbx_chan,512,0,0,3,
				    descr(mbx_name));
		if( !(status&1) ) continue;
		status = sys$assign(descr(pty_name),&pty_chan,3,
				    descr(mbx_name));
		if( status&1 ) break;
	}
	if( !(status&1) )
	{	chaos_close(conn,
			    descr("No free PTY's - try again later\n"));
		if( verbose ) fprintf(stderr,"No free PTY's %x\n",status);
		exit(0);
	}

	/*
	 * We have a PTY and a connection - allocate a packet, start
	 * Chaos input, set sane TELNET characteristics, and go!
	 */
	sprintf(goahead_signal,"%c%c",IAC,GA);
	status = sys$qio(MBX_EFN_A,mbx_chan,IO$_READVBLK,0,mbx_ast,0,
			 mbx_buf,256,0,0,0,0);
	if( !(status&1) )
	{	chaos_close(conn,
			    descr("Mailbox I/O error\n"));
		if( verbose ) fprintf(stderr,"Mailbox read error %x\n",status);
		exit(0);
	}
	if( !(chaos_pkt(&packet)&1) )	/* allocate a packet */
	{	chaos_close(conn,
			    descr("Error allocating Chaos packet\n"));
		if( verbose ) fprintf(stderr,"Couldn't allocate a packet\n");
		exit(0);
	}
	exit_blk[0] = 0;
	exit_blk[1] = kill_process;
	exit_blk[2] = 0;
	exit_blk[3] = &exit_reason;
	status = sys$dclexh(&exit_blk);
	if( !(status&1) )
	{	if( verbose ) fprintf(stderr,"Couldn't establish exit handler");
		exit(0);
	}
	set_pty_mode(TT$M_EIGHTBIT,(TT$M_NOBRDCST|TT$M_NOECHO));
	send_option(WILL,TN_ECHO,0);
	send_option(DO  ,TN_TRNBIN,0);
	send_option(WILL,TN_TRNBIN,0);
	send_option(DO  ,TN_SUPGO,0);
	send_option(WILL,TN_SUPGO,1);
	if( verbose ) fprintf(stderr,"On our way\n");
	chaos_asyn_in(conn,packet,CHAOS_EFN_A,chaos_ast,0);
	sleep(1);			/* cheap wait for completion */

	/*
	 * Main loop - read from PTY, put to network
	 */
	while( 1 )
	{	if( goahead != 0 && myopts[TN_SUPGO&3] == 0 )
		{	chaos_sout(conn,descr(goahead_signal));
			goahead = 0;
		}
		sys$qiow(PTY_EFN_S,pty_chan,IO$_READVBLK,pty_iosb,0,0,
			 pty_buf,512,0,0,0,0);
		if( !(pty_iosb[0]&1) )
		{	chaos_close(conn,
				    descr("PTY I/O error\n"));
			if( verbose ) fprintf(stderr,"PTY I/O error %x\n",pty_iosb[0]);
			kill_process();
			exit(0);
		}
		pkt_descr.size = pty_iosb[1];
		pkt_descr.ptr = pty_buf;/* send pty output over net */
		chaos_sout(conn,&pkt_descr);
		chaos_force_out(conn);
	}
}

/*
 * Here we have a packet from the network - process TELNET protocol
 * sequences and shove anything else to the PTY
 */
chaos_ast()
{
	int c;
	int saw_cr = 0;			/* crlf's don't cross pkt boundaries */

	pty_ocnt = 0;			/* nothing for the PTY yet */
	if( !(packet->Pkt_IOSB_Status&1) )
	{	chaos_close(conn,
			    descr("Network I/O error\n"));
		if( verbose ) fprintf(stderr,"I/O error reading pkt %x\n",
				      packet->Pkt_IOSB_Status);
		kill_process();
		exit(0);
	}
	if( (packet->Pkt_Opcode == PKT_OP_LOS) ||
	    (packet->Pkt_Opcode == PKT_OP_CLS) ||
	    (packet->Pkt_Opcode == PKT_OP_EOF) )
	{	chaos_close(conn,
			    descr("Connection lost or closed by NCP\n"));
		if( verbose ) fprintf(stderr,"Connection lost or closed by NCP %x\n",
				      packet->Pkt_Opcode);
		kill_process();
		exit(0);
	}
	bytes_left = PKT_NBYTES(packet);
	data_ptr = packet->Pkt_Data;

	/*
	 * We have a good packet - process any TELNET protocol sequences,
	 * and hand the rest off to the PTY
	 */
	while( bytes_left > 0 )
	{	c = get_char_from_pkt();
		if( c == IAC )		/* escape char? */
		{	c = get_char_from_pkt();
			if( c != IAC )	/* yes - do TELNET stuff */
			{	process_option(c);
				continue;
			}
		}
		if( myopts[TN_TRNBIN&03] == 0 ) c &= 0177;
		if( saw_cr )		/* else stuff char to PTY */
		{	saw_cr = 0;	/* ignore lf after cr */
			if( (c == 012) || (c == 000) ) continue;
		} else if( c == 015 ) saw_cr = 1;
		pty_out(c);
	}
	if( pty_ocnt != 0 )
		sys$qiow(PTY_EFN_A,pty_chan,IO$_WRITEVBLK,0,0,0,
			 pty_obuf,pty_ocnt,0,0,0,0);
	if( !(chaos_data_available(conn)) ) goahead = 1;
	chaos_asyn_in(conn,packet,CHAOS_EFN_A,chaos_ast,0);
}

/*
 * Get a character from the Chaos packet
 */
get_char_from_pkt()
{
	int c;

	bytes_left--;
	c = 0;
	if( bytes_left >= 0 )
	{	c = ((*data_ptr)&0377);
		data_ptr++;
	}
	return(c);
}

/*
 * Handle TELNET protocol
 */
process_option(c)
int c;
{
	int code;
	char proto[8];
	static char ctrl_c = 003;
	static char ctrl_o = 017;
	static char ctrl_u = 025;
	static char ctrl_x = 030;
	static char rubout = 0177;

	if( !(c == WILL || c == WONT || c == DO || c == DONT) )
		if( verbose ) fprintf(stderr,"(IAC %d)\n",c);
	switch( code = c ) {
	case WILL: case WONT: case DO: case DONT:
		c = get_char_from_pkt();
		if( verbose ) fprintf(stderr,"(IAC %d %d)\n",code,c);
		switch( code ) {
		case WILL:
			if( hisopts[c&3] != 0 ) break;
			if( (c == TN_SUPGO) || (c == TN_TRNBIN) )
			{	hisopts[c&3] = 1;
				send_option(DO,c,1);
			} else
			{	send_option(DONT,c,1);
			}
			break;
		case WONT:
			if( hisopts[c&3] == 0 ) break;
			if( (c == TN_SUPGO) || (c == TN_TRNBIN) )
			{	hisopts[c&3] = 0;
				send_option(DONT,c,1);
			} else
			{	send_option(DONT,c,1);
			}
			break;
		case DO:
			if( myopts[c&3] != 0 ) break;
			if( c == TN_ECHO )
			{	myopts[c&3] = 1;
				hisopts[c&3] = 0;
				set_pty_mode(0,TT$M_NOECHO);
				send_option(WILL,c,1);
			} else if( c == TN_TIMMRK )
			{	send_option(WONT,c,1);
			} else if( c == TN_SUPGO )
			{	myopts[c&3] = 1;
				goahead = 0;
				send_option(WILL,c,1);
			} else if( c == TN_TRNBIN )
			{	myopts[c&3] = 1;
				set_pty_mode(TT$M_EIGHTBIT,0);
				send_option(WILL,c,1);
			} else
			{	send_option(WONT,c,1);
			}
			break;
		case DONT:
			if( myopts[c&3] == 0 ) break;
			if( c == TN_ECHO )
			{	myopts[c&3] = 0;
				hisopts[c&3] = 1;
				set_pty_mode(TT$M_NOECHO,0);
				send_option(WONT,c,1);
			} else if( c == TN_TIMMRK )
			{	myopts[c&3] = 0;
				send_option(WONT,c,1);
			} else if( c == TN_SUPGO )
			{	myopts[c&3] = 0;
				goahead = 1;
				send_option(WONT,c,1);
			} else if( c == TN_TRNBIN )
			{	myopts[c&3] = 0;
				set_pty_mode(0,TT$M_EIGHTBIT);
				send_option(WONT,c,1);
			} else
			{	send_option(WONT,c,1);
			}
			break;
		}
		break;
	case DMARK:			/* i.e., flush all typeahead */
		pty_out(ctrl_x);
		break;
	case IP:			/* i.e., send a ctrl-c */
		pty_out(ctrl_c);
		break;
	case EC:			/* i.e., send a rubout */
		pty_out(rubout);
		break;
	case EL:			/* i.e., flush this line */
		pty_out(ctrl_u);
		break;
	case AO:			/* i.e., stop output */
		sprintf(proto,"%c%c",IAC,DMARK);
		chaos_sout(conn,descr(proto));
		chaos_force_out(conn);
		pty_out(ctrl_o);
		break;
	case NOP: case GA: case BRK:
		break;
	case AYT:			/* Are You There? */
		chaos_sout(conn,descr(BANNER));
		chaos_force_out(conn);
		break;
	default:
		if( verbose ) fprintf(stderr,"Received IAC %d\n",code);
		break;
	}
}

/*
 * Send out a TELNET option of the form IAC cmd opt.  For sake of
 * lower network traffic, only output the packet if force!=0
 */
send_option(cmd,opt,force)
int cmd,opt,force;
{
	if( verbose ) fprintf(stderr,"Sending IAC %d %d\n",cmd,opt);
	chaos_out_char(conn,IAC);
	chaos_out_char(conn,cmd);
	chaos_out_char(conn,opt);
	if( force ) chaos_force_out(conn);
}

/*
 * Set PTY's terminal characteristics
 */
set_pty_mode(on_bits,off_bits)
int on_bits,off_bits;
{
	int characteristics[2];

	sys$qiow(PTY_EFN_A,pty_chan,IO$_SENSEMODE,0,0,0,
		 &characteristics,8,0,0,0,0);
	characteristics[1] &= (~off_bits);
	characteristics[1] |= on_bits;
	sys$qiow(PTY_EFN_A,pty_chan,IO$_SETCHAR,0,0,0,
		 &characteristics,8,0,0,0,0);
}

/*
 * Termination MBX AST means time to quit
 */
mbx_ast()
{
	sleep(2);			/* in case there is still output */
	sys$dassgn(pty_chan);
	/* chaos_eof(conn); */
	chaos_close(conn,descr("TELNET session complete\n"));
	if( verbose ) fprintf(stderr,"Normal exit\n");
	exit(1);
}

/*
 * Kill the user process if it didn't log out correctly
 */
kill_process()
{
	int status;
	unsigned long items[4];
	unsigned long pid,unit;
	char pty_name[16];

	/*
	 * Get the pid of the pty owner and delete that process
	 */
	items[0] = 4 + (DVI$_UNIT << 16);
	items[1] = &unit;
	items[2] = 0;
	items[3] = 0;
	status = sys$getdvi(GEN_EFN,pty_chan,0,items,0,0,0,0);
	if( status&1 )
	{	sys$waitfr(GEN_EFN);
		sprintf(pty_name,"_PTA%d:",unit);
		items[0] = 4 + (DVI$_PID << 16);
		items[1] = &pid;
		items[2] = 0;
		items[3] = 0;
		status = sys$getdvi(GEN_EFN,0,descr(pty_name),items,0,0,0,0);
		if( status&1 )
		{	sys$waitfr(GEN_EFN);
			sys$delprc(&pid,0);
		}
	}
}
