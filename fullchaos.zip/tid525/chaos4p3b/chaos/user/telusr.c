/*
 *
 *	Chaos TELNET User -- this piece of code is loosely based
 *	on the works of Ron Schnell @ MIT and Kashtan @ SRI-IU,
 *	with much additional work by Scott McKay @ SCRC.
 */

/*
 *	Modification History:
 *	Ron Schnell - Made work for 3.0 with CMU's PTYS 11/82
 *	Ron Schnell - Added MBX feature 12/82
 *	Ron Schnell - Added code to set terminal to broadcast upon startup
 *	Scott McKay - Make it more robust 05/83
 *		    - Make it support TELNET protocol more fully
 *	Scott McKay - Convert TELNET server into TELNET user
 */

/*
 *  Utility routines for talking to Chaosnet
 */

int *seconds(n)
{
	static int secs[2] = {-1,-1};

	secs[0] = (-10*1000*1000)*n;
	return(secs);
}


struct VMS_Descriptor {int size; char *ptr;};

#define NDESCRS	20
struct VMS_Descriptor *descr(String)
register char *String;
{
	static struct VMS_Descriptor VMS_Descriptors[NDESCRS];
	static int index = 0;
	register int size = 0;

	if( index==NDESCRS ) index = 0;
	VMS_Descriptors[index].ptr = String;
	while( *String++ ) size++;	/* no nulls inside strings! */
	VMS_Descriptors[index].size = size;
	return(&VMS_Descriptors[index++]);
}


#include <stdio.h>
#include <iodef.h>
#include <ttdef.h>
#include "chaos$library:chaos.h"
#include "chaos$library:syscalls.h"

#define BANNER	"\r\nVAX/VMS Chaos TELNET User V3.0\n"

#define RFC_TIMER	30		/* timeout for chaos_rfc */

#define	CHAOS_EFN_A	23		/* event flags */
#define	CHAOS_EFN_S	22		/* event flags */
#define	TTY_EFN_A	21
#define	TTY_EFN_S	20

/*
 * TELNET protocol command characters
 */
#define	SE		240		/* end of subnegotiation params */
#define	NOP		241
#define	DMARK		242		/* data stream part of a synch */
#define	BRK		243		/* break key hit */
#define	IP		244		/* interrupt process */
#define	AO		245		/* abort output */
#define	AYT		246		/* are you there? */
#define	EC		247		/* erase character */
#define	EL		248		/* erase line */
#define	GA		249		/* goahead */
#define	SB		250		/* subnegotiation follows */
#define	WILL		251
#define	WONT		252
#define	DO		253
#define	DONT		254
#define	IAC		255		/* interpret as command */

/*
 * TELNET option codes
 */
#define	TN_TRNBIN	0		/* transmit binary (&3 -> 0) */
#define	TN_ECHO		1		/* echo (&3 -> 1) */
#define	TN_SUPGO	3		/* suppress goahead (&3 -> 3) */
#define	TN_TIMMRK	6		/* timing mark (&3 -> 2) */

int conn = -1;				/* chaos connection */
int tty_chan,tty_ocnt;			/* random tty stuff */
char tty_obuf[512];
int characteristics[2];
int hisopts[4],myopts[4];		/* TELNET options */
int goahead = 1;
int verbose = 0;
static struct CHAOSNET_DATA_PACKET *packet = 0;
static int bytes_left = 0;
static char *data_ptr = 0;

main(argc,argv)
int argc;
char **argv;
{
	int status;
	char *host_name = "";

	if( argc < 2 )
	{	while( strlen(host_name) == 0 )
		{	fprintf(stderr,"Host: ");
			gets(host_name);
		}
	}
	else host_name = *++argv;
	status = sys$assign(descr("SYS$INPUT:"),&tty_chan,0,0);
	if( !(status&1) )
	{	fprintf(stderr,"Couldn't open terminal\n");
		exit();
	}
	sys$qiow(TTY_EFN_S,tty_chan,IO$_SENSEMODE,0,0,0,
		 &characteristics,8,0,0,0,0);
	process(host_name);
}

/*
 * Parse host name, RFC for TELNET, and go
 */
process(host_name)
char *host_name;
{
	int i,status,ch;
	int host_addr = 0;
	char goahead_signal[8];
	extern chaos_ast();

/*
 * Given a host name, ask for a TELNET connection
 */
	for( i = 0; i < 4; i++ )
	{	hisopts[i] = 0;
		myopts[i] = 0;
	}
	status = hst_str_addr(descr(host_name),
			      &host_addr);
	if( !(status&1) )
	{	fprintf(stderr,"Couldn't parse host name %s\n",host_name);
		clean_exit();
	}
	chaos_rfc(&conn,host_addr,descr("TELNET"),
		  seconds(RFC_TIMER));	/* hook up to TELNET */
	chaos_state(conn);
	if( (state_of_conn(conn)&0377) != CONN_ST_OPEN )
	{	fprintf(stderr,"Couldn't establish TELNET connection\n");
		clean_exit();
	}

/*
 * We have a tty and a connection - allocate a packet, start
 * Chaos input, set sane TELNET characteristics, and go!
 */
	sprintf(goahead_signal,"%c%c",IAC,GA);
	if( !(chaos_pkt(&packet)&1) )	/* allocate a packet */
	{	fprintf(stderr,"Couldn't allocate a packet\n");
		clean_exit();
	}
	set_tty_mode((TT$M_EIGHTBIT|TT$M_NOECHO),
		     (TT$M_NOBRDCST|TT$M_HALFDUP));
	send_option(DO  ,TN_ECHO,0);
	send_option(WONT,TN_ECHO);
	send_option(DO  ,TN_TRNBIN,0);
	send_option(WILL,TN_TRNBIN,0);
	send_option(DO  ,TN_SUPGO,0);
	send_option(WILL,TN_SUPGO,1);
	chaos_asyn_in(conn,packet,CHAOS_EFN_A,chaos_ast,0);
	sleep(1);			/* cheap wait for completion */

/*
 * Main loop - read from tty, put to network
 */
	while( 1 )
	{	if( goahead != 0 && myopts[TN_SUPGO&3] == 0 )
		{	chaos_sout(conn,descr(goahead_signal));
			chaos_force_out(conn);
			goahead = 0;
		}
		if( (ch = get_char()) < 0 ) clean_exit();
		chaos_out_char(conn,ch);
		chaos_force_out(conn);
	}
}

/*
 * Here we have a packet from the network - process TELNET protocol
 * sequences and shove anything else to the tty
 */
chaos_ast()
{
	int c;

	tty_ocnt = 0;
	if( !(packet->Pkt_IOSB_Status&1) )
	{	fprintf(stderr,"Network I/O error\n");
		clean_exit();
	}
	if( (packet->Pkt_Opcode == PKT_OP_LOS) )
	{	fprintf(stderr,"Connection lost or closed by NCP\n");
		clean_exit();
	}
	if( (packet->Pkt_Opcode == PKT_OP_CLS) ||
	    (packet->Pkt_Opcode == PKT_OP_EOF) )
	{	fprintf(stderr,"Connection closed by remote host\n");
		clean_exit();
	}
	bytes_left = PKT_NBYTES(packet);
	data_ptr = packet->Pkt_Data;

/*
 * We have a good packet - process any TELNET protocol sequences,
 * and hand the rest off to the tty
 */
	while( bytes_left > 0 )
	{	c = get_char_from_pkt();
		if( c == IAC )		/* escape char? */
		{	c = get_char_from_pkt();
			if( c != IAC )	/* yes - do TELNET stuff */
			{	process_option(c);
				continue;
			}
		}
		if( myopts[TN_TRNBIN&03] == 0 ) c &= 0177;
		tty_out(c);
	}
	if( tty_ocnt != 0 )
		sys$qiow(TTY_EFN_A,tty_chan,IO$_WRITEVBLK,0,0,0,
			 tty_obuf,tty_ocnt,0,0,0,0);
	if( !(chaos_data_available(conn)) ) goahead = 1;
	chaos_asyn_in(conn,packet,CHAOS_EFN_A,chaos_ast,0);
}

/*
 * Get a char from the tty, and, if it's a command, process it
 */
get_char()
{
	int ch;
	char tty_buf[1];
	unsigned short tty_iosb[4];

get_ch:	sys$qiow(TTY_EFN_S,tty_chan,IO$_TTYREADALL,tty_iosb,0,0,
		 tty_buf,1,0,0,0,0);
	if( !(tty_iosb[0]&1) )
	{	fprintf(stderr,"TTY I/O error\n");
		goto get_ch;
	}
	ch = (((int) tty_buf[0]) & 0377);
	if( ch == 036 )			/* escape char (c-^)? */
	{	sys$qiow(TTY_EFN_S,tty_chan,IO$_TTYREADALL,tty_iosb,0,0,
			 tty_buf,1,0,0,0,0);
		if( !(tty_iosb[0]&1) )
		{	fprintf(stderr,"TTY I/O error\n");
			goto get_ch;
		}
		ch = (((int) tty_buf[0]) & 0377);
		switch( ch ) {
		case 036:		/* send second c-^ */
			return(ch);
			break;
		case '?': case 'H': case 'h':
			print_help();
			break;
		case 'Q': case 'q':
			fprintf(stderr,"Connection closed\n");
			return(-1);
			break;
		case 'V': case 'v':
			verbose = (~verbose);
			break;
		case 'Y'-0100:		/* interrupt */
			send_cmd(IP);
			break;
		case 'C'-0100:		/* break */
			send_cmd(BRK);
			break;
		case 'O'-0100:		/* abort output */
			send_cmd(AO);
			break;
		case 'T'-0100:		/* are you there */
			send_cmd(AYT);
			break;
		case 'Z'-0100:		/* temporary exit */
			attach();
			break;
		default:
			fprintf(stderr,"Illegal command\n");
			break;
		}
		goto get_ch;
	}
	return(ch);
}

/*
 * Get a character from the Chaos packet
 */
get_char_from_pkt()
{
	int c;

	bytes_left--;
	c = 0;
	if( bytes_left >= 0 )
	{	c = ((*data_ptr)&0377);
		data_ptr++;
	}
	return(c);
}

/*
 * Stash a character into the tty output buffer
 */
tty_out(c)
char c;
{
	tty_obuf[tty_ocnt++] = c;
}

/*
 * Handle TELNET protocol
 */
process_option(c)
int c;
{
	int code;
	char proto[8];
	static char ctrl_c = 003;
	static char ctrl_o = 017;
	static char ctrl_u = 025;
	static char ctrl_x = 030;
	static char rubout = 0177;

	switch( code = c ) {
	case WILL: case WONT: case DO: case DONT:
		c = get_char_from_pkt();
		if( verbose )
			fprintf(stderr,"(IAC %d %d)\n",code,c);
		switch( code ) {
		case WILL:
			if( hisopts[c&3] != 0 ) break;
			if( c == TN_ECHO )
			{	hisopts[c&3] = 1;
				myopts[c&3] = 0;
				set_tty_mode(TT$M_NOECHO,0);
				send_option(DO,c,1);
			} else if( c == TN_TIMMRK )
			{	send_option(DONT,c,1);
			} else if( c == TN_SUPGO )
			{	hisopts[c&3] = 1;
				send_option(DO,c,1);
			} else if( c == TN_TRNBIN )
			{	hisopts[c&3] = 1;
				send_option(DO,c,1);
			} else
			{	send_option(DONT,c,1);
			}
			break;
		case WONT:
			if( hisopts[c&3] == 0 ) break;
			if( c == TN_ECHO )
			{	hisopts[c&3] = 0;
				myopts[c&3] = 1;
				set_tty_mode(0,TT$M_NOECHO);
				send_option(DONT,c,1);
			} else if( c == TN_SUPGO )
			{	hisopts[c&3] = 0;
				send_option(DONT,c,1);
			} else if( c == TN_TRNBIN )
			{	hisopts[c&3] = 0;
				send_option(DONT,c,1);
			} else
			{	send_option(DONT,c,1);
			}
			break;
		case DO:
			if( myopts[c&3] != 0 ) break;
			if( c == TN_TIMMRK )
			{	send_option(WONT,c,1);
			} else if( c == TN_SUPGO )
			{	myopts[c&3] = 1;
				goahead = 0;
				send_option(WILL,c,1);
			} else if( c == TN_TRNBIN )
			{	myopts[c&3] = 1;
				set_tty_mode(TT$M_EIGHTBIT,0);
				send_option(WILL,c,1);
			} else
			{	send_option(WONT,c,1);
			}
			break;
		case DONT:
			if( myopts[c&3] == 0 ) break;
			if( c == TN_TIMMRK )
			{	myopts[c&3] = 0;
				send_option(WONT,c,1);
			} else if( c == TN_SUPGO )
			{	myopts[c&3] = 0;
				goahead = 1;
				send_option(WONT,c,1);
			} else if( c == TN_TRNBIN )
			{	myopts[c&3] = 0;
				set_tty_mode(0,TT$M_EIGHTBIT);
				send_option(WONT,c,1);
			} else
			{	send_option(WONT,c,1);
			}
			break;
		}
		break;
	case AO:
		send_cmd(DMARK);
		break;
	case NOP: case GA: case BRK: case DMARK:
		if( verbose ) fprintf(stderr,"(NOP/GA/BKR/DMARK %d)\n",c);
		break;
	case AYT:			/* Are You There? */
		if( verbose ) fprintf(stderr,"(AYT)\n");
		chaos_sout(conn,descr(BANNER));
		chaos_force_out(conn);
		break;
	default:
		fprintf(stderr,"Received IAC %d\n",code);
		break;
	}
}

/*
 * Send out a TELNET option of the form IAC cmd opt.  For sake of
 * lower network traffic, only output the packet if force!=0
 */
send_option(cmd,opt,force)
int cmd,opt,force;
{
	if( verbose )
		fprintf(stderr,"(Sending IAC %d %d)\n",cmd,opt);
	chaos_out_char(conn,IAC);
	chaos_out_char(conn,cmd);
	chaos_out_char(conn,opt);
	if( force ) chaos_force_out(conn);
}

/*
 * Send out a TELNET command of the form IAC cmd.
 */
send_cmd(cmd)
int cmd;
{
	if( verbose )
		fprintf(stderr,"(Sending IAC %d)\n",cmd);
	chaos_out_char(conn,IAC);
	chaos_out_char(conn,cmd);
	chaos_force_out(conn);
}

/*
 * Set tty's terminal characteristics
 */
set_tty_mode(on_bits,off_bits)
int on_bits,off_bits;
{
	int characteristics[2];

	sys$qiow(TTY_EFN_A,tty_chan,IO$_SENSEMODE,0,0,0,
		 &characteristics,8,0,0,0,0);
	characteristics[1] &= (~off_bits);
	characteristics[1] |= on_bits;
	sys$qiow(TTY_EFN_A,tty_chan,IO$_SETMODE,0,0,0,
		 &characteristics,8,0,0,0,0);
}

/*
 * Restore TTY characteristics, close connection, and exit
 */
clean_exit()
{
	sys$qiow(TTY_EFN_S,tty_chan,IO$_SETMODE,0,0,0,
		 &characteristics,8,0,0,0,0);
	sys$dassgn(tty_chan);
	if( conn >= 0 ) chaos_close(conn,descr("TELNET closed\n"));
	exit();
}

/*
 * Give the user some help
 */
print_help()
{
	fprintf(stderr,"\r\n");
	fprintf(stderr,"Q\tDisconnect and exit\n");
	fprintf(stderr,"V\tVerbose - show TELNET transactions\n");
	fprintf(stderr,"c-^\tSend a c-^\n");
	fprintf(stderr,"c-Y\tSend an attention sequence\n");
	fprintf(stderr,"c-C\tSend an break sequence\n");
	fprintf(stderr,"c-O\tSend an abort output sequence\n");
	fprintf(stderr,"c-T\tSend AYT sequence\n");
	fprintf(stderr,"c-Z\tSuspend this process and attach to another\n");
	fprintf(stderr,"H,?\tDisplay this message\n");
}

/*
 * Attach to another named process (only meaningful if this process
 * was started via a "spawn" command)
 */
attach()
{
	int i;
	int status = 1;
	int att_pid = 0;
	int jpi_items = 0;
	char *att_name;

	set_tty_mode(0,TT$M_NOECHO);	/* echoing back on */
	fprintf(stderr,"Process name: ");
	gets(att_name);
	if( att_name == NULL ) goto att_ex;
	status = sys$getjpi(0,&att_pid,descr(att_name),
			    &jpi_items,0,0,0);
	if( !(status&1) )
	{	for( i = 0; i < strlen(att_name); i++ )
			att_name[i] = toupper(att_name[i]);
		att_pid = 0;
		status = sys$getjpi(0,&att_pid,descr(att_name),
				    &jpi_items,0,0,0);
		if( !(status&1) ) goto att_ex;
	}
	status = lib$attach(&att_pid);
att_ex:	if( !(status&1) )
	{	fprintf(stderr,"Cannot attach to process\n");
	}
	if( myopts[TN_ECHO&3] == 0 ) set_tty_mode(TT$M_NOECHO,0);
}
