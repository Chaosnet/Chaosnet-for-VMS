/*
 *
 *	Chaos TELNET Server -- this piece of code is loosely based
 *	on the works of Ron Schnell @ MIT and Kashtan @ SRI-IU,
 *	with much additional work by Scott McKay @ SCRC.
 */

/*
 *	Modification History:
 *	Ron Schnell - Made work for 3.0 with CMU's PTYS 11/82
 *	Ron Schnell - Added MBX feature 12/82
 *	Ron Schnell - Added code to set terminal to broadcast upon startup
 *	Scott McKay - Make it more robust 05/83
 *		    - Make it support TELNET protocol more fully
 */

/*
 *  Utility routines for talking to Chaosnet
 */

int *seconds(n)
{
	static int secs[2] = {-1,-1};

	secs[0] = (-10*1000*1000)*n;
	return(secs);
}


struct VMS_Descriptor {int size; char *ptr;};

#define NDESCRS	20
struct VMS_Descriptor *descr(String)
register char *String;
{
	static struct VMS_Descriptor VMS_Descriptors[NDESCRS];
	static int index = 0;
	register int size = 0;

	if (index==NDESCRS) index = 0;
	VMS_Descriptors[index].ptr = String;
	while (*String++) size++;
	VMS_Descriptors[index].size = size;
	return(&VMS_Descriptors[index++]);
}


#include "chaos.h"
#include "syscalls.h"
#include <iodef.h>
#include <ttdef.h>

/* #define DEBUG_FLAG	1 */
/* #define VERBOSE_FLAG	1 */

#define BANNER	"\r\nVAX/VMS Chaos TELNET server V3.0"

#define	PTY1		0		/* lowest PTY */
#define	PTYN		7		/* highest PTY */

#define LSN_TIMER	300		/* timeout for chaos_lsn */

#define	CHAOS_EFN_A	23		/* event flags */
#define	CHAOS_EFN_S	22		/* event flags */
#define	PTY_EFN_A	21
#define	PTY_EFN_S	20
#define	MBX_EFN_A	19

/*
 * TELNET protocol command characters
 */
#define	SE		240		/* end of subnegotiation params */
#define	NOP		241
#define	DMARK		242		/* data stream part of a synch */
#define	BRK		243		/* break key hit */
#define	IP		244		/* interrupt process */
#define	AO		245		/* abort output */
#define	AYT		246		/* are you there? */
#define	EC		247		/* erase character */
#define	EL		248		/* erase line */
#define	GA		249		/* goahead */
#define	SB		250		/* subnegotiation follows */
#define	WILL		251
#define	WONT		252
#define	DO		253
#define	DONT		254
#define	IAC		255		/* interpret as command */

/*
 * TELNET option codes
 */
#define	TN_TRNBIN	0		/* transmit binary (&3 -> 0) */
#define	TN_ECHO		1		/* echo (&3 -> 1) */
#define	TN_SUPGO	3		/* suppress goahead (&3 -> 3) */
#define	TN_TIMMRK	6		/* timing mark (&3 -> 2) */

int pty_chan,mbx_chan;			/* random vms channels */
int chaos_conn;				/* chaos connection */
int hisopts[4],myopts[4];		/* TELNET options */
int goahead = 1;
char pty_obuf[512];			/* PTY output buffer */
int pty_ocnt;				/*  for efficiency */
static struct CHAOSNET_DATA_PACKET *packet = 0;
static int bytes_left = 0;
static char *data_ptr = 0;
int saw_cr = 0;
static char cr = 015;

main()
{
        int i,status;
	unsigned short pty_iosb[4];
	char pty_buf[512],mbx_buf[256];
	struct {int size; char *ptr;} pkt_descr;
	struct {int size; char *ptr;} rfc_descr;
	int rfc_len;
	char rfc_buf[256];
	char goahead_signal[8];
	extern chaos_ast(),mbx_ast();

/*
 * Listen and open a Chaos connection
 */
	debug_printf("Chaos TELNET started\r\n");
	rfc_descr.size = 256;
	rfc_descr.ptr = rfc_buf;
	chaos_lsn(&chaos_conn,descr("TELNET"),seconds(LSN_TIMER));
	chaos_state(chaos_conn);
	if ((state_of_conn(chaos_conn)&0377)!=CONN_ST_RFCRCV) {
		debug_printf("Not in RFC state\r\n");
		exit(0);
	}
	chaos_accept(chaos_conn,15,&rfc_descr,&rfc_len);
	chaos_state(chaos_conn);
	if ((state_of_conn(chaos_conn)&0377)!=CONN_ST_OPEN) {
		debug_printf("Chaosnet didn't open\r\n");
		exit(0);
	}
	debug_printf("Chaos connection opened OK\r\n");
	chaos_sout(chaos_conn,descr(BANNER));
	chaos_force_out(chaos_conn);

/*
 *	Try to allocate a PTY and an associated termination MBX
 */
	status = 0;
	for (i = PTY1; i<=PTYN; i++) {
		char pty_name[64];
		char mbx_name[64];
		sprintf(mbx_name,"SPT%d",i);
		sprintf(pty_name,"_PYA%d",i);
		status = sys$crembx(0,&mbx_chan,512,0,0,3,
				    descr(mbx_name));
		if (!(status&1)) continue;
		status = sys$assign(descr(pty_name),&pty_chan,3,
				    descr(mbx_name));
		if (status&1) break;
	}
	if (!(status&1)) {
		chaos_close(chaos_conn,
			    descr("No free PTY's - try again later\r\n"));
		debug_printf("No free PTY's %x\r\n",status);
		exit(0);
	}

/*
 * We have a PTY and a connection - allocate a packet, start
 * Chaos input, set sane TELNET characteristics, and go!
 */
	sprintf(goahead_signal,"%c%c",IAC,GA);
	status = sys$qio(MBX_EFN_A,mbx_chan,IO$_READVBLK,0,mbx_ast,0,
			 mbx_buf,256,0,0,0,0);
	if (!(status&1)) {
		chaos_close(chaos_conn,
			    descr("Mailbox I/O error\r\n"));
		debug_printf("Mailbox read error %x\r\n",status);
		exit(0);
	}
	if (!(chaos_pkt(&packet)&1)) {	/* allocate a packet */
		chaos_close(chaos_conn,
			    descr("Error allocating Chaos packet\r\n"));
		debug_printf("Couldn't allocate a packet");
		exit(0);
	}
	set_pty_mode(TT$M_EIGHTBIT,(TT$M_NOBRDCST|TT$M_NOECHO));
	send_option(WILL,TN_ECHO,0);
	send_option(DO  ,TN_TRNBIN,0);
	send_option(WILL,TN_TRNBIN,0);
	send_option(DO  ,TN_SUPGO,0);
	send_option(WILL,TN_SUPGO,1);
	debug_printf("On our way\r\n");
	chaos_asyn_in(chaos_conn,packet,CHAOS_EFN_A,chaos_ast,0);
	sleep(1);			/* cheap wait for completion */

/*
 * Main loop - read from PTY, put to network
 */
	while (1) {
		if (goahead!=0 && myopts[TN_SUPGO&3]==0) {
			chaos_sout(chaos_conn,descr(goahead_signal));
			goahead=0;
		}
		sys$qiow(PTY_EFN_S,pty_chan,IO$_READVBLK,pty_iosb,0,0,
			 pty_buf,512,0,0,0,0);
		if (!(pty_iosb[0]&1)) {
			chaos_close(chaos_conn,
				    descr("PTY I/O error\r\n"));
			debug_printf("PTY I/O error %x\r\n",pty_iosb[0]);
			exit(0);
		}
		pkt_descr.size = pty_iosb[1];
		pkt_descr.ptr = pty_buf;/* send pty output over net */
		chaos_sout(chaos_conn,&pkt_descr);
		chaos_force_out(chaos_conn);
	}
}

/*
 * Here we have a packet from the network - process TELNET protocol
 * sequences and shove anything else to the PTY
 */
chaos_ast()
{
	int c;

	pty_ocnt = 0;			/* nothing for the PTY yet */
	if (!(packet->Pkt_IOSB_Status&1)) {
		chaos_close(chaos_conn,
			    descr("Network I/O error\r\n"));
		debug_printf("I/O error reading pkt %x\r\n",
			     packet->Pkt_IOSB_Status);
		exit(0);
	}
	if ((packet->Pkt_Opcode==PKT_OP_LOS) ||
	    (packet->Pkt_Opcode==PKT_OP_CLS) ||
	    (packet->Pkt_Opcode==PKT_OP_EOF)) {
		chaos_close(chaos_conn,
			    descr("Connection lost or closed by NCP\r\n"));
		debug_printf("Connection lost or closed by NCP %x\r\n",
			     packet->Pkt_Opcode);
		exit(0);
	}
	bytes_left = PKT_NBYTES(packet);
	data_ptr = packet->Pkt_Data;

/*
 * We have a good packet - process any TELNET protocol sequences,
 * and hand the rest off to the PTY
 */
	while (bytes_left>0) {
		c = get_char_from_pkt();
#ifdef VERBOSE_FLAG
		debug_printf("%d ",c);
#endif
		if (c==IAC) {		/* escape char? */
			c = get_char_from_pkt();
#ifdef VERBOSE_FLAG
			debug_printf("%d ",c);
#endif
			if (c!=IAC) {	/* yes - do TELNET stuff */
				process_option(c);
				continue;
			}
		}
		if (!(myopts[TN_TRNBIN&03])) c &= 0177;
		if (saw_cr) {		/* else stuff char to PTY */
			pty_out(cr);
			saw_cr = 0;
			if ((c==012) || (c==000)) continue;
		} else {
			if (c==015) {
				saw_cr = 1;
				continue;
			}
		}
		pty_out(c);
	}
	if (pty_ocnt!=0)
		sys$qiow(PTY_EFN_A,pty_chan,IO$_WRITEVBLK,0,0,0,
			 pty_obuf,pty_ocnt,0,0,0,0);
	if (!(chaos_data_available(chaos_conn))) goahead = 1;
	chaos_asyn_in(chaos_conn,packet,CHAOS_EFN_A,chaos_ast,0);
}

/*
 * Get a character from the Chaos packet
 */
get_char_from_pkt()
{
	int c;

	bytes_left--;
	c = 0;
	if (bytes_left>=0) {
		c = ((*data_ptr)&0377);
		data_ptr++;
	}
	return(c);
}

/*
 * Stash a character into the PTY output buffer
 */
pty_out(c)
char c;
{
	pty_obuf[pty_ocnt++] = c;
}

/*
 * Handle TELNET protocol
 */
process_option(c)
int c;
{
	int code;
	char proto[8];
	static char ctrl_c = 003;
	static char ctrl_o = 017;
	static char ctrl_u = 025;
	static char ctrl_x = 030;
	static char rubout = 0177;

#ifdef VERBOSE_FLAG
	if (!(c==WILL || c==WONT || c==DO || c==DONT))
		debug_printf("(IAC %d)\r\n",c);
#endif
	switch (code = c) {
	case WILL: case WONT: case DO: case DONT:
		c = get_char_from_pkt();
#ifdef VERBOSE_FLAG
		debug_printf("%d ",c);
		debug_printf("(IAC %d %d)\r\n",code,c);
#endif
		switch (code) {
		case WILL:
			if (hisopts[c&3]) break;
			if ((c==TN_SUPGO) || (c==TN_TRNBIN)) {
				hisopts[c&3] = 1;
				send_option(DO,c,1);
			} else {
				send_option(DONT,c,1);
			}
			break;
		case WONT:
			if (!(hisopts[c&3])) break;
			if ((c==TN_SUPGO) || (c==TN_TRNBIN)) {
				hisopts[c&3] = 0;
				send_option(DONT,c,1);
			} else {
				send_option(DONT,c,1);
			}
			break;
		case DO:
			if (myopts[c&3]) break;
			if (c==TN_ECHO) {
				myopts[c&3] = 1;
				hisopts[c&3] = 0;
				set_pty_mode(0,TT$M_NOECHO);
				send_option(WILL,c,1);
			} else if (c==TN_TIMMRK) {
				send_option(WONT,c,1);
			} else if (c==TN_SUPGO) {
				myopts[c&3] = 1;
				send_option(WILL,c,1);
			} else if (c==TN_TRNBIN) {
				myopts[c&3] = 1;
				set_pty_mode(TT$M_EIGHTBIT,0);
				send_option(WILL,c,1);
			} else {
				send_option(WONT,c,1);
			}
			break;
		case DONT:
			if (!(myopts[c&3])) break;
			if (c==TN_ECHO) {
				myopts[c&3] = 0;
				hisopts[c&3] = 1;
				set_pty_mode(TT$M_NOECHO,0);
				send_option(WONT,c,1);
			} else if (c==TN_TIMMRK) {
				myopts[c&3] = 0;
				send_option(WONT,c,1);
			} else if (c==TN_SUPGO) {
				myopts[c&3] = 0;
				send_option(WONT,c,1);
			} else if (c==TN_TRNBIN) {
				myopts[c&3] = 0;
				set_pty_mode(0,TT$M_EIGHTBIT);
				send_option(WONT,c,1);
			} else {
				send_option(WONT,c,1);
			}
			break;
		}
		break;
	case DMARK:			/* i.e., flush all typeahead */
		pty_out(ctrl_x);
		break;
	case IP:			/* i.e., send a ctrl-c */
		pty_out(ctrl_c);
		break;
	case EC:			/* i.e., send a rubout */
		pty_out(rubout);
		break;
	case EL:			/* i.e., flush this line */
		pty_out(ctrl_u);
		break;
	case AO:			/* i.e., stop output */
		sprintf(proto,"%c%c",IAC,DMARK);
		chaos_sout(chaos_conn,descr(proto));
		chaos_force_out(chaos_conn);
		pty_out(ctrl_o);
		break;
	case NOP: case GA: case BRK:
		break;
	case AYT:			/* Are You There? */
		chaos_sout(chaos_conn,descr(BANNER));
		chaos_force_out(chaos_conn);
		break;
	default:
		debug_printf("Received IAC %d\r\n",code);
		break;
	}
}

/*
 * Send out a TELNET option of the form IAC cmd opt.  For sake of
 * lower network traffic, only output the packet if force!=0
 */
send_option(cmd,opt,force)
int cmd,opt,force;
{
	char proto[8];

#ifdef VERBOSE_FLAG
	debug_printf("Sending IAC %d %d\r\n",cmd,opt);
#endif
	sprintf(proto,"%c%c%c",IAC,cmd,opt);
	chaos_sout(chaos_conn,descr(proto));
	if (force) chaos_force_out(chaos_conn);
}

/*
 * Set PTY's terminal characteristics
 */
set_pty_mode(on_bits,off_bits)
int on_bits,off_bits;
{
	int characteristics[2];

	sys$qiow(PTY_EFN_A,pty_chan,IO$_SENSEMODE,0,0,0,
		 &characteristics,8,0,0,0,0);
	characteristics[1] &= (~off_bits);
	characteristics[1] |= on_bits;
	sys$qiow(PTY_EFN_A,pty_chan,IO$_SETCHAR,0,0,0,
		 &characteristics,8,0,0,0,0);
}

/*
 * Termination MBX AST means time to quit
 */
mbx_ast()
{
	sleep(2);			/* in case there is still output */
	sys$dassgn(pty_chan);
	chaos_eof(chaos_conn);
	chaos_close(chaos_conn,descr("Session complete\r\n"));
	debug_printf("Normal exit\r\n");
	exit(1);
}

debug_printf(str,a1,a2,a3,a4)
char str[];
int a1,a2,a3,a4;
{
#ifdef DEBUG_FLAG
	printf(str,a1,a2,a3,a4);
#endif
}

