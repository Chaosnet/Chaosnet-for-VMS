/*
 *
 *	Definitions to get "tastefully" caseified system call names
 *	all down to lower case
 *
 */

#define	SYS$AdjStk	sys$adjstk
#define	SYS$Assign	sys$assign
#define	SYS$BinTim	sys$bintim
#define	SYS$BrdCst	sys$brdcst
#define	SYS$Cancel	sys$cancel
#define	SYS$CanExh	sys$canexh
#define	SYS$CanWak	sys$canwak
#define	SYS$CanTim	sys$cantim
#define	SYS$Cli		sys$cli
#define	SYS$Close	sys$close
#define	SYS$ClrAST	sys$clrast
#define	SYS$CmExec	sys$cmexec
#define	SYS$CmKrnl	sys$cmkrnl
#define	SYS$CntReg	sys$cntreg
#define	SYS$Connect	sys$connect
#define	SYS$Create	sys$create
#define	SYS$CreLog	sys$crelog
#define	SYS$CreMBX	sys$crembx
#define	SYS$CrePrc	sys$creprc
#define	SYS$CretVA	sys$cretva
#define	SYS$Crmpsc	sys$crmpsc
#define	SYS$Dassgn	sys$dassgn
#define	SYS$DclCmh	sys$dclcmh
#define	SYS$DclExh	sys$dclexh
#define	SYS$DelMBX	sys$delmbx
#define	SYS$Delprc	sys$delprc
#define	SYS$DeltVA	sys$deltva
#define	SYS$Dgblsc	sys$dgblsc
#define	SYS$Disconnect	sys$disconnect
#define	SYS$Display	sys$display
#define	SYS$Erase	sys$erase
#define	SYS$Exit	sys$exit
#define	SYS$ExpReg	sys$expreg
#define	SYS$Fao		sys$fao
#define	SYS$Find	sys$find
#define	SYS$ForcEX	sys$forcex
#define	SYS$GetChn	sys$getchn
#define	SYS$GetJPI	sys$getjpi
#define	SYS$GetTim	sys$gettim
#define	SYS$Get		sys$get
#define	SYS$GetMsg	sys$getmsg
#define	SYS$Hiber	sys$hiber
#define	SYS$ImgAct	sys$imgact
#define	SYS$Mgblsc	sys$mgblsc
#define	SYS$Open	sys$open
#define	SYS$Parse	sys$parse
#define	SYS$PurgWS	sys$purgws
#define	SYS$Put		sys$put
#define	SYS$PutMsg	sys$putmsg
#define	SYS$QioW	sys$qiow
#define	SYS$Qio		sys$qio
#define	SYS$Read	sys$read
#define	SYS$Rename	sys$rename
#define	SYS$Resume	sys$resume
#define	SYS$Rewind	sys$rewind
#define	SYS$RmsRunDwn	sys$rmsrundwn
#define	SYS$RunDwn	sys$rundwn
#define	SYS$SchdWk	sys$schdwk
#define	SYS$Search	sys$search
#define	SYS$SetDDir	sys$setddir
#define	SYS$SetAST	sys$setast
#define	SYS$SetDDir	sys$setddir
#define	SYS$SetDfProt	sys$setdfprot
#define	SYS$SetExv	sys$setexv
#define	SYS$SetPri	sys$setpri
#define	SYS$SetPrn	sys$setprn
#define	SYS$SeTimr	sys$setimr
#define	SYS$SetRWM	sys$setrwm
#define	SYS$SndOpr	sys$sndopr
#define	SYS$Suspnd	sys$suspnd
#define	SYS$TrnLog	sys$trnlog
#define	SYS$Truncate	sys$truncate
#define	SYS$WaitFR	sys$waitfr
#define	SYS$Wake	sys$wake



